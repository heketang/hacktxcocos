#ifndef _COUNTDOWN_TIMER_H_
#define _COUNTDOWN_TIMER_H_
#include "cocos2d.h"
USING_NS_CC;

class CountdownTimer
{
public:
    ~CountdownTimer();
    void settle(float duration, bool forever = false, const std::function<void()>& onTimeUp = nullptr);
    void suspend(void);
    void resume();
    void restart();

    void reset(void);

    void update(float dt);

    std::function<void(int seconds)> onTimeChanged;
	std::function<void(float seconds)> onTimeChangedF;
    std::function<void()>            onTimeUp;

private:
    float timingValue = 0;
    float duration = 0;
    bool  running = false;
    bool  forever = false;
};

#endif

