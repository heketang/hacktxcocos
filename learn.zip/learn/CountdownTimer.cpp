#include "CountdownTimer.h"
#include "purelib/NXMacroDefs.h"

CountdownTimer::~CountdownTimer()
{

}

void CountdownTimer::settle(float duration, bool forever, const std::function<void()>& onTimeUp)
{
	this->timingValue = duration;
	this->duration = duration;
	this->forever = forever;
	this->onTimeUp = onTimeUp;
	resume();
}

void CountdownTimer::suspend(void)
{
	this->running = false;
}

void CountdownTimer::resume(void)
{
	this->running = true;
}

void CountdownTimer::restart()
{
	reset();
	resume();
}

void CountdownTimer::update(float dt)
{
	if (!this->running || this->duration <= 0)
		return;

	int prevalue = static_cast<int>(std::ceil(this->duration));

	this->duration -= dt;

	if (this->onTimeChangedF) {
		CCRUNONGL([=]{
			this->onTimeChangedF(std::max(0.0f, this->duration));
		});
	}

	int newvalue = static_cast<int>(std::ceil(this->duration));
	if (prevalue != newvalue)
		if (this->onTimeChanged) {
			CCRUNONGL([=]{
				this->onTimeChanged(std::max(0, newvalue));
			});
		}

	if (this->duration <= 0)
	{
		if (this->onTimeUp)
		{
            auto tempTimeUp = this->onTimeUp;
			CCRUNONGL([=]{
                tempTimeUp();
			});
		}

		if (this->forever)
			this->reset();
        else {
            this->onTimeUp = nullptr;
        }
	}
}

void CountdownTimer::reset(void)
{
	this->duration = this->timingValue;
}

