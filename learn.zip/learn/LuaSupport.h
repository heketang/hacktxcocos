#ifndef _LUA_SUPPORT_H_
#define _LUA_SUPPORT_H_
#include "CCLuaEngine.h"
#include <type_traits>
#include <cocos2d.h>
#include <string>
#include "LuaBasicConversions.h"
//#define LUAX_LOG_FUNC cocos2d::log
#include "xxlcall.h"


void       luasupport_register_all_modules(lua_State *L);

LUAX_VCALL_ADD_CCOBJ_SUPPORT(Node)
LUAX_VCALL_ADD_CCOBJ_SUPPORT(Scene)
LUAX_VCALL_ADD_CCOBJ_SUPPORT(Layer)
LUAX_VCALL_ADD_CCOBJ_SUPPORT(LayerColor)
LUAX_VCALL_ADD_CCOBJ_SUPPORT(Sprite)


//template<>
//std::vector<cocos2d::Node*> luax_dogetval(lua_State* L, const std::vector<cocos2d::Node*>& default_value);
inline
void luax_vpusharg(lua_State* L, int& carg, int& narg, const Point& arg)
{
    ++carg;
    if (lua_checkstack(L, 1))
        point_to_luaval(L, arg),++narg;
}

inline
void luax_retrive_arg(lua_State* L, const char* func, int n, Node*& arg, bool& ok)
{
    ok &= luaval_to_object<cocos2d::Node>(L, n, "cc.Node", &arg);
}

template<typename _Nodety> inline
void luax_retrive_arg(lua_State* L, const char* func, int n, _Nodety*& arg, bool& ok)
{
    Node* base = nullptr;
    ok &= luaval_to_object<cocos2d::Node>(L, n, "cc.Node", &base);
    if (ok)
        arg = dynamic_cast<_Nodety*>(base);
}

#endif

