#include "BattleScene.h"
#include "BattleField.h"
#include "BattleData.h"
#include "BattleFieldController.h"
#include "inet/NetworkManager.h"
#include "cocostudio/CocoStudio.h"
#include "purelib/utils/iconvw.h"
#include "GameUtils.h"
#include "Effect.h"
#include "Soldier.h"
#include "ShaderManager.h"
#include "purelib/utils/nsconv.h"
#include "AIDriver.h"
#include "BattleObj.h"
#include "BattleEventDispatcher.h"
#include "EventDispatcherEx.h"
#include "purelib/platform/NXNativeUtils.h"
#include "AudioEngine.h"
#include "purelib/utils/mathext.h"
#include <limits>
#include "effect_nodes/ensShatterNode.h"
#include "GuideLayer.h"
//#include "purelib/NXProgressLayer.h"
#include "purelib/UXProgressBar.hpp"
#include "GameOptions.h"

LUAX_VCALL_ADD_CCUI_SUPPORT(Text);

ui::Layout* internalCreateClipper(const Size& viewSize, int tag = -1)
{
    auto clipper = ui::Layout::create();
    clipper->setAnchorPoint(Point::ANCHOR_MIDDLE);
    clipper->ignoreAnchorPointForPosition(false);
    clipper->setContentSize(viewSize);
    clipper->setTag(tag);
    clipper->setClippingEnabled(true);
    clipper->setBackGroundColorOpacity(0);
    return clipper;
}

// @illregual accessor, don't copy
class UniformValueHack : public cocos2d::UniformValue
{
public:
    std::function<void(GLProgram*, Uniform*)> * getCallback()
    {
        if (_type == Type::CALLBACK_FN) {
            return _value.callback;
        }
        return nullptr;
    }

    std::function<void(GLProgram*, Uniform*)> *& callback()
    {
        return _value.callback;
    }
};

class GLProgramStateHack : public cocos2d::GLProgramState
{
public:
    using cocos2d::GLProgramState::GLProgramState;
    GLProgramState* cloneProperly()
    {
        auto glprogramstate = clone();

        typedef decltype(_uniforms) UniformsIterator;

        for (auto iterDest = ((GLProgramStateHack*)glprogramstate)->_uniforms.begin(),
            iterSrc = _uniforms.begin();
            iterSrc != _uniforms.end(); ++iterDest, ++iterSrc)
        {
            auto& dest = *iterDest;
            auto& src = *iterSrc;

            auto pcbSrc = ((UniformValueHack&)src.second).getCallback();
            if (pcbSrc != nullptr)
            {
                ((UniformValueHack&)dest.second).callback() = new std::function<void(GLProgram*, Uniform*)>(*pcbSrc);
            }
        }

        return glprogramstate;
    }
};

GLProgramState* _cloneGLProgramState(GLProgramState* source)
{
    return ((GLProgramStateHack*)source)->cloneProperly();
}

static auto lcgSmallIconSize = Size(78, 78);

enum BattleZOrder
{
    kBattleZOrderTouch,
    kBattleZOrderUI,
    kBattleZOrderSceneTopmost = INT_MAX,
};

enum {
    TAG_SKILL_BTN_HIGHLIGHT = 1104,
    TAG_UI_EFFECT_FIRE,
    TAG_UI_EFFECT_SKILL_BAR,
};

enum {
    TAG_UI_TIMELINE_ANIMATION = 501219,
    TAG_UI_TL_TURNROUND = 501220,
};

LUAX_VCALL_ADD_CCUI_SUPPORT(Button);
LUAX_VCALL_ADD_CUSTOM_SUPPORT(Hero);

enum {
    TAG_BATTLE_SCENE = 0x6102,
    // local spec

    //TAG_BATTLE_BTN_VIEW = 1128, // �鿴״̬
    // TAG_BATTLE_BTN_DEL = 1126, // ɾ����ť
    TAG_BATTLE_BTN_ROUNDOUT = 9,// ʣ�ಽ����ť��������������غ϶Ի���
    TAG_BATTLE_DLG_ROUNDOUT = 71, // �����غ϶Ի���
    TAG_BATTLE_BTN_ROUNDOUT_YES = 74,
    TAG_BATTLE_BTN_ROUNDOUT_NO = 75,

    // TAG_BATTLE_BTN_CLOSE_SETTINGS = 45,
    TAG_BATTLE_DLG_SETTINGS = 44,
    TAG_BATTLE_BTN_SHOW_IME = 80,
    TAG_BATTLE_IMG_INPUT_BACKG = 82,
    TAT_BATTLE_INPUT_SMS = 84,
    TAG_BATTLE_BTN_EQUIP = 296, // ���ұ�ǩ��ͬ


    TAB_BATTLE_BTN_SETTINGS = 86,
    TAG_BATTLE_BTN_CLOSE_SETTINGS = 277,
    TAG_BATTLE_LA_NEW_SETTINGS = 274,

    TAG_SETTINGS_PANEL = 240,
    TAB_SETTINGS_BTN_VIEW_ANY = 43,
    TAG_SETTINGS_BTN_AUTO = 48,
    TAG_SETTINGS_BTN_GIVE_UP = 47, // Ͷ��
    TAG_SETTINGS_BTN_OPM = 241,

    TAB_SETTINGS_BTN_VIEW_ANY_NEW = 278,
    TAG_SETTINGS_BTN_AUTO_NEW = 281,
    TAG_SETTINGS_BTN_GIVE_UP_NEW = 279, // Ͷ��
    TAG_SETTINGS_BTN_OPM_NEW = 280,

    TAG_BATTLE_FOREGROUND = 0xc002,

    TAG_BATTLE_ICON_BOUND_NODE = 2000
};

enum DramaReward
{
    EXP = 7,
    GOLD = 9,
    DIAMOND = 10,
    IRON = 11
};


static void updateCustomBarPercent(Node* bar, Node* relative, float value)
{
    if (bar == nullptr)
        return;
    //auto oldScale = relative->getScale();
    auto relativeSize = relative->getContentSize();
    auto pos = Point(relativeSize.width / 2, -relativeSize.height / 2);
    auto deltaTotal = relativeSize.height;
    pos.y += (value / 100.0f * deltaTotal);

    //relative->setScale(1.0f);
    auto worldPoint = relative->convertToWorldSpace(pos);
    //relative->setScale(oldScale);
    auto localPoint = bar->getParent()->convertToNodeSpace(worldPoint);

    bar->setPosition(localPoint);
    if (bar->getScaleY() <= -1) {
        bar->setPositionY(-bar->getPositionY() + (relativeSize.height * relative->getScaleY()));
    }
    bar->setVisible(!(value >= 100 || value <= 0));
}


static void internalChangeIcon(Sprite* icon, const char* newtexture)
{
    auto boundSize = icon->getContentSize();

    auto& smallImgSize = icon->getContentSize();
    float scaleProperly = std::min((boundSize.width / std::max(smallImgSize.width, smallImgSize.height)) * 0.75f, 0.75f);

    icon->setScale(scaleProperly);
}

static void internalChangeIcon(Sprite* icon, const char* newtexture, const Size& boundSize)
{
    icon->setTexture(newtexture);

    auto& smallImgSize = icon->getContentSize();
    float scaleProperly = (std::min(boundSize.width, boundSize.height) / std::max(smallImgSize.width, smallImgSize.height));

    icon->setScale(scaleProperly);

    icon->setVisible(true);
}

static std::vector<Node*> cheatGroup; // ���������ԣ�����ʱע�ͻ�ɾ������

static BattleScene* s_battleObject = nullptr;
BattleScene* BattleScene::thisObject()
{
    return s_battleObject;
}

int g_fight_count = 0;

static int backgroundMusicId = -1;

void BattleScene::onExit(void)
{
    cheatGroup.clear();

    if (backgroundMusicId != -1)
        experimental::AudioEngine::stop(backgroundMusicId);

    stopGame();

    Layer::onExit();

    EventDispatcherEx::getInstance()->removeAllListeners();
    backgDispatch->removeAllListeners();
    BattleEventDispatcher::getInstance()->removeAllEventListeners();

    // AchievementData::getInstance()->reset();

    s_battleObject = nullptr;
}

BattleScene::BattleScene() : objectRefreshed(false), localAvatarTLA(false), peerAvatarTLA(false)
{
    ++g_fight_count;

    localCtl = new BattleFieldController(OPSIDE_LOCAL);
    peerCtl = new BattleFieldController(OPSIDE_PEER);
}

BattleScene::~BattleScene()
{
    delete localCtl;
    delete peerCtl;
    delete this->backgDispatch;
}

AbilityManager* BattleScene::getAbilityManager(void)
{
    return &abilityMgr;
}

bool BattleScene::abilityIsAllowToDo()
{
    return !getAbilityManager()->hasAbilityRunning() && getAbilityManager()->roundAbilityQueue2.empty() && getAbilityManager()->events == 0;
}


CountdownTimer* BattleScene::getEmbattleTimer(void)
{
    return &this->embattleTimer;
}

Node* BattleScene::getBackgnd(void)
{
    return backg;
}

bool BattleScene::init()
{
    if (!Layer::init())
        return false;

    embattleTimeLimit = gamedepl->getEmbattleTime();

    maskLayer = nullptr;
    this->settingPanel = nullptr;
    designationLocation = Vec2(0, 0);
    isDramaConditionOk = false;
    isDramaSoldierDelete = false;
    chapter_index = 0;
    nPlayer_index = 1;
    story_index = 0;
    enemy_index = 0;
    battleStartupInfoResult = -1;
    isPeerDramaFlush = false;
    isLocalFirst = false;
    isDramaClickButton = false;
    isDramaSoldierAtk = false;
    myRefresh_index = 0;
    userMsgFlag = 0;
    dramaSavePoint = 0;
    isChapterFirstFight = true;
    my_division = 0;
    their_division = 0;
    myTime = nullptr;
    youTime = nullptr;

#if defined(WINRT)
    //SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/battle_bgm2.wav", true);
#else
    //SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/battle_bgm2.mp3", true);
#endif
    // backgroundMusicId = experimental::AudioEngine::play2d("sounds/battle_bgm2", true);

    setTag(TAG_BATTLE_SCENE);

    auto localHeroId = BattleData::getInstance()->queryData(VDI_HERO_ID, true);

    auto backgImageSrc = luax_pvvcall("bext.getBackgImageSrc", localHeroId, BattleData::getInstance()->getBattleStartupInfo().result < 1);

    backg = Sprite::create(backgImageSrc); // ����ͼ��jpg��pngС8��
    this->addChild(backg);
    nodes_layout::centerNode(backg);

    this->backgDispatch = new EventDispatcherEx();
    this->backgDispatch->initWithNode(backg);

    /// add buttom layer
    bottomNode = Node::create();
    backg->addChild(bottomNode);
    nodes_layout::centerNode(bottomNode);

    /// create mainuiround
    mainui = CSLoader::getInstance()->createNode("la_fight_mainui.csb"); // cocostudio::GUIReader::getInstance()->widgetFromJsonFile("cocosui/battleScene.ExportJson");// LayerColor::create(Color4B(255, 255, 255, 35));// Sprite::create("battle/mainuiround.jpg");
    mainui->setCascadeOpacityEnabled(true);
    mainui->setOpacity(0);
    // auto layout = dynamic_cast<ui::Layout*>(mainui);
    // layout->setBackGroundImage("battle/mainuiround.png");

    this->addChild(mainui);
    nodes_layout::centerNode(mainui);

    initFields();
    initUI();
    registerEventHandlers();


    /// ��ʼ�����ֲ�
    this->eventBlockLayer = GameUtils::createModelLayer();
    this->addChild(this->eventBlockLayer);
    this->eventBlockLayer->setVisible(false);

    BattleData::getInstance()->startup(this);  //��ʼ��ģ�ͣ�PVEģ�ͻ���PVPģ�ͣ�PVEģ����ע��ˢ�������¼���PVPģ����ע���ƶ�ɾ��ˢ���¼�

    /// topmost
    topmostNode = Node::create();
    // topmostNode->setContentSize(getContentSize());
    this->addChild(topmostNode, kBattleZOrderSceneTopmost);
    nodes_layout::centerNode(topmostNode);

    // Adpating
    nodes_layout::vscr::setNodeLeft(GameUtils::findDescendant(mainui, "Panel_your")->getChildByName("Sprite_48"), -4);
    nodes_layout::vscr::setNodeLeft(GameUtils::findDescendant(mainui, "Panel_your")->getChildByName("you_time"), -4);

    nodes_layout::vscr::setNodeRight(GameUtils::findDescendant(mainui, "Button_degree"), -56);
    nodes_layout::vscr::setNodeRight(GameUtils::findDescendant(mainui, "Image_11"), 5);

    nodes_layout::vscr::setNodeLeft(GameUtils::findDescendant(mainui, "Button_all"), 13.1f);
    nodes_layout::vscr::setNodeRight(GameUtils::findDescendant(mainui, "Button_soldiers"), 23.6);
    nodes_layout::vscr::setNodeRight(GameUtils::findDescendant(mainui, "my_time"), -21.7);

    return true;
}

#if _ENABLE_SPINE_BATCH_RENDER
SpineBatchNode* BattleScene::getSpineBatchNode(BattleObj* obj)
{
    union {
        struct {
            int bitsId : 30;
            int bitsColor : 2;
        };
        int value;
    } asp;
    auto s = dynamic_cast<Soldier*>(obj);
    if (s != nullptr) {
        asp.bitsId = s->getUnitId();
        asp.bitsColor = s->getColorId();
    }
    else {
        asp.value = -1;
    }
    auto key = asp.value;

    auto batchIter = std::find_if(this->spineBatchNodes.begin(), this->spineBatchNodes.end(), [=](SpineBatchNode* batch) {
        return (batch->getTag() == key);
    });

    if (batchIter != this->spineBatchNodes.end())
        return *batchIter;

    auto spineBatchNode = SpineBatchNode::create();
    this->spineBatchNodes.push_back(spineBatchNode);

    spineBatchNode->setTag(key);
    spineBatchNode->setContentSize(Size(luax_vgetval<float>("deploy.battle_field.chessboard_width"), luax_vgetval<float>("deploy.battle_field.chessboard_height")));
    spineBatchNode->ignoreAnchorPointForPosition(false);

    spineBatchNode->setGLProgramState(( (GLProgramStateHack*)s->getImpl()->getGLProgramState() )->cloneProperly());

    this->backg->addChild(spineBatchNode);
    nodes_layout::centerNode(spineBatchNode);

    return spineBatchNode;
}
#endif

void BattleScene::showMaskLayer(float opacity)
{
    if (this->maskLayer == nullptr) {
        this->maskLayer = LayerColor::create(Color4B(0, 0, 0, opacity));
        this->addChild(maskLayer);
    }
}

void BattleScene::removeMaskLayer(void)
{
    if (this->maskLayer != nullptr) {
        this->maskLayer->removeFromParent();
        this->maskLayer = nullptr;
    }
}

void BattleScene::stopAllUIEvents(const Color4B& color, bool bSuspendTimer)
{
    if (bSuspendTimer)
        this->embattleTimer.suspend();
    this->eventBlockLayer->setColor(Color3B(color));
    this->eventBlockLayer->setOpacity(color.a);
    this->eventBlockLayer->setVisible(true);
}

void BattleScene::resumeAllUIEvents(void)
{
    this->eventBlockLayer->setVisible(false);

    if (this->battleStartupInfoResult != 0)
    {
        this->embattleTimer.resume();
    }
}

bool BattleScene::isEventBlocked() const
{
    return this->eventBlockLayer->isVisible();
}

void BattleScene::initFields()
{
    localHero = Hero::create();
    peerHero = Hero::create();

    localHero->controller = this->localCtl;
    peerHero->controller = this->peerCtl;

    localHero->local = true;
    peerHero->local = false;

    this->addChild(localHero);
    this->addChild(peerHero);
    nodes_layout::setNodePosition(localHero, nodes_layout::ALIGN_CB);
    nodes_layout::setNodePosition(peerHero, nodes_layout::ALIGN_CT);

    /// create battle field
    localField = BattleField::create();
    peerField = BattleField::create();

    localField->setUserData(this);
    peerField->setUserData(this);

    backg->addChild(peerField);
    backg->addChild(localField);

    normalEffectLa = LayerColor::create(Color4B(255, 0, 255, 0));
    backg->addChild(normalEffectLa);
    nodes_layout::centerNode(normalEffectLa);

    std::vector<Node*> layouts = { peerField, localField };
    nodes_layout::alignLefts(layouts);
    nodes_layout::makeVerticalSpacingEqual(layouts, 80);
    nodes_layout::centerHoriVerti(layouts);

    localCtl->install(localField, localHero, peerCtl);
    peerCtl->install(peerField, peerHero, localCtl);


}

void BattleScene::startGame(void)
{
    if (this->objectRefreshed)
        return;

    if (!BattleData::getInstance()->isDataReady())
    {
        createTextTagForError("Error, Battle Data Not Ready!");
        return;
    }

    NetworkManager::getInstance()->startBattleHeartbeat();

    // start GAME
    this->scheduleUpdate();

    localField->resumeSchedulerAndActions();
    peerField->resumeSchedulerAndActions();


    // update init data
    auto battleData = BattleData::getInstance();
    auto mode = BattleData::getInstance()->getMode();
    std::vector<DramaLevelItem> enemy_soldiers;
    std::vector<DramaLevelItem> my_soldiers;

    if (mode == BattleMode::PVE || mode == BattleMode::PHONY_PVP)
    {
        auto& detail_field = BattleData::getInstance()->getBattleStartupInfo();
        this->battleStartupInfoResult = detail_field.result;

        auto enemy_t = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_ENEMYREFRESH);
        auto& enemys = enemy_t->getAllData();
        auto enemy = enemy_t->getDataRow(1);

        auto myRefresh_t = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_MYREFRESH);
        auto& myRefreshs = myRefresh_t->getAllData();
        auto myRefresh = myRefresh_t->getDataRow(1);

        if (this->battleStartupInfoResult < 1)
        {
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_BATTLE_START);
            auto& detail = BattleData::getInstance()->getDramaBattleStartupInfo();
            this->isLocalFirst = BattleData::getInstance()->getDramaStartupInfoFirst();

            detail.encodeLua(luax_getVM());

            battleData->setFirst(detail.first);

            bLocalFirst = detail.first;
            /*if (detail.first) {
                this->onTurnLocalRound(true);
                }
                else {
                this->onTurnPeerRound(true);
                }*/

            auto chapters = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_CHAPTER);
            auto& chapter = chapters->getDataRow(chapter_index);

            if (chapter_index == 1001)
            {
                this->isChapterFirstFight = true;
            }

            if (chapter.at(DAI_CHAPTER_MY_ON).asInt() == 1){
                for (size_t i = 1; i <= myRefreshs.size(); i++)
                {
                    myRefresh.clear();
                    myRefresh = myRefresh_t->getDataRow(i);
                    this->myRefresh_index = i;
                    if (myRefresh.at(DAI_MYREFRESH_CHAPTER_ID).asInt() == chapter_index)
                    {
                        auto my_detail = nsc::split(myRefresh.at(DAI_MYREFRESH_ENEMY_DETAIL).asString(), "#");

                        for (size_t i = 0; i < my_detail.size(); ++i)
                        {
                            auto my_info = nsc::split(my_detail.at(i).c_str(), ";");
                            DramaLevelItem soldier = { (uint32_t)atoi(my_info.at(0).c_str()), (uint8_t)atoi(my_info.at(1).c_str()), (uint8_t)atoi(my_info.at(2).c_str()), (uint16_t)atoi(my_info.at(3).c_str()), (uint8_t)atoi(my_info.at(4).c_str()) };
                            my_soldiers.push_back(soldier);
                        }
                        break;
                    }

                }
            }
            else
            {
                my_soldiers = detail.user_field.soldiers;
                //soldiers.assign(detail.peer_field.soldiers.begin(), detail.peer_field.soldiers.end());
            }

            if (chapter.at(DAI_CHAPTER_ENEMY_ON).asInt() == 1){
                for (size_t i = 1; i <= enemys.size(); i++)
                {
                    enemy.clear();
                    enemy = enemy_t->getDataRow(i);
                    this->enemy_index = i;
                    if (enemy.at(DAI_ENEMYREFRESH_CHAPTER_ID).asInt() == chapter_index)
                    {
                        auto enemy_detail = nsc::split(enemy.at(DAI_ENEMYREFRESH_ENEMY_DETAIL).asString(), "#");

                        for (size_t i = 0; i < enemy_detail.size(); ++i)
                        {
                            auto enemy_info = nsc::split(enemy_detail.at(i).c_str(), ";");
                            DramaLevelItem soldier = { (uint32_t)atoi(enemy_info.at(0).c_str()), (uint8_t)atoi(enemy_info.at(1).c_str()), (uint8_t)atoi(enemy_info.at(2).c_str()), (uint16_t)atoi(enemy_info.at(3).c_str()), (uint8_t)atoi(enemy_info.at(4).c_str()) };
                            enemy_soldiers.push_back(soldier);
                        }
                        break;
                    }

                }
            }
            else
            {
                enemy_soldiers = detail.peer_field.soldiers;
                //soldiers.assign(detail.peer_field.soldiers.begin(), detail.peer_field.soldiers.end());
            }
            localCtl->generateDramaSoldiers(my_soldiers);
            peerCtl->generateDramaSoldiers(enemy_soldiers);

            battleData->updateUIOnly(VDI_STEP, detail.first);

            fillIcons(detail.user_field.hero_id, detail.peer_field.hero_id);

            BattleData::getInstance()->setOpmode(OPMODE_QUICK);
            /*if (chapter_index == 1001 || chapter_index == 1003)
            {
            BattleData::getInstance()->setOpmode(OPMODE_CLICK);
            }
            else{
            BattleData::getInstance()->setOpmode(OPMODE_QUICK);
            }*/

            if (chapter.at(DAI_CHAPTER_NEWPLAYER_ON).asInt() == 0)
            {
                isDrama = false;
            }
            else
            {
                isDrama = true;
            }
        }
        else
        {
            auto& detail = detail_field;
            battleData->setFirst(detail.first);

            bLocalFirst = detail.first;
            /*if (detail.first) {
                this->onTurnLocalRound(true);
                }
                else {
                this->onTurnPeerRound(true);
                }*/

            localCtl->generateSoldiers(detail.user_field.soldiers);
            peerCtl->generateSoldiers(detail.peer_field.soldiers);

            battleData->updateUIOnly(VDI_STEP, detail.first);

            luax_pvcall("bext.setDivision");
            fillIcons(detail.user_field.hero_id, detail.peer_field.hero_id);


            /*auto p = localCtl->convertToWorldPoint(1, 1);
            auto meIcon = GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BTN_ICON);
            auto guideLayer = GuideLayer::CreateStep(p, meIcon);
            this->addChild(guideLayer);*/

            //nodes_layout::centerNode(guideLayer);
        }
    }
    else if (mode >= BattleMode::PVP)
    {
        auto& detail = BattleData::getInstance()->getBattleStartupInfo();
        this->battleStartupInfoResult = detail.result;
        battleData->setFirst(detail.first);

        bLocalFirst = detail.first;
        /*if (detail.first) {
            this->onTurnLocalRound(true);
            }
            else {
            this->onTurnPeerRound(true);
            }*/
        luax_pvcall("bext.setDivision");

        localCtl->generateSoldiers(detail.user_field.soldiers);
        peerCtl->generateSoldiers(detail.peer_field.soldiers);

        battleData->updateUIOnly(VDI_STEP, detail.first);

        fillIcons(detail.user_field.hero_id, detail.peer_field.hero_id);
    }



    battleData->updateUIOnly(VDI_IDLES);
    battleData->updateUIOnly(VDI_HP);
    battleData->updateUIOnly(VDI_MAX_HP);
    battleData->updateUIOnly(VDI_MP);

    battleData->updateUIOnly(VDI_IDLES, false);
    battleData->updateUIOnly(VDI_HP, false);
    battleData->updateUIOnly(VDI_MAX_HP, false);
    battleData->updateUIOnly(VDI_MP, false);

    luax_pvcall("equipmentDataInit.handleUnitEquipmentInit", localHero);
    luax_pvcall("equipmentDataInit.handleUnitEquipmentInit", peerHero);

    //auto str = GameUtils::getStringForKey("matching");
    //createTextTagForNormal(iconvw::g2u(str).c_str());

    this->gameRunning = true;
}

void BattleScene::changeDivisionFrame()
{
    auto localLeftFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "left_frame"));
    auto peerLeftFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "left_frame"));

    auto localRightFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "right_frame"));
    auto peerRightFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "right_frame"));

    auto localHeadFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "head_frame"));
    auto peerHeadFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "head_frame"));

    auto localButtonSkill = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodeLocal, "Button_skill"));
    auto peerButtonSkill = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodePeer, "Button_skill"));

    auto localButtonWeapon = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodeLocal, "Button_weapon"));
    auto peerButtonWeapon = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodePeer, "Button_weapon"));

    auto localHpFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "hp_frame"));
    auto peerHpFrame = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "hp_frame"));

    auto localButtonDegree = dynamic_cast<ui::Button*>(GameUtils::findDescendant(mainui, "Button_degree"));//״̬��ť
    this->trstr = dynamic_cast<ui::Text*>(GameUtils::findDescendant(localButtonDegree, "btn_degree_text"));    //�غ��л�����
    this->imageStep = dynamic_cast<ui::ImageView*>(GameUtils::findDescendant(mainui, "Image_11"));   //���ض�λ����
    this->strStep = dynamic_cast<ui::Text*>(GameUtils::findDescendant(imageStep, "Text_21"));       //���²���

    auto localButtonSoldier = dynamic_cast<ui::Button*>(GameUtils::findDescendant(mainui, "Button_soldiers"));
    auto localButtonSetting = dynamic_cast<ui::Button*>(GameUtils::findDescendant(mainui, "Button_all"));

    if (my_division == 0)
    {
        localButtonSetting->setVisible(false);
    }

    int m_ndir = sprintf(my_texturePath, "res/fight/head_frame_lv%d/", my_division);

    xstrcpy(my_texturePath + m_ndir, "left_right_frame.png");
    localLeftFrame->setTexture(my_texturePath);
    localRightFrame->setTexture(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "head_frame.png");
    localHeadFrame->setTexture(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "weapon_skill_frame.png");
    localButtonSkill->loadTextureNormal(my_texturePath);
    localButtonSkill->loadTextureDisabled(my_texturePath);
    localButtonWeapon->loadTextureNormal(my_texturePath);
    localButtonWeapon->loadTextureDisabled(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "hp_frame.png");
    localHpFrame->setTexture(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "round.png");
    localButtonDegree->loadTextureNormal(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "soldier.png");
    localButtonSoldier->loadTextureNormal(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "setting.png");
    localButtonSetting->loadTextureNormal(my_texturePath);

    xstrcpy(my_texturePath + m_ndir, "step_frame.png");


    int t_division = sprintf(their_texturePath, "res/fight/head_frame_lv%d/", their_division);
    xstrcpy(their_texturePath + t_division, "left_right_frame.png");
    peerLeftFrame->setTexture(their_texturePath);
    peerRightFrame->setTexture(their_texturePath);

    xstrcpy(their_texturePath + t_division, "head_frame.png");
    peerHeadFrame->setTexture(their_texturePath);

    xstrcpy(their_texturePath + t_division, "weapon_skill_frame.png");
    peerButtonSkill->loadTextureNormal(their_texturePath);
    peerButtonSkill->loadTextureDisabled(their_texturePath);
    peerButtonWeapon->loadTextureNormal(their_texturePath);
    peerButtonWeapon->loadTextureDisabled(their_texturePath);

    xstrcpy(their_texturePath + t_division, "hp_frame.png");
    peerHpFrame->setTexture(their_texturePath);

    xstrcpy(their_texturePath + t_division, "step_frame.png");
}

void BattleScene::fillIcons(int meIconID, int youIconId)
{
    changeDivisionFrame();
    const Size& boundSize = GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_ICON_BOUND_NODE)->getContentSize();

    ////// ��ʼ��ͷ��
    meIcon = GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BTN_ICON);
    auto youIcon = GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BTN_ICON);

    auto heroTable = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_HEROS);

    auto& merecord = heroTable->getDataRow(meIconID);
    std::string mypath = merecord[DAI_HEROS_IMAGES].asString();
    //static_cast<Sprite*>(meIcon)->setTexture(mypath + "/small_img.png");

    auto &yourecord = heroTable->getDataRow(youIconId);
    std::string youpath = yourecord[DAI_HEROS_IMAGES].asString();
    //static_cast<Sprite*>(youIcon)->setTexture(youpath + "/small_img.png");




    const char* localAvatarAsset = luax_pvxcall<const char*>("bext.getHeroAvatar", meIconID / 10000);
    auto localAvatar = CSLoader::createNode(localAvatarAsset);
    localAvatar->setPosition(meIcon->getPosition());
    meIcon->getParent()->addChild(localAvatar);
    localAvatarTLA.setup(localAvatarAsset);
    localAvatarTLA.play(localAvatar, "idle", true);

    const char* peerAvatarAsset = luax_pvxcall<const char*>("bext.getHeroAvatar", youIconId / 10000);
    auto peerAvatar = CSLoader::createNode(peerAvatarAsset);
    peerAvatar->setPosition(meIcon->getPosition());
    youIcon->getParent()->addChild(peerAvatar);
    peerAvatarTLA.setup(peerAvatarAsset);
    peerAvatarTLA.play(peerAvatar, "idle", true);

    meIcon->setOpacity(0);
    youIcon->setVisible(false);

    // meIcon->bringToFront();
    GameUtils::uiRegister(meIcon, [](cocos2d::Ref*){
        cocos2d::log("-------------------- me icon clicked -----------------------");
        luax_pvcall("bext.handleLocalAvatarClicked");
    });

    localAvatar->insertBefore(meIcon);
    peerAvatar->insertBefore(youIcon);
    peerAvatar->setScaleY(-1);
    peerAvatar->setScaleX(-1);


    //// ��ʼ������ͼ��
    this->localHero->setAbilId(merecord[DAI_HEROS_ID].asInt());
    this->peerHero->setAbilId(yourecord[DAI_HEROS_ID].asInt());

    auto spellTab = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SPELL);
    auto localHeroSpellProps = spellTab->getDataRow(this->localHero->getAbilId());
    auto peerHeroSpellProps = spellTab->getDataRow(this->peerHero->getAbilId());

    auto panelLocalSkillDetail = GameUtils::findDescendant(mainui, "Panel_mySkillDes");
    auto panelPeerSkillDetail = GameUtils::findDescendant(mainui, "Panel_yourSkillDes");

    dynamic_cast<ui::Text*>(GameUtils::findDescendant(panelLocalSkillDetail, "skill_name"))->setString(localHeroSpellProps[DAI_SPELL_NAME].asString());
    dynamic_cast<ui::Text*>(GameUtils::findDescendant(panelLocalSkillDetail, "Text_skill"))->setString(localHeroSpellProps[DAI_SPELL_DESCRIBE].asString());

    dynamic_cast<ui::Text*>(GameUtils::findDescendant(panelPeerSkillDetail, "skill_info"))->setString(peerHeroSpellProps[DAI_SPELL_NAME].asString());
    dynamic_cast<ui::Text*>(GameUtils::findDescendant(panelPeerSkillDetail, "Text_skill"))->setString(peerHeroSpellProps[DAI_SPELL_DESCRIBE].asString());


    char skillTexturePath[128];

    sprintf(skillTexturePath, "images/shared/icons/abils/hero_%d.png", this->localHero->getId() / 10000);
    internalChangeIcon(dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_skill")), skillTexturePath, boundSize);

    sprintf(skillTexturePath, "images/shared/icons/abils/hero_%d.png", this->peerHero->getId() / 10000);
    internalChangeIcon(dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_skill")), skillTexturePath, boundSize);

    auto skillIcon = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_skill"));
    auto skillIconPeer = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_skill"));
    ShaderManager::getInstance()->setShader(ShaderType::PERCENT_DARK_VERTI, skillIcon);
    ShaderManager::getInstance()->setShader(ShaderType::PERCENT_DARK_VERTI, skillIconPeer);
    ShaderManager::getInstance()->setPercent(skillIcon, 0.0);
    ShaderManager::getInstance()->setPercent(skillIconPeer, 0.0);


    ////// ��ʼ��װ��icon������
    auto localButtonWeapon = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodeLocal, "Button_weapon"));
    auto peerButtonWeapon = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodePeer, "Button_weapon"));

    auto localEquipIcon = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_weapon"));
    auto peerEquipIcon = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_weapon"));

    auto equipTab = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_EQUIPMENTS);
    auto localEquipId = BattleData::getInstance()->queryData(VDI_EQUIP_ID);
    auto peerEquipId = BattleData::getInstance()->queryData(VDI_EQUIP_ID, false);

    /// local equip icon
    auto& localEquipProps = equipTab->getDataRow(localEquipId);
    auto& peerEquipProps = equipTab->getDataRow(peerEquipId);

    if (!localEquipProps.empty()) {
        auto texturePath = localEquipProps.at(DAI_EQUIPMENTS_E_ICON_WAY).asString();
        internalChangeIcon(localEquipIcon, texturePath, boundSize); // TODO: Get bound node
        auto equipLa = GameUtils::findDescendant(mainui, "Panel_myEquipDes");
        auto lblEquipName = dynamic_cast<ui::Text*>(GameUtils::findDescendant(equipLa, "equip_name"));
        auto lblEquipDesc = dynamic_cast<ui::Text*>(GameUtils::findDescendant(equipLa, "Text_equip"));
        lblEquipName->setString(localEquipProps[DAI_EQUIPMENTS_E_NAME].asString());
        lblEquipDesc->setString(localEquipProps[DAI_EQUIPMENTS_E_DES].asString());
    }
    else {
        localButtonWeapon->setEnabled(false);
        localWeaponEnabled = false; // localButtonWeapon->setEnabled(false);
    }

    if (!peerEquipProps.empty()) {
        auto texturePath = peerEquipProps.at(DAI_EQUIPMENTS_E_ICON_WAY).asString();
        internalChangeIcon(peerEquipIcon, texturePath, boundSize); // TODO: Get bound node
        auto equipLa = GameUtils::findDescendant(mainui, "Panel_yourEquipDes");
        auto lblEquipName = dynamic_cast<ui::Text*>(GameUtils::findDescendant(equipLa, "equip_name"));
        auto lblEquipDesc = dynamic_cast<ui::Text*>(GameUtils::findDescendant(equipLa, "Text_equip"));
        lblEquipName->setString(peerEquipProps[DAI_EQUIPMENTS_E_NAME].asString());
        lblEquipDesc->setString(peerEquipProps[DAI_EQUIPMENTS_E_DES].asString());
    }
    else {
        peerButtonWeapon->setEnabled(false);
        peerWeaponEnabled = false; // peerButtonWeapon->setEnabled(false);
    }

    this->timelineUIAnim.preserveScale("Image_weapon");
    this->timelineUIAnimPeer.preserveScale("Image_weapon");

    this->timelineUIAnim.preserveScale("Image_skill");
    this->timelineUIAnimPeer.preserveScale("Image_skill");
}

void BattleScene::resumeGame(std::shared_ptr<RealtimeBattleInfoNotify> resumeInfo)// �����������������������̺�ָ���Ϸ
{
    /*if (!BattleData::getInstance()->isDataReady())
    {
    createTextTagForError("Error, Battle Data Not Ready!");
    return;
    }*/

    NetworkManager::getInstance()->startBattleHeartbeat();

    localCtl->reset();
    peerCtl->reset();

    // start GAME
    this->scheduleUpdate();

    localField->resumeSchedulerAndActions();
    peerField->resumeSchedulerAndActions();

    auto battleData = BattleData::getInstance();

    battleData->updateUIOnly(VDI_IDLES);
    battleData->updateUIOnly(VDI_HP);
    battleData->updateUIOnly(VDI_MAX_HP);
    battleData->updateUIOnly(VDI_MP);

    battleData->updateUIOnly(VDI_IDLES, false);
    battleData->updateUIOnly(VDI_HP, false);
    battleData->updateUIOnly(VDI_MAX_HP, false);
    battleData->updateUIOnly(VDI_MP, false);


    bool localOperating = BattleData::getInstance()->isLocalOperating();
    battleData->updateUIOnly(VDI_STEP, localOperating);
    if (localOperating) {
        this->onTurnLocalRound(true);
    }
    else {
        this->onTurnPeerRound(true);
    }

#if 0
    getLocalController()->refreshObjects(resumeInfo->receiver_info.cells);
    getPeerController()->refreshObjects(resumeInfo->sender_info.cells);
#endif

    BattleData::getInstance()->clearBattleResumeInfo();

    /*auto str = GameUtils::getStringForKey("recovery");
    createTextTagForNormal(iconvw::g2u(str).c_str());*/

    this->gameRunning = true;
}

void BattleScene::refreshAllObjects(RealtimeBattleInfoNotify* detail)
{
    this->objectRefreshed = true;
    //this->getLocalController()->refreshObjects(detail->receiver_info.cells);
    // this->getPeerController()->refreshObjects(detail->sender_info.cells);
}

void BattleScene::stopGame(void)
{
    hideTextTag();

    luax_pvcall("bext.handleGameStop");

    BattleEventDispatcher::getInstance()->setNotifyAttackStart(false);
    NetworkManager::getInstance()->stopBattleHeartbeat();
    AIDriver::getInstance()->reset();

    BattleData::getInstance()->terminate();

    localField->pauseSchedulerAndActions();
    peerField->pauseSchedulerAndActions();

    localCtl->reset();
    peerCtl->reset();

    localField->disableControl();
    peerField->disableControl();

    // stop GAME
    this->unscheduleUpdate();

    this->gameRunning = false;
    this->gameTerminating = false;
}

void BattleScene::update(float dt)
{
    if (this->gameRunning && !this->gameLogicBlocking) {
        localCtl->updateBehavoir(dt);
        peerCtl->updateBehavoir(dt);

        abilityMgr.updateBehavior(dt);

        AIDriver::getInstance()->updateBehavoir(dt);

        embattleTimer.update(dt);
        // leafTimer.update(dt);
        for (auto timer : timers)
            timer->update(dt);

        this->triggerGameEnd();
    }
}

void BattleScene::addTimer(CountdownTimer* timer)
{
    if (std::find(this->timers.begin(), this->timers.end(), timer) == this->timers.end())
        this->timers.push_back(timer);
}

void BattleScene::removeTimer(CountdownTimer* timer)
{
    container_helper::remove_if(timers, [timer](CountdownTimer* t){
        return (t == timer);
    });
}

void BattleScene::suspendAllTimers()
{
    for (auto timer : timers)
        timer->suspend();
}

void BattleScene::resumeAllTimers()
{
    for (auto timer : timers)
        timer->resume();
}

void BattleScene::showFire(bool local)
{
    Node* avatar = nullptr;
    if (local)
    {
        avatar = (GameUtils::findDescendant(this->pnodeLocal, TAG_BATTLE_BTN_ICON));
    }
    else {
        avatar = (GameUtils::findDescendant(this->pnodePeer, TAG_BATTLE_BTN_ICON));
    }

    if (avatar->getActionByTag(TAG_UI_EFFECT_FIRE) != nullptr)
        return;

#if 0
    auto fire = Effect::create("models/ui_effect/master_fire");
    fire->setTag(TAG_UI_EFFECT_FIRE);
    avatar->addChild(fire);
    fire->alignCenter();
    fire->playAnimation("animation", true);

    nodes_layout::centerNode(fire);
#endif

    avatar->setColor(Color3B(255, 0, 0));
    auto tintAction = cocos2d::RepeatForever::create(Sequence::create(
        TintTo::create(0.3f, Color3B(255, 0, 0)),
        TintTo::create(0.3f, Color3B(255, 255, 255)),
        nullptr
        ));
    tintAction->setTag(TAG_UI_EFFECT_FIRE);
    avatar->runAction(tintAction);
}

void BattleScene::hideFire(bool local)
{
    Node* avatar = nullptr;
    if (local)
    {
        avatar = (GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BTN_ICON));
    }
    else {
        avatar = (GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BTN_ICON));
    }

    avatar->stopActionByTag(TAG_UI_EFFECT_FIRE);
}

void BattleScene::startAIDriverAndAutoControl(BattleFieldController* ctl)
{
    this->startAutoControl(ctl);
    AIDriver::getInstance()->active();
    /*if (!abilityMgr.hasAbilityRunning())
    {
    AIDriver::getInstance()->active();
    }
    else {
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_END, [](const BattleEventParam&){
    AIDriver::getInstance()->active();
    }, true);
    }*/
}

int BattleScene::getRealRounds(bool turningLocal) const
{
    auto currentRounds = BattleData::getInstance()->getRounds();

    return currentRounds;

    /*if (turningLocal) {
        return (BattleData::getInstance()->isFirst()) ? currentRounds + 1 : currentRounds;
        }
        return (!BattleData::getInstance()->isFirst()) ? currentRounds + 1 : currentRounds;*/
}

void BattleScene::configBattleForSync(float optime)
{
    bool localOperating = BattleData::getInstance()->isLocalOperating();

    this->myTime->setVisible(localOperating);
    this->youTime->setVisible(!localOperating);

    if (localOperating)
    {
        GameUtils::findDescendant(mainui, "PanelTimerParent")->setVisible(false);
        embattleTimer.onTimeChanged = [this](int /*seconds*/){
            auto valueNew = BattleData::getInstance()->modifyData(VDI_OPTIME, -1);

            if (valueNew <= luax_vgetval<float>("deploy.optime_label_display_time", 10))
            {
                auto panel = GameUtils::findDescendant(mainui, "PanelTimerParent");
                panel->setVisible(true);

                auto labelTime = dynamic_cast<TextAtlas*>(panel->getChildren().at(0));
                labelTime->setString(fastest_itoa(valueNew));
            }

            if (valueNew <= 0)
            {
                this->updateUIValue(TAG_BATTLE_LBL_TIME, 0);
                embattleTimer.suspend();
                if (luax_pvxcall<bool>("cicAbilCreate.launchLocalCachedCicAbils")){
                    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_END, [=](const BattleEventParam&){
                        BattleData::getInstance()->notifyTurnOver();
                    }, true);
                }
                else {
                    BattleData::getInstance()->notifyTurnOver();
                }
            }
        };
        embattleTimer.settle(optime);

        setAllUserButtonsEnabled(true);
        localField->enableControl();
        this->imageStep->loadTexture(this->my_texturePath);
    }
    else {
        BattleData::getInstance()->updateData(VDI_OPTIME, optime, false);

        setAllUserButtonsEnabled(false);
        localField->disableControl();
        this->imageStep->loadTexture(this->their_texturePath);

        // ensure timer hidden.
        embattleTimer.suspend();
        auto panel = GameUtils::findDescendant(mainui, "PanelTimerParent");
        panel->setVisible(false);
    }

    upStepPosition(localOperating);

    if (BattleData::getInstance()->getRounds() >= luax_vgetval("deploy.poweradd_rounds", 5))
    {
        if (luax_pvxcall<bool>("bext.showUrgentMap"))
        {
            this->showHeroFire(true);
            this->showHeroFire(false);
        }
    }

    updateRoundsUI(); // ���»غ�UI
}

void BattleScene::onTurnLocalRound(bool forInit, int timeLimit)
{
    bLocalTurnning = true;
    this->localCtl->updateUserOpTime();
    auto currentRounds = getRealRounds(true);
    this->myTime->setVisible(true);
    this->youTime->setVisible(false);

	auto mpa = luax_pvfcall("formula.mpa.autoRound");
	localHero->modifyMana(mpa, !forInit);// BattleData::getInstance()->modifyData(VDI_MP, mpa);

    BattleData::getInstance()->updateData(VDI_OPTIME, timeLimit);
    // ��������ʱ
    //embattleTimer.onTimeChangedF = [this, timeLimit](float seconds){
    //	// progressTimer->setPercentage(seconds / timeLimit * 100);
    //};
    GameUtils::findDescendant(mainui, "PanelTimerParent")->setVisible(false);
    embattleTimer.onTimeChanged = [this, timeLimit](int /*seconds*/){
        auto valueNew = BattleData::getInstance()->modifyData(VDI_OPTIME, -1);

        if (valueNew <= luax_vgetval<float>("deploy.optime_label_display_time", 10))
        {
            auto panel = GameUtils::findDescendant(mainui, "PanelTimerParent");
            panel->setVisible(true);

            auto labelTime = dynamic_cast<TextAtlas*>(panel->getChildren().at(0));
            labelTime->setString(fastest_itoa(valueNew));
        }

        if (valueNew <= 0)
        {
            this->updateUIValue(TAG_BATTLE_LBL_TIME, 0);
            embattleTimer.suspend();
            if (luax_pvxcall<bool>("cicAbilCreate.launchLocalCachedCicAbils")){
                BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_END, [=](const BattleEventParam&){
                    BattleData::getInstance()->notifyTurnOver();
                }, true);
            }
            else {
                BattleData::getInstance()->notifyTurnOver();
            }
        }
    };
    embattleTimer.suspend();
    AIDriver::getInstance()->deactive();


    this->eventBlockLayer->setOpacity(0);
    this->eventBlockLayer->setVisible(true);
    this->imageStep->loadTexture(this->my_texturePath);
    luax_pvvcall("bext.roundbacklocal", this->trstr);

    if (!luax_pvxcall<bool>("bext.handleTurnLocalRound", BattleData::getInstance()->isFirst(), currentRounds))
    {
        auto nodTurnRound = CSLoader::createNode("tl_turn_round.csb");
        this->backg->addChild(nodTurnRound);
        nodes_layout::centerNode(nodTurnRound);
        auto spRound = cocos2d::utils::findChild<Sprite*>(nodTurnRound, "difanghuihe");
        auto lblRound = cocos2d::utils::findChild<ui::Text*>(nodTurnRound, "Text_tx");
        spRound->setTexture("res/wofanghuihe.png");
        lblRound->setString(fastest_itoa(getRealRounds(true)));

        this->timelineTurnRound.play(nodTurnRound, false, "wfhh", [=]()mutable->void{
            this->finishTurnLocalRound();
        });
    }
}

void BattleScene::onTurnPeerRound(bool forInit, int timeLimit)
{
    this->bTurnning = !forInit;

    this->localCtl->updateUserOpTime();
    auto currentRounds = getRealRounds(false);

    this->myTime->setVisible(false);
    this->youTime->setVisible(true);

    auto mpa = luax_pvfcall("formula.mpa.autoRound");
    peerHero->modifyMana(mpa, !forInit);// BattleData::getInstance()->modifyData(VDI_MP, mpa);
    // notify script
    // luax_pvcall("bext.onTurnPeerRound", BattleData::getInstance()->isFirst(), currentRounds);

    BattleData::getInstance()->updateData(VDI_OPTIME, timeLimit, false);
    // ��������ʱ
    //embattleTimer.onTimeChangedF = [this, timeLimit](float seconds){
    //	// progressTimer->setPercentage(seconds / timeLimit * 100);
    //};
    GameUtils::findDescendant(mainui, "PanelTimerParent")->setVisible(false);
    embattleTimer.onTimeChanged = ([this, timeLimit](int /*seconds*/){
        auto valueNew = BattleData::getInstance()->modifyData(VDI_OPTIME, -1, false);
        if (valueNew <= luax_vgetval<float>("deploy.optime_label_display_time", 20))
        {
            auto panel = GameUtils::findDescendant(mainui, "PanelTimerParent");
            panel->setVisible(true);

            auto labelTime = dynamic_cast<TextAtlas*>(panel->getChildren().at(0));
            labelTime->setString(fastest_itoa(valueNew));
        }

        if (valueNew <= 0)
        { // just waiting peer notify.
            this->updateUIValue(TAG_BATTLE_LBL_TIME, 0);
            embattleTimer.suspend();

            if (getPeerController()->isAutoControl()) {
                BattleData::getInstance()->notifyTurnOver();
            }
        }
    });

    setAllUserButtonsEnabled(false);

    localField->disableControl();

    this->localCtl->cancelSelectedSoldier(true);
    this->localCtl->clearDraggingSoldier();
    this->localField->cancelTouch();

    AIDriver::getInstance()->deactive(); // ��ͣAI

    embattleTimer.suspend();

    this->eventBlockLayer->setOpacity(0);
    this->eventBlockLayer->setVisible(true);

    luax_pvvcall("bext.roundbackpeer", this->trstr);
    this->imageStep->loadTexture(this->their_texturePath);

    if (!luax_pvxcall<bool>("bext.handleTurnPeerRound", BattleData::getInstance()->isFirst(), currentRounds))
    {
        auto nodTurnRound = CSLoader::createNode("tl_turn_round.csb");
        this->backg->addChild(nodTurnRound);
        nodes_layout::centerNode(nodTurnRound);
        auto lblRound = cocos2d::utils::findChild<ui::Text*>(nodTurnRound, "Text_tx");
        lblRound->setString(fastest_itoa(currentRounds));
        this->timelineTurnRound.play(nodTurnRound, false, "dfhh", [=]()mutable->void{
            this->finishTurnPeerRound();

        });
    }
}

void BattleScene::finishTurnLocalRound()
{
    bool bStartRound = BattleData::getInstance()->isFirst();
    bool forInit = getRealRounds(true) == 1 && BattleData::getInstance()->isFirst();

    this->eventBlockLayer->setVisible(false);
    this->localCtl->updateUserOpTime();

    BattleData::getInstance()->updateData(VDI_STEP, forInit ? 2 : 3, true);

    upStepPosition(true);

    luax_pvcall("equipmentDataInit.handleEquipidUnitAddStep", localHero);

    // notify script
    /*if (BattleData::getInstance()->isFirst())
    {
    BattleData::getInstance()->increaseRounds();
    }*/

    if (!forInit)
        getLocalController()->turnRound();  //Ԫ��ֵ���º͹���Ԫ����

    //����������Զ��йܣ����Ի�����AI����
    if (this->localCtl->isAutoControl()) {
        this->localField->disableControl(); //���ش����¼��ĵĽ�ֹ����
        this->startAIDriverAndAutoControl(this->localCtl);
    }
    else
    { //�������,��Ҫ��ֹ�з�AI�ж�
        localField->enableControl();//ʹ��
    }

    handleRoundAnimationEnd(this->embattleTimeLimit);

    auto nPlayers = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_NEWPLAYER);
    if (this->isDrama)
    {
        auto& nPlayer = nPlayers->getDataRow(nPlayer_index);
        if (nPlayer.at(DAI_NEWPLAYER_CHAPTER_ID).asInt() == chapter_index)
        {
            if (this->isDramaSoldierAtk == false)
            {
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
            }
        }

    }

    if (this->battleStartupInfoResult < 1 && nPlayer_index != 0)
    {
        auto& nPlayer = nPlayers->getDataRow(nPlayer_index);
        auto condition = nsc::split(nPlayer.at(DAI_NEWPLAYER_CONDITION).asString(), ";");
        auto save = nPlayer.at(DAI_NEWPLAYER_SAVE).asString();

        if (atoi(save) != 0 && this->dramaSavePoint == 0)
        {
            auto save_info = nsc::split(save, ";");
            if (atoi(save_info.at(0).c_str()) != 9)
            {
                this->dramaSavePoint = atoi(save_info.at(1).c_str());
            }
        }

        if (atoi(condition.at(0).c_str()) == 6)
        {
            if (atoi(condition.at(1).c_str()) == BattleData::getInstance()->getRounds())
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
        }

        auto isContinue = checkDramaWinOrLoseCondition(DAI_CHAPTER_LOSE_CONDITIONS, false);
        if (isContinue)
            return;

        checkDramaWinOrLoseCondition(DAI_CHAPTER_WIN_CONDITIONS, true);

    }

    this->backg->removeChildByTag(TAG_UI_TL_TURNROUND);
    // nodTurnRound->removeFromParent();

    // this->bTurnning = false;

    if (bStartRound) {
        /*performGlobalBuffers(true);
        performGlobalBuffers(false);*/
    }
}

void BattleScene::finishTurnPeerRound()
{
    bool bStartRound = !BattleData::getInstance()->isFirst();
    bool forInit = getRealRounds(false) == 1 && !BattleData::getInstance()->isFirst();

    /*if (!BattleData::getInstance()->isFirst())
    {
    BattleData::getInstance()->increaseRounds();
    }*/

    /*eff->playAnimation("difanghuihe", false, true, [=](BattleObj*){*/
    this->eventBlockLayer->setVisible(false);
    if (!forInit)
        getPeerController()->turnRound();

    BattleData::getInstance()->updateData(VDI_STEP, forInit ? 2 : 3, false);
    luax_pvcall("equipmentDataInit.handleEquipidUnitAddStep", peerHero);

    upStepPosition(false);

    if (this->peerCtl->isAutoControl())
    {
        if (this->isDrama)
        {
            auto nPlayers = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_NEWPLAYER);
            auto& nPlayer = nPlayers->getDataRow(nPlayer_index);
            auto condition = nsc::split(nPlayer.at(DAI_NEWPLAYER_CONDITION).asString(), ";");
            if (this->isLocalFirst == false)
            {
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
                this->isLocalFirst = true;
            }
            else if (atoi(condition.at(0).c_str()) == 6)
            {
                if (atoi(condition.at(1).c_str()) == BattleData::getInstance()->getRounds())
                {
                    this->isDramaConditionOk = true;
                    BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
                }

                auto isContinue = checkDramaWinOrLoseCondition(DAI_CHAPTER_LOSE_CONDITIONS, false);
                if (isContinue)
                    return;

                checkDramaWinOrLoseCondition(DAI_CHAPTER_WIN_CONDITIONS, true);
            }
            else
            {
                this->startAIDriverAndAutoControl(this->peerCtl);
            }

        }
        else
        {
            this->startAIDriverAndAutoControl(this->peerCtl);
        }
    }
    else
    { // ����з������Զ��йܣ��Լ����й�״̬����ôת��ս���Ժ�Ӧ�ý�ֹAI�ж�
        /*if (this->localCtl->isAutoControl())
        {
        AIDriver::getInstance()->deactive();
        }*/
    }

    if (!BattleData::getInstance()->needsNotifyThroughNetwork())
    {
        handleRoundAnimationEnd(this->embattleTimeLimit);
    }

    // luax_pvcall("bext.onAfterTurnPeerRound", BattleData::getInstance()->isFirst(), currentRounds);

    this->backg->removeChildByTag(TAG_UI_TL_TURNROUND); // nodTurnRound->removeFromParent();

    // this->bTurnning = false;
    if (bStartRound) {
        /*performGlobalBuffers(true);
        performGlobalBuffers(false);*/
    }
}

void BattleScene::checkAndApplyGlobalBuffs(bool local)
{
    if (this->bTurnning) {
        this->bTurnning = false;
    }

    if (bLocalTurnning) {
        bLocalTurnning = false;
        setAllUserButtonsEnabled(true); // request enable button, it will check isAutoControl
    }
    // performGlobalBuffers(local);
}

//�ջ�
void  BattleScene::applyGlobalPowerBuffs()
{
    showHeroFire(true);
    showHeroFire(false);
}

void BattleScene::showHeroFire(bool local)
{
    Node* fireNode = nullptr;
    Point hornLoc;
    if (local) {
        fireNode = GameUtils::findDescendant(pnodeLocal, "node_fire");
    }
    else {
        // animName = "lanhaojiao";
        fireNode = GameUtils::findDescendant(pnodePeer, "node_fire");
        fireNode->setScaleY(-1);
    }

    if (fireNode->isVisible())
        return;

    TimelineAnimate tl;
    tl.setup("mast_fire.csb");
    fireNode->setVisible(true);
    tl.play(fireNode, true);
    appendGlobalBuffSig("images/shared/gongji_buf.png", local);
}

void BattleScene::performGlobalBuffs(bool local)
{ // unused: TODO: remove this function
#if 0
    if (BattleData::getInstance()->getRounds() >= luax_vgetval("deploy.stepadd_rounds", 10))
    {
        BattleData::getInstance()->modifyData(VDI_STEP, luax_vgetval("deploy.stepadd_value", 2), local);
    }
#endif

    auto powerAddRounds = luax_vgetval("deploy.poweradd_rounds", 5);
    auto powerRoundDelta = BattleData::getInstance()->getRounds() - powerAddRounds;
    if (powerRoundDelta >= 0)
    { // ��ս�Ž�
        BattleFieldController* controller = nullptr;
        if (local)
            controller = getLocalController();
        else
            controller = getPeerController();
        // ����Ч��
        if (powerAddRounds == BattleData::getInstance()->getRounds())
        {
            // luax_pvcall("audiol.play", 351); // experimental::AudioEngine::play2d("sounds/zzhj.mp3");
#if 0
            auto effect = Effect::create("models/ui_effect/zhengzhanhaojiao", 1.0f, EffectAlign::ALIGN_CENTER);
            getTopmost()->addChild(effect);
            const char* animName = "honghaojiao";
#endif

            //auto loc = effect->getPosition();

            TimelineAnimate tl;
            Node* fireNode = nullptr;
            tl.setup("mast_fire.csb");
            Point hornLoc;
            if (local) {
                fireNode = GameUtils::findDescendant(pnodeLocal, "node_fire");
            }
            else {
                // animName = "lanhaojiao";
                fireNode = GameUtils::findDescendant(pnodePeer, "node_fire");
                fireNode->setScaleY(-1);
            }

            fireNode->setVisible(true);
            tl.play(fireNode, true);
            appendGlobalBuffSig("images/shared/gongji_buf.png", local);

#if 0
            Point hornLoc;
            if (local) {
                fireNode = GameUtils::findDescendant(pnodeLocal, "node_fire");
                hornLoc = effect->getParent()->convertToNodeSpace(fireNode->getParent()->convertToWorldSpace(fireNode->getPosition()));
                hornLoc.y += 43;
                hornLoc.x += 50;
            }
            else {
                animName = "lanhaojiao";
                fireNode = GameUtils::findDescendant(pnodePeer, "node_fire");
                hornLoc = effect->getParent()->convertToNodeSpace(fireNode->getParent()->convertToWorldSpace(fireNode->getPosition()));
                fireNode->setScaleY(-1);

                hornLoc.y -= 5;
                hornLoc.x += 50;
            }

            fireNode->setVisible(true);


            effect->setPosition(hornLoc);
            effect->playAnimation(animName, false, true, [=](BattleObj*){
                appendGlobalBuffSig("images/shared/gongji_buf.png", local);
            });
#endif
        }
    }
}

void BattleScene::appendGlobalBuffSig(const std::string& path, bool local)
{
    Node* nodeParent = nullptr;
    Point targetPoint;
    if (local) {
        nodeParent = GameUtils::findDescendant(this->pnodeLocal, "Node_buffs");
        // targetPoint = getTopmost()->convertToNodeSpace(buffNode->getParent()->convertToWorldSpace(buffNode->getPosition()));
    }
    else {
        nodeParent = GameUtils::findDescendant(this->pnodePeer, "Node_buffs");
        // targetPoint = getTopmost()->convertToNodeSpace(buffNode->getParent()->convertToWorldSpace(buffNode->getPosition()));
    }

    auto sig = Sprite::create(path);

    Point pos = Point::ZERO;
    auto children = nodeParent->getChildren();
    if (!children.empty()) {
        auto last = *(children.rbegin());
        pos.x = (last->getPosition().x + last->getContentSize().width / 2 + sig->getContentSize().width / 2);
    }

    sig->setPosition(pos);
    nodeParent->addChild(sig);
}

void BattleScene::setCheckTerminating(bool checkTer)
{
    gameTerminating = checkTer;
}
bool BattleScene::getCheckTerminating()
{
    return 	this->gameTerminating;
}

void BattleScene::triggerGameEnd(void)
{
    if (this->gameTerminating || this->shaking || abilityMgr.hasAbilityRunning())
        return;

    auto localRealHP = localHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE);
    auto peerRealHP = peerHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE);
	auto localHeroDied = (::round((localRealHP - 0.5f)) <= 0)  && localRealHP == BattleData::getInstance()->queryData(VDI_HP,true);
	auto peerHeroDied  = (::round((peerRealHP - 0.5f )) <= 0)  && peerRealHP == BattleData::getInstance()->queryData(VDI_HP, false);

#if 0
    if (!this->forceKillingHero) {

        ////������������
        if (localHeroDied)
        {
            auto hero = BattleScene::thisObject()->getHero(true);
            luax_pvicall("equipmentDataInit.handleEquipidUnitDied", hero);

            peerHeroDied = BattleData::getInstance()->queryData(VDI_HP, false) <= 0;
            ////�з���������			
            if (peerHeroDied)
            {
                auto hero = BattleScene::thisObject()->getHero(false);
                luax_pvicall("equipmentDataInit.handleEquipidUnitDied", hero);
            }
        }
        else if (peerHeroDied) {
            auto hero = BattleScene::thisObject()->getHero(false);
            luax_pvicall("equipmentDataInit.handleEquipidUnitDied", hero);

            localHeroDied = BattleData::getInstance()->queryData(VDI_HP, true) <= 0;
            ////�з���������			
            if (localHeroDied)
            {
                auto hero = BattleScene::thisObject()->getHero(true);
                luax_pvicall("equipmentDataInit.handleEquipidUnitDied", hero);
            }
        }

        localHeroDied = BattleData::getInstance()->queryData(VDI_HP) <= 0;
        peerHeroDied = BattleData::getInstance()->queryData(VDI_HP, false) <= 0;
    }
#endif

    if (localHeroDied || peerHeroDied)
    {
        gameTerminating = true;

        if (peerHeroDied) {
            AchievementData::getInstance()->modifyData(AVDI_NormalSoldierKillPeerCic, 1, GL_TRUE);
        }

        BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, !localHeroDied);
    }
}

void BattleScene::handleRoundAnimationEnd(int timeLimit)
{

    if (this->battleStartupInfoResult > 0)
    {
        embattleTimer.settle(timeLimit, true);
    }

    if (abilityMgr.hasAbilityRunning())
    {
        embattleTimer.suspend();
    }
}

void BattleScene::initLight(void)
{
#if 0
    auto& winSize = Director::getInstance()->getWinSize();

#if 1
    m_light = new ens::ClightNode();
    m_light->autorelease();
    m_light->init(48);
    m_light->setPosition(ccp(winSize.width , winSize.height));
#endif
#if 0

    m_shadowRoot = new ens::C2DSoftShadowRoot();
    m_shadowRoot->autorelease();
    m_shadowRoot->init();
    addChild(m_shadowRoot);
    m_shadowRoot->setLight(m_light);
#endif
#if 0
    m_shadowObj = new C2DSoftShadowObj();
    m_shadowObj->autorelease();
    m_shadowObj->init(makeRegularPolygon(84, 8));
    m_shadowObj->setLight(m_light);
    m_shadowRoot->addObj(m_shadowObj);
    m_shadowObj->setPosition(ccp(winSize.width / 2, winSize.height / 2));

    m_shadowObj2 = new C2DSoftShadowObj();
    m_shadowObj2->autorelease();
    m_shadowObj2->init(makeRegularPolygon(20, 8));
    m_shadowObj2->setLight(m_light);
    m_shadowRoot->addObj(m_shadowObj2);
    m_shadowObj2->setPosition(ccp(winSize.width / 3 * 2, winSize.height / 3));

    m_shadowObj3 = new C2DSoftShadowObj();
    m_shadowObj3->autorelease();
    m_shadowObj3->init(makeRectPolygon(32, 47.5));
    m_shadowObj3->setLight(m_light);
    m_shadowRoot->addObj(m_shadowObj3);
    m_shadowObj3->setPosition(ccp(winSize.width / 2, winSize.height / 6 * 5));
#endif

#if 0
    m_sprite = CCSprite::create("demoRes/dish.png");
    addChild(m_sprite, 20);
    m_sprite->setRotation(360.0 / 8 / 2);
    m_sprite->setPosition(ccp(winSize.width / 2, winSize.height / 2));

    m_sprite2 = CCSprite::create("demoRes/chessPiece.png");
    addChild(m_sprite2, 20);
    m_sprite2->setPosition(ccp(winSize.width / 3 * 2, winSize.height / 3));

    m_sprite3 = CCSprite::create("demoRes/cigaretteBox.png");
    addChild(m_sprite3, 20);
    m_sprite3->setPosition(ccp(winSize.width / 2, winSize.height / 6 * 5));
#endif

    m_sprite_light = CCSprite::create("images/shared/light2.png");
    addChild(m_sprite_light, 20);
    m_sprite_light->setPosition(ccp(winSize.width, winSize.height));
    m_sprite_light->setScale(4.5*m_light->getR() / (m_sprite_light->getContentSize().width / 2));
    ccBlendFunc blendFunc = { GL_ONE, GL_ONE };
    m_sprite_light->setBlendFunc(blendFunc);
#endif
}

void BattleScene::initUI()
{
    this->pnodeLocal = GameUtils::findDescendant(mainui, TAG_BATTLE_PNODE_INFO);
    this->pnodePeer = GameUtils::findDescendant(mainui, TAG_BATTLE_PNODE_INFO_PEER);

    // auto countersParentNode = GameUtils::findDescendant(mainui, "Node_counters");
    // nodes_layout::vscr::setNodeRight(countersParentNode, 0);
    this->myTime = GameUtils::findDescendant(mainui, "my_time");
    this->youTime = GameUtils::findDescendant(mainui, "you_time");

    // �������Կؼ�
    this->progressTimer = nullptr; /*ProgressTimer::create(Sprite::create("images/shared/99803.png"));
    this->progressTimer->setReverseProgress(true);
    this->addChild(this->progressTimer);
    nodes_layout::centerNode(this->progressTimer);
    this->progressTimer->setPercentage(100);*/

    this->timelineTurnRound.setup("tl_turn_round.csb");

    this->timelineUIAnim.setup("la_fight_mainui_anim.csb");
    this->timelineUIAnimPeer.setup("la_fight_mainui_anim_peer.csb");
    this->timelineResult.setup("la_fight_win.csb");
    // this->timelineDefeat.setup("la_fight_defeated_anim.csb"); // unused: TODO: remove it.
#if 1


#endif
#if 0 // Old UI Version, To be removed in the future.
    this->timelineBarHP.setup("la_anim_xuetiao.csb");
    this->timelineBarMP.setup("la_anim_nengliangtiao.csb");
#endif

    this->timelineStep.setup("la_anim_bushu.csb");
    this->timelineCallOut.setup("la_anim_chubing.csb");
    this->timelineAbilTips.setup("la_anim_jinengtishi.csb");
    // this->timelineCic.setup("la_anim_zhugongtouxaing.csb");

#if 0 // Old UI Version, To be removed in the future.
    this->timelineBarHP.play(GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BAR_HP), true);
    this->timelineBarHP.play(GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BAR_HP), true);
    this->timelineBarMP.play(GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BAR_MP), true);
    this->timelineBarMP.play(GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BAR_MP), true);
#endif


#if 1 // �Զ���Ѫ���ٷֱ�֧��
    GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BAR_HP)->setVisible(false);
    GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BAR_HP)->setVisible(false);
    GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BAR_HP)->setTag(-1);
    GameUtils::findDescendant(pnodePeer, TAG_BATTLE_BAR_HP)->setTag(-1);

    // create local HP bar.
    Effect* hpBarBody = Effect::create("models/ui_effect/hp_tiao", 1.0f, EffectAlign::ALIGN_CENTER);
    hpBarBody->playAnimation("animation", true);
    hpBarBody->setOpacity(0);
    hpBarLocal = hpBarBody;
    // hpBarBody->alignCenter();

    /*Effect* hpBarToy = Effect::create("models/ui_effect/hp_tishi", 1.0f, EffectAlign::ALIGN_CENTER);
    hpBarToy->playAnimation("animation", true);*/

    auto hpBarParent = GameUtils::findDescendant(pnodeLocal, 283);
    UXProgressBar* hpBar = UXProgressBar::create(hpBarBody, hpBarParent->getContentSize(), nullptr);
    hpBar->setTag(TAG_BATTLE_BAR_HP);
    hpBarParent->addChild(hpBar);
    nodes_layout::centerNode(hpBar);
    // hpBar->setOpacity(0); // hpBar->setVisible(false);

    /// create peer HP bar
    hpBarBody = Effect::create("models/ui_effect/hp_tiao", 1.0f, EffectAlign::ALIGN_CENTER);
    hpBarBody->playAnimation("animation", true);
    hpBarBody->setOpacity(0);
    hpBarPeer = hpBarBody;
    // hpBarBody->alignCenter();

    /*hpBarToy = Effect::create("models/ui_effect/hp_tishi", 1.0f, EffectAlign::ALIGN_CENTER);
    hpBarToy->playAnimation("animation", true);*/

    hpBarParent = GameUtils::findDescendant(pnodePeer, 308);
    hpBar = UXProgressBar::create(hpBarBody, hpBarParent->getContentSize(), nullptr);
    hpBar->setTag(TAG_BATTLE_BAR_HP);
    hpBarParent->addChild(hpBar);
    nodes_layout::centerNode(hpBar);
    // hpBar->setOpacity(0); // hpBar->setVisible(false);

#endif

#if 1 // ���ܰٷֱȻҶ�֧��
    auto skillBtn = GameUtils::findDescendant(pnodeLocal, "Button_skill");
    skillBtn->setVisible(false);
    auto skillBtnPeer = GameUtils::findDescendant(pnodePeer, "Button_skill");
    skillBtnPeer->setVisible(false);

    auto skillIcon = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_skill"));
    auto skillIconPeer = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_skill"));


    /// ������Ч��
    auto barPadding = 8;
    auto bar = Effect::create("models/ui_effect/jinengtiao", 1.0f, EffectAlign::ALIGN_TOP);
    bar->setModelOffset(72 + 2);
    bar->playAnimation("animation", true);
    bar->setTag(TAG_UI_EFFECT_SKILL_BAR);
    auto barClipper = internalCreateClipper(Size(72, 72), TAG_UI_EFFECT_SKILL_BAR);
    barClipper->addChild(bar);
    skillBtn->addChild(barClipper);
    nodes_layout::centerNode(barClipper);
    // barClipper->setPositionY(barClipper->getPositionY() + barPadding);
    updateCustomBarPercent(bar, skillIcon, 0);

    auto barPeer = Effect::create("models/ui_effect/jinengtiao", 1.0f, EffectAlign::ALIGN_TOP);
    barPeer->setModelOffset(72 + 2);
    barPeer->playAnimation("animation", true);
    barPeer->setTag(TAG_UI_EFFECT_SKILL_BAR);
    barClipper = internalCreateClipper(Size(72, 72), TAG_UI_EFFECT_SKILL_BAR);
    barClipper->addChild(barPeer);
    skillBtnPeer->addChild(barClipper);
    nodes_layout::centerNode(barClipper);
    // barClipper->setPositionY(barClipper->getPositionY() + barPadding);

    updateCustomBarPercent(barPeer, skillIconPeer, 0);
    barPeer->setScaleY(-1);


#endif
    //this->barHPHeight = GameUtils::findDescendant(pnodeLocal, TAG_BATTLE_BAR_HP)->getContentSize().height;

    /// setup ui init-status
#if 1 // ��ʼ��UI�ؼ�״̬
    // hide detail layers
    this->setUIVisible(TAG_BATTLE_LAYER_DETAIL, false);
    this->setUIVisible(TAG_BATTLE_LAYER_DETAIL_PEER, false);

    auto mode = BattleData::getInstance()->getMode();

    // ���ý����ʼ��
    this->settingPanel = GameUtils::findDescendant(mainui, TAG_SETTINGS_PANEL);
    for (auto ctl : settingPanel->getChildren())
    {
        this->settingControlOffsets.push_back(ctl->getPositionY());
    }
#endif  

    // ˢ����ť
    GameUtils::uiRegister(mainui, TAG_BATTLE_BTN_FLUSH_SOLDIER, [this, mode](Ref*) {
        if (mode == BattleMode::PVE || mode == BattleMode::PHONY_PVP)
        {
            if (this->battleStartupInfoResult >= 1)
            {
                BattleData::getInstance()->flushSoldier();
            }
            else
            {
                BattleData::getInstance()->flushDramaSoldier();
                if (this->isDrama && this->isDramaClickButton)
                {
                    this->isDramaConditionOk = true;
                    this->isDramaClickButton = false;
                    BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
                }
            }
        }
        else if (mode >= BattleMode::PVP)
        {
            BattleData::getInstance()->flushSoldier();
        }

        this->localCtl->updateUserOpTime();

    });

    /// ͷ�����¼�

    /////// �ҷ���������
    auto skillPanel = GameUtils::findDescendant(mainui, "Panel_mySkillDes");
    //ע�����������¼�//�����Լ��볡����Ч��
    GameUtils::uiRegister(pnodeLocal, TAG_BATTLE_BTN_SKILL, [=](cocos2d::Ref*){
        if (!skillPanel->isVisible())
        {
            GameUtils::scaledShowUI(skillPanel);
            if (this->isDrama && this->isDramaClickButton)
            {
                this->isDramaConditionOk = true;
                this->isDramaClickButton = false;
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
            }
        }
        else
        {
            GameUtils::scaledHideUI(skillPanel);
        }
    });

    enableHideAny(skillPanel, [=](Node* ui){
        if (!this->isDrama)
        {
            GameUtils::scaledHideUI(ui);
        }
        return false;
    });

    GameUtils::uiRegister(skillPanel, "skill_lanuch_btn", [=](cocos2d::Ref*){ // 
        if (launchLocalCicAbil())
        {
            this->localCtl->updateUserOpTime();

            GameUtils::scaledHideUI(skillPanel);
            if (this->isDrama && this->isDramaClickButton)
            {
                this->isDramaConditionOk = true;
                this->isDramaClickButton = false;
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
            }
        }
    });

    ////// �Է���������
    auto skillPanelPeer = GameUtils::findDescendant(mainui, "Panel_yourSkillDes");
    //ע�����������¼�//�����Լ��볡����Ч��
    GameUtils::uiRegister(pnodePeer, TAG_BATTLE_BTN_SKILL, [=](cocos2d::Ref*){
        // ((Sprite*)nullptr)->setVisible(false); // bugly����

        if (!skillPanelPeer->isVisible())
            GameUtils::scaledShowUI(skillPanelPeer);
        else
            GameUtils::scaledHideUI(skillPanelPeer);
    });

    enableHideAny(skillPanelPeer, [](Node* ui){
        GameUtils::scaledHideUI(ui);
        return false;
    });

    ///// װ��UI����
    auto localEquipLa = GameUtils::findDescendant(mainui, "Panel_myEquipDes");
    auto peerEquipLa = GameUtils::findDescendant(mainui, "Panel_yourEquipDes");
    /// �ҷ�װ������
    GameUtils::uiRegister(pnodeLocal, TAG_BATTLE_BTN_EQUIP, [=](cocos2d::Ref*){
        if (!localEquipLa->isVisible())
            GameUtils::scaledShowUI(localEquipLa);
        else
            GameUtils::scaledHideUI(localEquipLa);
    });
    /// �з�װ������
    GameUtils::uiRegister(pnodePeer, TAG_BATTLE_BTN_EQUIP, [=](cocos2d::Ref*){
        if (!peerEquipLa->isVisible())
            GameUtils::scaledShowUI(peerEquipLa);
        else
            GameUtils::scaledHideUI(peerEquipLa);
    });

    // ����װ������UI������⴦����
    enableHideAny(localEquipLa, [](Node* ui){
        GameUtils::scaledHideUI(ui);
        return false;
    });
    enableHideAny(peerEquipLa, [](Node* ui){
        GameUtils::scaledHideUI(ui);
        return false;
    });

    // ע������غ�ȷ�϶Ի�����ʾ״̬
    GameUtils::uiRegister(mainui, { (int)TAG_BATTLE_BTN_ROUNDOUT, (int)TAG_BATTLE_BTN_ROUNDOUT_NO }, [this](cocos2d::Ref*){
        if (!getLocalController()->movingUnits.empty())
            return;

        changeUIVisibleCovering(TAG_BATTLE_DLG_ROUNDOUT);
        if (this->isDrama && this->isDramaClickButton)
        {
            this->isDramaConditionOk = true;
            this->isDramaClickButton = false;
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
        }
    });

    // ע������غ�ȷ�϶Ի�����ʾ״̬
    GameUtils::uiRegister(mainui, TAG_BATTLE_BTN_ROUNDOUT_YES, [this](cocos2d::Ref*){

        changeUIVisibleCovering(TAG_BATTLE_DLG_ROUNDOUT);

        /// ���ûغϽ�����ť
        setUIEnabled(TAG_BATTLE_BTN_ROUNDOUT, false);

        /// ����ħ��
        auto step = BattleData::getInstance()->queryData(VDI_STEP);
        auto mpa = luax_pvicall("formula.mpa.giveupRound", step);

        this->localHero->viewTipsAboutValue(mpa, "MP");
        //this->localHero->modifyMana(mpa);
        BattleData::getInstance()->modifyData(VDI_MP, mpa);

        BattleData::getInstance()->notifyTurnOver();

        if (this->isDrama && this->isDramaClickButton)
        {
            this->isDramaConditionOk = true;
            this->isDramaClickButton = false;
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
        }

        localCtl->setAutoControl(false);
        this->cancelAutoControl(localCtl);

#if CC_TARGET_PLATFORM == CC_PLATFORM_WIN32
        xmld::document& stepRecorder = localCtl->stepRecorder;
        auto stepsd = stepRecorder.root()["steps"];
        auto stepd = stepsd.add_child("step");
        stepd.set_attribute_value("type", "giveup");
        stepRecorder.save(true);
#endif
    });

    // ����Ϣ��ť
    GameUtils::uiRegister(mainui, TAG_BATTLE_BTN_SHOW_IME, [this](cocos2d::Ref* obj){
        /// TODO: ���η�����Ϣʱ��������5s

        auto smsButton = dynamic_cast<ui::Button*>(obj);
        auto inputboxbg = GameUtils::findDescendant(mainui, TAG_BATTLE_IMG_INPUT_BACKG);
        auto inputbox = dynamic_cast<ui::TextField*>(inputboxbg->getChildByTag(TAT_BATTLE_INPUT_SMS));
        if (!inputboxbg->isVisible())
        { // ���������
            smsButton->loadTextureNormal("res/e52ec598-ca48-4ba9-4ac7539fc639.png");

            inputboxbg->setVisible(true);
            // inputbox->setString(iconvw::g2u("�ø�����߰ɣ�С��å!"));
            CCRUNONGL([inputbox, inputboxbg]{
                // inputbox->setAttachWithIME(inputboxbg->isVisible());
                inputbox->attachWithIME();
            });
        }
        else
        { //  ȷ�Ϸ��Ͳ��ر������
            smsButton->loadTextureNormal("res/e52ec598-ca48-4ba9-4ac7539fc63f.png");

            inputboxbg->setVisible(false);
            inputbox->setDetachWithIME(true);
            auto& content = inputbox->getString();
            if (!content.empty())
            {
                this->showSMSDialog(inputbox->getString(), true);
                BattleData::getInstance()->sendSMS(inputbox->getString());
            }
            else {
                auto str = GameUtils::getStringForKey("roar");
                this->showSMSDialog(iconvw::g2u(str), true);
            }
        }
    });


    this->initSettingsUI();
}

void BattleScene::enableHideAny(cocos2d::Node* uiRoot, int tag, const std::function<bool(Node*)>& hideFunc)
{
    enableHideAny(GameUtils::findDescendant(uiRoot, tag));
}

void BattleScene::enableHideAny(cocos2d::Node* ui, const std::function<bool(Node*)>& hideFunc)
{
    this->nodesHideAny.insert(std::make_pair(ui, hideFunc));
}

void BattleScene::enableHideAny2(cocos2d::Node* ui, const std::function<bool(Node*)>& hideFunc)
{
    this->nodesHideAny2.insert(std::make_pair(ui, hideFunc));
}

void BattleScene::registerEventHandlers(void)
{
    /// ��ʼ����
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_STARTING, [this](const BattleEventParam&){
        // luax_pvcall("bext.onAttackingStart", backg, getLowestDisplay(), mainui);
        embattleTimer.suspend();
        AIDriver::getInstance()->deactive();
        this->stopAllUIEvents(Color4B(0, 0, 0, 0), false);
        this->getLocalController()->cancelSelectedSoldier(true);
    });

    /// ��������
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_END, [this](const BattleEventParam&){
        // luax_pvcall("bext.onAttackingEnd", backg, getLowestDisplay(), mainui);
        embattleTimer.resume();
        AIDriver::getInstance()->active();
        this->resumeAllUIEvents();
    });

    /// ��Ϸ�����¼�
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_GAME_END, [this](const BattleEventParam& param){
        this->onGameEnd(param.bVal);
    });

    /// ���������¼�
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_REWARD_STEP, [this](const BattleEventParam& param){
        BattleData::getInstance()->modifyData(VDI_OPTIME, 5, param.bVal); // TODO: config time rewards
        // createTextTagForNormal("TIME+%d", 5);
    });

    /// ���鿪ʼ
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_DRAMA_BATTLE_START, [this](const BattleEventParam& param){
        luax_pvcall("dbext.onDramaGuideStart");
    });

    /// ����ָ��
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_DRAMA_GUIDE, [this](const BattleEventParam& param){
        luax_pvcall("dbext.onDramaGuide", backg, mainui, param.bVal);
    });

    /// ������;�����ؼ�
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_DRAMA_GUIDE_BACK, [this](const BattleEventParam& param){
        luax_pvcall("dbext.onDramaGuideBack");
    });

    /// �������
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_DRAMA_GUIDE_DELETE, [this](const BattleEventParam& param){
        luax_pvcall("dbext.onDramaGuideDelete", backg, mainui);
    });

    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_STEP_REDUCE, [this](const BattleEventParam&){
        /*this->timelineStep.setup("la_anim_bushu.csb");
        this->timelineCallOut.setup("la_anim_chubing.csb");
        this->timelineAbilTips.setup("la_anim_jinengtishi.csb");
        this->timelineCic.setup("la_anim_zhugongtouxaing.csb");*/

        auto tip = CSLoader::createNode("la_anim_bushu.csb");
        auto button = GameUtils::findDescendant(mainui, TAG_BATTLE_BTN_ROUNDOUT);
        button->addChild(tip);
        tip->setPosition(button->getContentSize().width / 2, button->getContentSize().height / 2);
        timelineStep.playOnce(tip);
    });

    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_IDLES_INCREASE, [this](const BattleEventParam&){
        auto tip = CSLoader::createNode("la_anim_chubing.csb");
        auto button = GameUtils::findDescendant(mainui, TAG_BATTLE_BTN_FLUSH_SOLDIER);
        button->addChild(tip);
        tip->setPosition(button->getContentSize().width / 2, button->getContentSize().height / 2);
        timelineCallOut.playOnce(tip);
    });

    /// Auto�����ɼ�״̬����
    localCtl->onAutoStateChanged = [this](bool bVal){
        GameUtils::findDescendant(pnodeLocal, "Image_hero_tx")->setVisible(bVal);
    };

    //peerCtl->onAutoStateChanged = [this](bool bVal){
    //    GameUtils::findDescendant(pnodePeer, "Image_hero_tx")->setVisible(bVal);
    //};
}

void BattleScene::updateRoundsUI(void)
{
    auto eyeL = GameUtils::findDescendant(mainui, TAG_BATTLE_DLG_SETTINGS);
    auto lblRounds = dynamic_cast<ui::Text*>(eyeL->getChildByName("Text_round"));

    char svalue[128];
    auto str = GameUtils::getStringForKey("rounds");
    sprintf(svalue, "%d", BattleData::getInstance()->getRounds());
    lblRounds->setText(svalue);
}

void BattleScene::switchEyeStatus(ui::Button* ui)
{
    if (ui == nullptr)
    {
        ui = dynamic_cast<ui::Button*>(GameUtils::findDescendant(mainui, TAB_SETTINGS_BTN_VIEW_ANY_NEW));
    }

    bool visible = this->changeUIVisible(TAG_BATTLE_DLG_SETTINGS);
    if (visible) {
        // ui->setBrightStyle(ui::Widget::BrightStyle::HIGHLIGHT);
        this->foreachAllUnits([](Unit* u){
            u->onShowShieldLabel();
        });
        localHero->showLeaderLabel();
        peerHero->showLeaderLabel();

        BattleData::getInstance()->setEyeOpened(true);

        updateRoundsUI();
    }
    else {
        // ui->setBrightStyle(ui::Widget::BrightStyle::NORMAL);
        this->foreachAllUnits([](Unit* u){
            u->onHideShieldLabel();
        });
        localHero->hideLeaderLabel();
        peerHero->hideLeaderLabel();

        BattleData::getInstance()->setEyeOpened(false);
    }

    ui->getChildByName("light")->setVisible(visible);
}

void BattleScene::initSettingsUI(void)
{
#if 1

    auto newSettings = GameUtils::findDescendant(mainui, TAG_BATTLE_LA_NEW_SETTINGS);

    GameUtils::uiRegister(newSettings, [newSettings](cocos2d::Ref*){
        newSettings->setVisible(false);
    });

    // չ������������
    GameUtils::uiRegister(mainui, std::vector < int > { TAB_BATTLE_BTN_SETTINGS, TAG_BATTLE_BTN_CLOSE_SETTINGS }, [this](cocos2d::Ref* sender){
        this->changeUIVisible(TAG_BATTLE_LA_NEW_SETTINGS);
#if 0
        auto button = dynamic_cast<ui::Button*>(sender);

        if (this->settingPanel->isVisible())
        {
            this->hideSettingPanelAnimated(button);
        }
        else {
            this->showSettingPanelAnimated(button);
        }
#endif
        if (this->isDrama && this->isDramaClickButton)
        {
            this->isDramaConditionOk = true;
            this->isDramaClickButton = false;
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
        }


    });

    /// ��ʾʿ������ֵ(����)
    GameUtils::uiRegister(mainui, TAB_SETTINGS_BTN_VIEW_ANY_NEW, [=](cocos2d::Ref* sender){
        auto button = dynamic_cast<ui::Button*>(sender);
        switchEyeStatus(button);

        // newSettings->setVisible(false);
    });

    // �һ���ť
    GameUtils::uiRegister(mainui, TAG_SETTINGS_BTN_AUTO_NEW, [=](cocos2d::Ref* sender){
        auto button = dynamic_cast<ui::Button*>(sender);

        if (!this->localCtl->isAutoControl())
        { // ����AI
            BattleScene::thisObject()->getLocalController()->cancelSelectedSoldier();

            setAllUserButtonsEnabled(false);

            // updataUIVisibleText(TAG_BATTLE_AUTO_CONTROL, iconvw::g2u("�ֶ�"));
            // button->getChildByName("light")->setVisible(true); // ->setBrightStyle(ui::Widget::BrightStyle::HIGHLIGHT);

            this->localCtl->setAutoControl(true);

            if (this->localCtl->isActive())
            {
                this->localField->disableControl(); //���ش����¼��ĵĽ�ֹ����
                this->startAutoControl(this->localCtl);
            }
        }
        else
        { // ����AI
            // button->setBrightStyle(ui::Widget::BrightStyle::NORMAL);
            // updataUIVisibleText(TAG_BATTLE_AUTO_CONTROL, iconvw::g2u("�Զ�"));
            localCtl->setAutoControl(false);

            if (BattleData::getInstance()->isLocalOperating())
                setAllUserButtonsEnabled(true);
        }

        button->getChildByName("light")->setVisible(this->localCtl->isAutoControl());

        // newSettings->setVisible(false);
    });

    /// Ͷ����ť
    GameUtils::uiRegister(mainui, TAG_SETTINGS_BTN_GIVE_UP_NEW, [=](cocos2d::Ref*){
        handleGiveup();

        newSettings->setVisible(false);
    });

    BattleEventDispatcher::getInstance()->addEventListener(ON_BACK_PRESS, [=](const BattleEventParam&){
        if (this->battleStartupInfoResult > 0)
        {
            handleGiveup(true);
        }
        // newSettings->setVisible(false);
    });

    // ����ƶ�
    auto btnOpChanger = dynamic_cast<ui::Button*>(GameUtils::findDescendant(mainui, TAG_SETTINGS_BTN_OPM_NEW));
    auto updateOpButton = [=](ui::Button* button){
        if (BattleData::getInstance()->isClickOpmode())
        {
            button->setBrightStyle(ui::Widget::BrightStyle::HIGHLIGHT);
        }
        else {
            button->setBrightStyle(ui::Widget::BrightStyle::NORMAL);
        }

        button->getChildByName("light")->setVisible(BattleData::getInstance()->isClickOpmode());

        if (this->isDrama && this->isDramaClickButton)
        {
            this->isDramaConditionOk = true;
            this->isDramaClickButton = false;
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE);
        }

        localCtl->cancelSelectedSoldier();
    };
    updateOpButton(btnOpChanger);
    GameUtils::uiRegister(btnOpChanger, [=](cocos2d::Ref* sender){
        BattleData::getInstance()->setOpmode(BattleData::getInstance()->isQuickOpmode() ? OPMODE_CLICK : OPMODE_QUICK);

        auto button = dynamic_cast<ui::Button*>(sender);
        updateOpButton(button);

        // newSettings->setVisible(false);
    });
#endif
}

void BattleScene::handleGiveup(bool showConfirm)
{
    BattleData::getInstance()->setDataLocked(false);

    if (!this->gameRunning)
        return;

    // ��ֹ���Ͷ��
    if (this->forceKillingHero)
        return;

    if (showConfirm) { // old version: show confirm dialog
        if (confirmDlg != nullptr)
            return;

        if (!BattleData::getInstance()->isPVE()) {
            auto str = GameUtils::getStringForKey("exitcur");
            confirmDlg = GameUtils::showDialog(iconvw::g2u(str), [=](){
                CC_SAFE_RELEASE_NULL(confirmDlg);

                auto str = GameUtils::getStringForKey("run");
                BattleData::getInstance()->sendSMS(iconvw::g2u(str));

                // TODO: ����֧������ʱʧ�ܻص�,
                messages::GiveupReq msg;
                msg.reserved = 0;

                /// TODO: move to battle data.
                NetworkManager::getInstance()->registerCallback(CID_BATTLE_GIVEUP_RESP, [this](MsgBase* msg){
                    auto detail = dynamic_cast<messages::GiveupResp*>(msg);
                    if (_IsNull(detail))
                        return;

                    if (detail->succeed)
                    {
                        /*auto str = GameUtils::getStringForKey("hissucc");
                        createTextTagForNormal(iconvw::g2u(str).c_str());*/

                        killHero(true);
                        BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [](const BattleEventParam&){
                            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END);
                        }, true);
                    }
                    else {
                        /*auto str = GameUtils::getStringForKey("runfail");
                        createTextTagForError(iconvw::g2u(str).c_str());*/
                    }

                    dopp->postDelayedOperation([]{
                        NetworkManager::getInstance()->unregisterCallback({ CID_BATTLE_GIVEUP_RESP });
                    });

                });

                NetworkManager::getInstance()->sendMsg(msg);
            }, [=]{ CC_SAFE_RELEASE_NULL(confirmDlg);  });
        }
        else {
            auto str = GameUtils::getStringForKey("exitcur");
            confirmDlg = GameUtils::showDialog(iconvw::g2u(str), [=](){
                CC_SAFE_RELEASE_NULL(confirmDlg);

                killHero(true);

                if (this->isDrama)
                {
                    BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE_DELETE);
                }

                BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [](const BattleEventParam&){
                    BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END);
                }, true);

            }, [=]{
                CC_SAFE_RELEASE_NULL(confirmDlg);
                if (this->isDrama)
                {
                    BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE_BACK);
                }
            });

            if (this->isDrama)
            {
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE_BACK);
            }
        }

        if (confirmDlg != nullptr)
            confirmDlg->retain();
    }
    else {
        if (!BattleData::getInstance()->isPVE())
        {
            auto str = GameUtils::getStringForKey("run");
            BattleData::getInstance()->sendSMS(iconvw::g2u(str));

            // TODO: ����֧������ʱʧ�ܻص�,
            messages::GiveupReq msg;
            msg.reserved = 0;

            /// TODO: move to battle data.
            NetworkManager::getInstance()->registerCallback(CID_BATTLE_GIVEUP_RESP, [this](MsgBase* msg){
                auto detail = dynamic_cast<messages::GiveupResp*>(msg);
                if (_IsNull(detail))
                    return;

                if (detail->succeed)
                {
                    /*auto str = GameUtils::getStringForKey("hissuc");
                    createTextTagForNormal(iconvw::g2u(str).c_str());*/
                    killHero(true);
                }
                else {
                    /*auto str = GameUtils::getStringForKey("his");
                    createTextTagForError(iconvw::g2u(str).c_str());*/
                }

                dopp->postDelayedOperation([]{
                    NetworkManager::getInstance()->unregisterCallback({ CID_BATTLE_GIVEUP_RESP });
                });

            });

            NetworkManager::getInstance()->sendMsg(msg);
        }
        else {
            killHero(true);

            if (this->isDrama)
            {
                BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_DRAMA_GUIDE_DELETE);
            }
            // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END);
        }
    }
}

bool BattleScene::launchLocalCicAbil(int cx)
{
    if (!checkAllowLaunchCicAbil(true))
        return false;

    luax_pvcall("audiol.play", localHero->getId());

    hideTextTag();
    this->embattleTimer.resume();
    // BattleData::getInstance()->notifyCicLaunchAbil(cx);
    launchCicAbil(localHero, cx);

    if (BattleData::getInstance()->modifyData(VDI_MP, -100) < 100) {
        // this->setUIEnabled(TAG_BATTLE_BTN_USE_SKILL, false);
    }

    AchievementData::getInstance()->modifyData(AVDI_LaunchCicAbilCount, 1, GL_TRUE);

    return true;
}

//�з�֪ͨ���Ŷ���
void BattleScene::launchPeerCicAbilBefore(int cx)
{
    auto op = [=](){
        luax_pvcall("audiol.play", peerHero->getId());
        cocos2d::log("***************peer create abil  ************");
        luax_pvcall("abilityDispatch.handleMasterSkillLaunchBefore", peerHero);
        return true;
    };
    peerCtl->pushNetworkOtherFunc(op);
}
//�з�֪ͨ��������
void BattleScene::launchPeerCicAbilRight(int cx)
{
    auto op = [=](){
        if (!checkAllowLaunchCicAbil(false))
            return false;
        cocos2d::log("***************peer launch abil  ************");
        luax_pvcall("abilityDispatch.handleMasterSkillLunchRight", peerHero, cx);
        BattleData::getInstance()->modifyData(VDI_MP, -100, false);
        // AchievementData::getInstance()->modifyData(AVDI_LaunchCicAbilCount, 1, GL_TRUE); // ͳ�ƴ���ֻͳ�Ʊ����ͷż��ܴ���
        return true;
    };
    peerCtl->pushNetworkOtherFunc(op);
}


void BattleScene::launchPeerCicAbil(int cx)
{
    if (!checkAllowLaunchCicAbil(false))
        return;
    launchCicAbil(peerHero, cx);
    BattleData::getInstance()->modifyData(VDI_MP, -100, false);

    // AchievementData::getInstance()->modifyData(AVDI_LaunchCicAbilCount, 1, GL_TRUE);
}
//cx==-1
void BattleScene::launchCicAbil(Hero* hero, int cx)
{
    luax_pvcall("abilityDispatch.handleMasterSkillLunch", hero, cx);
}

bool BattleScene::checkAllowLaunchCicAbil(bool local)
{
    if (local && BattleData::getInstance()->queryData(VDI_MP, local) < 100)
        return false;

    if (/*cicAbilLaunching || */this->abilityMgr.hasAbilityRunning())
        return false;

    cicAbilLaunching = true;

    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ATTACKING_END, [=](const BattleEventParam& param){
        if (static_cast<Ability*>(param.ptrVal)->isCicAbil())
            cicAbilLaunching = false;
    }, true);

    return true;
}

void BattleScene::followSoldier(Soldier* s)
{
}

void BattleScene::showSettingPanelAnimated(ui::Button* button)
{
    if (button == nullptr)
        button = dynamic_cast<ui::Button*>(GameUtils::findDescendant(this->mainui, TAB_BATTLE_BTN_SETTINGS));

    button->runAction(RotateTo::create(0.15f, 0));

    settingPanel->setVisible(true);
    auto controls = this->settingPanel->getChildren();
    for (size_t i = 0; i < this->settingControlOffsets.size(); ++i)
    {
        auto ctl = controls.at(i);
        ctl->stopAllActions();
        ctl->runAction(MoveTo::create(0.2f, Point(ctl->getPositionX(), this->settingControlOffsets[i])));
    }
}

void BattleScene::hideSettingPanelAnimated(ui::Button* button)
{
    if (button == nullptr)
        button = dynamic_cast<ui::Button*>(GameUtils::findDescendant(this->mainui, TAB_BATTLE_BTN_SETTINGS));

    button->runAction(RotateTo::create(0.15f, 180));

    auto controls = this->settingPanel->getChildren();
    static auto counter = 0;
    counter = controls.size();
    for (size_t i = 0; i < this->settingControlOffsets.size(); ++i)
    {
        auto ctl = controls.at(i);
        ctl->stopAllActions();
        ctl->runAction(
            Sequence::create(MoveTo::create(0.2f, Point(ctl->getPositionX(), 0)),
            cocos2d::CallFunc::create([this]{ if (--counter <= 0) settingPanel->setVisible(false);  }),
            nullptr
            ));
    }
}

void BattleScene::killHero(bool local)
{
    this->forceKillingHero = true;

    if (local)
    {
        this->localHero->hurt(this->localHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE));
    }
    else{
        this->peerHero->hurt(this->peerHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE));
    }
}

void BattleScene::shake(bool local)
{
    if (this->shaking)
        return;

    this->shaking = true;
    auto shakeAction = cocos2d::Sequence::create(
        cocos2d::MoveBy::create(0.1f, Point(5, 10)),
        cocos2d::MoveBy::create(0.1f, Point(-10, -20)),
        cocos2d::MoveBy::create(0.1f, Point(5, 15)),
        cocos2d::MoveBy::create(0.1f, Point(0, -5)), CallFunc::create([this]{
        this->shaking = false;
        // BattleEventDispatcher::getInstance()->dispatchEvent(ON_SHAKE_END);
    }), nullptr);
    this->backg->runAction(shakeAction);

#if 0
    if (userdef->get("vibrate", true).asBool())
        cocos2d::Device::vibrate(0.2);
#endif

    if (local) {
        this->timelineUIAnim.play(pnodeLocal, false, "mcic");
    }
    else {
        this->timelineUIAnimPeer.play(pnodePeer, false, "pcic");
    }

    if (localHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE) <= 0 || peerHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE) <= 0)
        return;

    if (BattleData::getInstance()->getRounds() < luax_vgetval("deploy.urgent_rounds", 30))
    { // �������ģʽ��������Ҷ��Ч
        /*auto shakeAnim = Effect::create("models/ui_effect/map1_effect1");
        shakeAnim->setPosition(Point(backg->getContentSize().width / 2, backg->getContentSize().height / 3));
        this->backg->addChild(shakeAnim);
        shakeAnim->playAnimation("zhenpingluoye", false, true, [this](BattleObj*){
        this->effectLeaf = nullptr;
        });*/

        luax_pvcall("bext.handleScreenShake", backg, localHero->getId());
    }

    experimental::AudioEngine::play2d("sounds/stone_destroy");

    // ���
    if (local) {
        localAvatarTLA.play("hurt", false, [=]{
            localAvatarTLA.play("idle", true);
        });
    }
    else {
        peerAvatarTLA.play("hurt", false, [=]{
            peerAvatarTLA.play("idle", true);
        });
    }
}


void BattleScene::onEnter(void)
{
    cocos2d::Layer::onEnter();

    s_battleObject = this;

    // ֪ͨ����������ս��
    messages::EnterBattleSceneNotify notify;
    notify.mode = BattleData::getInstance()->getMode();
    NetworkManager::getInstance()->sendMsg(notify);



    // ����ս��������Ч
    auto soundId = 200 + localHero->getId() / 10000;
    luax_pvcall("audiol.stopAll");
    backgroundMusicId = luax_pvicall("audiol.play", soundId);

    if (this->battleStartupInfoResult < 1) {
        localField->setVisible(false);
        peerField->setVisible(false);
        normalEffectLa->setVisible(false);
    }

    mainui->setCascadeOpacityEnabled(true);
    mainui->setOpacity(0);
    pnodeLocal->setCascadeOpacityEnabled(true);
    pnodePeer->setCascadeOpacityEnabled(true);

    auto localWepaonButton = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodeLocal, "Button_weapon"));
    auto peerWeaponButton = dynamic_cast<ui::Button*>(GameUtils::findDescendant(pnodePeer, "Button_weapon"));

    localWepaonButton->setCascadeOpacityEnabled(true);

#if 1
    /*this->mainui->setOpacity(0);
    this->backg->setOpacity(0);*/
    luax_pvcall("bext.playFireAnimation", localHero->getId(), BattleData::getInstance()->getBattleStartupInfoResult() < 1);
    BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_ENTER_ANIMATION_END, [=](const BattleEventParam&){
        BattleData::getInstance()->setRounds(1);

        if (this->battleStartupInfoResult < 1) {
            localField->setVisible(true);
            peerField->setVisible(true);
            normalEffectLa->setVisible(true);
        }

        localWepaonButton->setEnabled(localWeaponEnabled);
        peerWeaponButton->setEnabled(peerWeaponEnabled);

        GameUtils::findDescendant(pnodeLocal, "Button_skill")->setVisible(true);
        GameUtils::findDescendant(pnodePeer, "Button_skill")->setVisible(true);

        auto action = cocos2d::FadeIn::create(1);
        this->mainui->runAction(action->clone());
        this->backg->runAction(action->clone());

        this->hpBarLocal->setVisible(true);
        this->hpBarLocal->runAction(action->clone());
        this->hpBarPeer->setVisible(true);
        this->hpBarPeer->runAction(action);

        auto resumeInfo = BattleData::getInstance()->getBattleResumeInfo();
        if (resumeInfo == nullptr)
        {
            this->startGame();
        }
        else {
            this->resumeGame(resumeInfo);
        }

        // enable game logic
        gameLogicBlocking = false;

        if (!isDrama) {
            BattleEventDispatcher::getInstance()->addEventListener(BattleEventType::ON_SOLDIER_INITIALIZED, [=](const BattleEventParam&){
                if (bLocalFirst) {
                    this->onTurnLocalRound(true);
                }
                else {
                    this->onTurnPeerRound(true);
                }
            }, true);
        }
        else {
            if (bLocalFirst) {
                this->onTurnLocalRound(true);
            }
            else {
                this->onTurnPeerRound(true);
            }
        }

    }, true);
#endif

#if 0
    /// �볡����
    CCUniquePtr<Effect> uiAnmiation(Effect::newObject("models/ui_effect/map1_start", 1.0f, EffectAlign::ALIGN_CENTER)); // SkeletonCache::getInstance()->addData("battle/anim/senlin.json", "battle/anim/senlin.atlas", 1.0f);
    getLowestDisplay()->addChild(uiAnmiation.get());
    nodes_layout::centerNode(uiAnmiation.get());

    uiAnmiation->getSkeletonImpl()->setTimeScale(1.5f);

    uiAnmiation->playAnimation("animation", false, true, [=](BattleObj*){
    });
    uiAnmiation->addEventListener("ev_start", [=](Node*){

        if (this->battleStartupInfoResult < 1) {
            localField->setVisible(true);
            peerField->setVisible(true);
            normalEffectLa->setVisible(true);
        }

        localWepaonButton->setEnabled(localWeaponEnabled);
        peerWeaponButton->setEnabled(peerWeaponEnabled);

        GameUtils::findDescendant(pnodeLocal, "Button_skill")->setVisible(true);
        GameUtils::findDescendant(pnodePeer, "Button_skill")->setVisible(true);

        auto action = cocos2d::FadeIn::create(0.25);
        this->mainui->runAction(action->clone());

        this->hpBarLocal->setVisible(true);
        this->hpBarLocal->runAction(action->clone());
        this->hpBarPeer->setVisible(true);
        this->hpBarPeer->runAction(action);

        // add lighting
        effectLighting = Effect::create("models/ui_effect/map1_effect2");
        effectLighting->setPosition(Point(backg->getContentSize().width / 2, backg->getContentSize().height / 2));
        this->backg->addChild(effectLighting);
        effectLighting->playAnimation("animation", true);
        effectLighting->setTimeScale(0);

        std::shared_ptr<CountdownTimer> lightDelayTimer(new CountdownTimer());
        lightDelayTimer->settle(5, false, [=]{
            effectLighting->setTimeScale(1);
            removeTimer(lightDelayTimer.get());
        });
        this->addTimer(lightDelayTimer.get());

        // add forground
        auto foreg = Sprite::create("images/shared/maps/map1_foreimg.png");
        foreg->setTag(TAG_BATTLE_FOREGROUND);
        getBackgnd()->addChild(foreg);
        nodes_layout::centerNode(foreg);

        // enable game logic
        gameLogicBlocking = false;
    });
#endif

#if 0 // �رշŴ���
    // zoomin zoomout
    EventDispatcherEx::getInstance()->addMultiTouchMovedListener([this](const Point& mid, float distance){
        auto& mapSize = this->backg->getContentSize();

        /// calc illegal map new scale
        auto scaleDistance = distance / ((mapSize.width + mapSize.height) / 2);
        auto nowScale = backg->getScale();
        auto newScale = cocos2d::clampf(nowScale + scaleDistance, 1.0f, 10.0f);


        if (newScale != nowScale) {

            auto newAnchorPointInPoints = this->backg->convertToNodeSpace(mid);
            auto& anchorPointInPoints = this->backg->getAnchorPointInPoints();

            /// udpate map anchor point without display position moved.
            auto offset = (newAnchorPointInPoints - anchorPointInPoints)/* * nowScale */;
            this->backg->setPosition(this->backg->getPosition() + offset);

            auto newAnchorPoint = Point(newAnchorPointInPoints.x / mapSize.width, newAnchorPointInPoints.y / mapSize.height);
            this->backg->setAnchorPoint(newAnchorPoint);

            /// sets scale
            this->backg->setScale(newScale);
        }
    });
#endif

    EventDispatcherEx::getInstance()->addClickListener([this](const Point& worldp, int /*clickCount*/){
        for (auto& hideAny : nodesHideAny)
        {
            if (hideAny.first->isVisible())
                hideAny.second(hideAny.first);
        }
    });

    // optimize #22: �����������������رտ�������
    this->backgDispatch->addClickListener([this](const Point& worldp, int count){
        switch (count)
        {
        case 2:
            if (!nodes_utility::containsPoint(this->localField, worldp) && !nodes_utility::containsPoint(this->peerField, worldp))
            {
                switchEyeStatus();
            }
            break;
        case 6:
            openCheat();
            break;
        }

        for (auto& hideAny : nodesHideAny)
        {
            if (hideAny.first->isVisible())
                hideAny.second(hideAny.first);
        }
    });

    effectLeaf = nullptr; // unused TODO: remove it.
    /*leafTimer.settle(30, true, [this](){
        effectLeaf = Effect::create("models/ui_effect/map1_effect1");
        effectLeaf->setPosition(Point(backg->getContentSize().width / 2, backg->getContentSize().height / 3));
        this->backg->addChild(effectLeaf);
        effectLeaf->playAnimation("luoye", false, true, [this](BattleObj*){
        this->effectLeaf = nullptr;
        });
        });*/

    // hideSettingPanelAnimated
    this->hideSettingPanelAnimated();


    // memory warnings
    TextureCache::getInstance()->removeUnusedTextures();
}

void BattleScene::handleEnterUrgentMode()
{
    leafTimer.suspend();

    if (this->effectLighting != nullptr) {
        this->effectLighting->removeFromParent();
        this->effectLighting = nullptr;
    }

    if (this->effectLeaf != nullptr) {
        this->effectLeaf->removeFromParent();
        this->effectLeaf = nullptr;
    }
}

//��������Ϊ��ǩ ֵ �Ƿ���ʾ Ѫ����ʾֵ
void BattleScene::updateUIValue(int tag, float value, /*bool hideZero,*/ bool forMaxVal)
{
    bool localui = true;
    ui::Text* label = nullptr;
    ui::TextAtlas* labelAtlas = nullptr;
    ui::LoadingBar* bar = nullptr;
    ui::Layout* simBar = nullptr;
    Node* ui = nullptr;
    Node* pnode = nullptr;
    Node* mnode = nullptr;
    switch (tag)
    {
    case TAG_BATTLE_LBL_HP_PEER:
    case TAG_BATTLE_LBL_MAX_HP_PEER:
    case TAG_BATTLE_BAR_HP_PEER:
        /* case TAG_BATTLE_LBL_MP_PEER:*/
    case TAG_BATTLE_BAR_MP_PEER:
    case TAG_BATTLE_PROG_SKILL_PEER:
        pnode = GameUtils::findDescendant(this->mainui, TAG_BATTLE_PNODE_INFO_PEER);
        localui = false;
        break;
    case TAG_BATTLE_LBL_HP:
    case TAG_BATTLE_LBL_MAX_HP:
    case TAG_BATTLE_BAR_HP:
        /*case TAG_BATTLE_LBL_MP:*/
    case TAG_BATTLE_BAR_MP:
    case TAG_BATTLE_PROG_SKILL:
        pnode = GameUtils::findDescendant(this->mainui, TAG_BATTLE_PNODE_INFO);
        break;
    }

    // translate tag
    switch (tag)
    {

    case TAG_BATTLE_LBL_HP_PEER:
        tag = TAG_BATTLE_LBL_HP;
        break;
    case TAG_BATTLE_LBL_MAX_HP_PEER:
        tag = TAG_BATTLE_LBL_MAX_HP;
        break;
    case TAG_BATTLE_BAR_HP_PEER:
        tag = TAG_BATTLE_BAR_HP;
        break;
        /* case TAG_BATTLE_LBL_MP_PEER:  // �ڶ�����棬����ת��
             tag = TAG_BATTLE_LBL_MP;
             break;*/
    case TAG_BATTLE_BAR_MP_PEER:
        tag = TAG_BATTLE_BAR_MP;
        break;
    case TAG_BATTLE_PROG_SKILL_PEER:
        tag = TAG_BATTLE_PROG_SKILL;
        break;
    }

    // sets ui
    switch (tag) {
    case TAG_BATTLE_LBL_HP:
    case TAG_BATTLE_LBL_MAX_HP:
    case TAG_BATTLE_BAR_HP:
        // case TAG_BATTLE_LBL_MP:
    case TAG_BATTLE_BAR_MP:
    case TAG_BATTLE_PROG_SKILL:
        ui = GameUtils::findDescendant(pnode, tag);
        break;
    default:
        ui = GameUtils::findDescendant(mainui, tag);
    }

    // ui::Button* button = nullptr; // maybe for MP, use shader
    if (!_IsNull((label = dynamic_cast<ui::Text*>(ui))) || !_IsNull((labelAtlas = dynamic_cast<ui::TextAtlas*>(ui))))
    {
        char svalue[64];
        const std::string* now = nullptr;
        if (label != nullptr) {
            now = &label->getString();
        }
        else {
            now = &labelAtlas->getString();
        }

        auto values = nsc::parse2f(*now, '/'); // For blood values
        auto maxVal = std::get<1>(values);
        float curVal = std::get<0>(values);
        if (maxVal < FLT_EPSILON) { // max is zero or neg
            snprintf(svalue, sizeof(svalue), "%.0f", value);
        }
        else {
            if (!forMaxVal) {
                snprintf(svalue, sizeof(svalue), "%.0f/%.0f", value, maxVal);
            }
            else {
                snprintf(svalue, sizeof(svalue), "%.0f/%.0f", curVal, value);
            }
        }

        Node* labelPtr = nullptr;
        if (label != nullptr)
        {
            labelPtr = label;
            label->setString(svalue);
        }
        else if (labelAtlas != nullptr)
        {
            labelPtr = labelAtlas;
            labelAtlas->setString(svalue);
        }

        if (std::abs(curVal - value) > 0.0001) {
            /*Color3B clrHighlight;
            if (value > curVal) {
            clrHighlight = Color3B(255, 248, 155);
            }
            else {
            clrHighlight = Color3B(222, 38, 38);
            }*/

            if (labelPtr != nullptr) {
                switch (tag) {

                case TAG_BATTLE_LBL_STEP: // RGB(255, 0, 0)
                    if (localCtl->isActive() && std::abs(curVal - value) == 1 && !this->bLocalTurnning) {
                        static const Point srcLoc = labelPtr->getPosition();
                        auto destLoc = srcLoc + Vec2(-20, -30);
                        labelPtr->stopActionByTag(201607);
                        labelPtr->runAction(Sequence::create(
                            MoveTo::create(0.1, destLoc),
                            CallFunc::create([=]{ labelPtr->setColor(value > curVal ? Color3B(255, 248, 155) : Color3B(222, 38, 38)); }),
                            ScaleTo::create(0.1, 1.3),
                            DelayTime::create(0.1),
                            Spawn::create(
                            ScaleTo::create(0.03, 1.0),
                            MoveTo::create(0.03, srcLoc),
                            nullptr),
                            CallFunc::create([labelPtr]{ labelPtr->setColor(Color3B(255, 255, 255)); }),
                            nullptr))->setTag(201607);
                    }
                    else {
#if 0
                        labelPtr->runAction(Sequence::create(
                            MoveBy::create(0.1, Vec2(-25, 50)),
                            CallFunc::create([labelPtr, clrHighlight]{ labelPtr->setColor(clrHighlight); }),
                            ScaleTo::create(0.1, 1.3),
                            DelayTime::create(0.2),
                            Spawn::create(
                            ScaleTo::create(0.03, 1.0),
                            MoveBy::create(0.03, Vec2(25, -50)),
                            nullptr),
                            CallFunc::create([labelPtr]{ labelPtr->setColor(Color3B(255, 255, 255)); }),
                            nullptr));
#endif
                    }
                    break;
                case TAG_BATTLE_LBL_HP:
                    if (!forMaxVal) {
                        // cocos2d::log("####### prev hp:%.0f, current hp: %.0f", curVal, value);
                        if (localui) {
                            static const Point srcLoc = labelPtr->getPosition();
                            auto destLoc = srcLoc + Vec2(value < curVal ? -10 : 10, 30);
                            labelPtr->stopActionByTag(201607);
                            labelPtr->runAction(Sequence::create(
                                MoveTo::create(0.1, destLoc),
                                CallFunc::create([=]{ labelPtr->setColor(value > curVal ? Color3B(255, 248, 155) : Color3B(222, 38, 38)); }),
                                ScaleTo::create(0.1, 1.3),
                                DelayTime::create(0.2),
                                Spawn::create(
                                ScaleTo::create(0.03, 1.0),
                                MoveTo::create(0.03, srcLoc),
                                nullptr),
                                CallFunc::create([labelPtr]{ labelPtr->setColor(Color3B(255, 255, 255)); }),
                                nullptr))->setTag(201607);
                        }
                        else {
                            static const Point srcLoc = labelPtr->getPosition();
                            auto destLoc = srcLoc + Vec2(value < curVal ? 10 : -10, 30);
                            labelPtr->stopActionByTag(201607);
                            labelPtr->runAction(Sequence::create(
                                MoveTo::create(0.1, destLoc),
                                CallFunc::create([=]{ labelPtr->setColor(value > curVal ? Color3B(255, 248, 155) : Color3B(222, 38, 38)); }),
                                ScaleTo::create(0.1, 1.3),
                                DelayTime::create(0.2),
                                Spawn::create(
                                ScaleTo::create(0.03, 1.0),
                                MoveTo::create(0.03, srcLoc),
                                nullptr),
                                CallFunc::create([labelPtr]{ labelPtr->setColor(Color3B(255, 255, 255)); }),
                                nullptr))->setTag(201607);
                        }
                    }
                    break;
                }
            }
        }

        if (tag == TAG_BATTLE_LBL_MP)
        {
            if (!forMaxVal && value >= 100)
            {
                if (tag == TAG_BATTLE_LBL_MP)
                {
                    this->setCicAbilButtonActived(TAG_BATTLE_BTN_SKILL, true, localui);
                    if (localui && localCtl->isActive())
                    {
                        this->setUIEnabled(TAG_BATTLE_BTN_USE_SKILL, true);
                    }
                }
            }
            else {
                if (tag == TAG_BATTLE_LBL_MP)
                {
                    this->setCicAbilButtonActived(TAG_BATTLE_BTN_SKILL, false, localui);

                    if (localui)
                        this->setUIEnabled(TAG_BATTLE_BTN_USE_SKILL, false);
                }
            }
        }
    }
    else if (!_IsNull((simBar = dynamic_cast<ui::Layout*>(ui)))) {
        auto& size = simBar->getContentSize();
        auto newHeight = this->barHPHeight * value / 100.0f;
        simBar->setContentSize(Size(size.width, newHeight));
    }
    else if (!_IsNull((bar = dynamic_cast<ui::LoadingBar*>(ui))))
    {
        bar->setPercent(value);
    }
    else if (tag == TAG_BATTLE_PROG_SKILL /*|| tag == TAG_BATTLE_PROG_SKILL_PEER*/)
    { // important: this where: magic limit is 100
#if 1
        assert(pnode != nullptr);
        ShaderManager::getInstance()->setPercent(static_cast<Sprite*>(ui), 1 - value / 100);
        updateCustomBarPercent(GameUtils::findDescendant(pnode, "Button_skill")->getChildByTag(TAG_UI_EFFECT_SKILL_BAR)->getChildByTag(TAG_UI_EFFECT_SKILL_BAR), ui, value);
        if (value >= 100)
        {
            /*if (tag == TAG_BATTLE_PROG_SKILL)
                static_cast<ui::Button*>(ui->getChildByTag(TAG_BATTLE_BTN_SKILL))->setEnabled(true);*/
        }
#endif
    }
    else if (auto uxbar = dynamic_cast<UXProgressBar*>(ui))
    {
        uxbar->setPercent(value);
    }

#if 0
    if (hideZero) {
        // ui->setVisible(std::abs(value) > FLT_EPSILON);
    }
#endif
}

bool BattleScene::setUIVisible(int tag, bool visible)
{
    auto ui = GameUtils::findDescendant(this->mainui, tag);
    if (ui != nullptr) {
        ui->setVisible(visible);
        return visible;
    }
    return false;
}

void BattleScene::setUIEnabled(int tag, bool enabled)
{
    auto ui = dynamic_cast<Widget*>(GameUtils::findDescendant(this->mainui, tag));
    if (ui != nullptr) {
        ui->setEnabled(enabled);
        ui->setBright(enabled);

        //if (tag == TAG_BATTLE_BTN_SKILL)
        //{
        //	if (enabled) {
        //		/*auto effect = Effect::create("models/ui_effect/jinengtishi");
        //		effect->playAnimation("animation", true);
        //		effect->alignBottom();*/
        //		if (_IsNull(ui->getChildByTag(TAG_SKILL_BTN_HIGHLIGHT))) {
        //			auto effect = CSLoader::createNode("la_anim_jinengtishi.csb");
        //			effect->setTag(TAG_SKILL_BTN_HIGHLIGHT);
        //			ui->addChild(effect);
        //			nodes_layout::centerNode(effect);
        //			timelineAbilTips.play(effect, true);
        //		}
        //	}
        //	else {
        //		ui->removeChildByTag(TAG_SKILL_BTN_HIGHLIGHT);
        //	}
        //}
    }
}

void BattleScene::setCicAbilButtonActived(int tag, bool active, bool local)
{
    Node* btnCicAbil = nullptr;
    if (local)
    {
        btnCicAbil = GameUtils::findDescendant(this->pnodeLocal, tag);
    }
    else{
        btnCicAbil = GameUtils::findDescendant(this->pnodePeer, tag);
    }
    if (active) {
        /*auto effect = Effect::create("models/ui_effect/jinengtishi");
        effect->playAnimation("animation", true);
        effect->alignBottom();*/
        if (_IsNull(btnCicAbil->getChildByTag(TAG_SKILL_BTN_HIGHLIGHT))) {
            auto effect = CSLoader::createNode("la_anim_jinengtishi.csb");
            effect->setTag(TAG_SKILL_BTN_HIGHLIGHT);
            btnCicAbil->addChild(effect);
            nodes_layout::centerNode(effect);
            timelineAbilTips.play(effect, true);
        }
    }
    else {
        btnCicAbil->removeChildByTag(TAG_SKILL_BTN_HIGHLIGHT);
    }
}

void BattleScene::setAllUserButtonsEnabled(bool enabled)
{ // ����ս�����ư�ť����״̬
    bool realenabled = enabled && !this->localCtl->isAutoControl() && BattleData::getInstance()->isLocalOperating();

    setUIEnabled(TAG_BATTLE_BTN_FLUSH_SOLDIER, realenabled);
    setUIEnabled(TAG_BATTLE_BTN_USE_SKILL, realenabled);
    setUIEnabled(TAG_BATTLE_BTN_ROUNDOUT, realenabled);
}

//void BattleScene::updateUIVisibleAnimated(int tag)
//{
//    auto ui = GameUtils::findDescendant(this->mainui, tag);
//    if (ui != nullptr)
//    {
//        if (ui->isVisible())
//            scaledHideUI(ui);
//        else
//            scaledShowUI(ui);
//    }
//}

void BattleScene::hideRoundoutDialog(void)
{
    this->hideUIConvering(TAG_BATTLE_DLG_ROUNDOUT);
}

bool BattleScene::changeUIVisible(int tag)
{
    auto ui = dynamic_cast<ui::Widget*>(GameUtils::findDescendant(this->mainui, tag));
    if (ui != nullptr)
    {
        ui->setVisible(!ui->isVisible());
        if (ui->isVisible()) {
            ui->bringToFront();
        }
        else
        {
            ui->sendToBack();
        }

        return ui->isVisible();
    }

    return false;
}

bool BattleScene::changeUIVisibleCovering(int tag)
{
    auto ui = dynamic_cast<ui::Widget*>(GameUtils::findDescendant(this->mainui, tag));
    if (ui != nullptr)
    {
        ui->setVisible(!ui->isVisible());
        if (ui->isVisible()) {
            ui->setTouchEnabled(true);
            if (this->battleStartupInfoResult >= 1)
                ui->bringToFront();
        }
        else
        {
            ui->setTouchEnabled(false);
            ui->sendToBack();
        }

        return ui->isVisible();
    }

    return false;
}

void BattleScene::hideUIConvering(int tag)
{
    auto ui = dynamic_cast<ui::Widget*>(GameUtils::findDescendant(this->mainui, tag));
    if (ui != nullptr)
    {
        ui->setVisible(false);
        ui->setTouchEnabled(false);
        ui->sendToBack();
    }
}

void BattleScene::updataUIVisibleText(int tag, const std::string& str)
{
    auto ui = dynamic_cast<ui::Button*>(GameUtils::findDescendant(this->mainui, tag));
    if (ui != nullptr)
    {
        ui->setTitleText(str);
    }
}
const Point BattleScene::getSkillBtnPosition(bool local)
{
    Node* Btn;
    if (local)
    {
        Btn = GameUtils::findDescendant(this->pnodeLocal, "Button_skill");
    }
    else
    {
        Btn = GameUtils::findDescendant(this->pnodePeer, "Button_skill");
    }

    return Btn->getParent()->convertToWorldSpace(Btn->getPosition());
}

void BattleScene::viewMpBlink(bool local)
{
    Node* Btn;
    auto node = GameUtils::simplePlayTimeline("la_anim_jineng_tt.csb");
    if (local)
    {
        Btn = GameUtils::findDescendant(this->pnodeLocal, "Button_skill");
    }
    else
    {
        Btn = GameUtils::findDescendant(this->pnodePeer, "Button_skill");
    }
    auto t = Btn->getParent()->convertToWorldSpace(Btn->getPosition());
    auto ppp = topmostNode->convertToNodeSpace(t);
    node->setPosition(ppp);
    topmostNode->addChild(node);
}

// �㲥�ڳ�����ʿ���ͳ�ǽִ�в���
void  BattleScene::foreachAllUnits(const std::function<void(Unit*)>& op)
{
    foreachLocalUnits(op);
    foreachPeerUnits(op);
}

// �㲥�ڳ��ҷ�ʿ���ͳ�ǽִ�в���
void BattleScene::foreachLocalUnits(const std::function<void(Unit*)>& op)
{
    this->localCtl->foreachUnits(op);
}

// �㲥�ڳ��Է�ʿ���ͳ�ǽִ�в���
void BattleScene::foreachPeerUnits(const std::function<void(Unit*)>& op)
{
    this->peerCtl->foreachUnits(op);
}


//////////////////////////////////////////////////////////////////////////////////// localCtl->setAutoControl(true)
//�����йܺ�ȡ���й�
void BattleScene::startAutoControl(BattleFieldController* ctl)
{
    //����һ�������˽��漺��ս��
    AIDriver::getInstance()->active();
    AIDriver::getInstance()->changeControlTarget(ctl);
}

void BattleScene::cancelAutoControl(BattleFieldController* ctl)
{
    if (ctl->isLocal() && ctl->isActive())
        this->localField->enableControl();


    AIDriver::getInstance()->releaseControl(ctl);
}

void BattleScene::showSMSDialog(const std::string& text, bool local)
{
#if 0
    Node* babbleDlg = GameUtils::findDescendant(mainui, local ? TAG_BATTLE_LAYER_SMS : TAG_BATTLE_LAYER_SMS_PEER);

    auto babbleLbl = dynamic_cast<ui::Text*>(babbleDlg->getChildByTag(local ? TAG_BATTLE_LBL_SMS : TAG_BATTLE_LBL_SMS_PEER));

    babbleLbl->setString(text);
    babbleDlg->setContentSize(Size(babbleLbl->getContentSize().width + 16, babbleDlg->getContentSize().height));

    if (!local)
        nodes_layout::setNodeRight(babbleLbl, 13.58f);

    if (!babbleDlg->isVisible()) {

        babbleDlg->stopAllActions();

        babbleDlg->setOpacity(0);
        auto action = cocos2d::Sequence::create(
            cocos2d::Show::create(),
            cocos2d::FadeIn::create(0.5f),
            cocos2d::DelayTime::create(5.0f),
            cocos2d::FadeOut::create(0.5f),
            cocos2d::Hide::create(),
            NULL
            );

        babbleDlg->runAction(action);
    }
#endif
}

static ui::Button* internalCreateResultButton(const std::string& title, float fontSize = 32, const Color3B& color = Color3B::WHITE)
{
    auto button = ui::Button::create("images/shared/button.png");
    button->setTitleColor(color);
    button->setTitleFontName(FONT_NAME_0);
    button->setTitleFontSize(fontSize);
    button->setTitleText(title);
    return button;
}

void BattleScene::onGameEnd(bool isDramaWin)
{
    if (!this->gameRunning)
        return;

    if (confirmDlg != nullptr) {
        confirmDlg->removeFromParent();
        confirmDlg->release();
        confirmDlg = nullptr;
    }

    /// ��������
    abilityMgr.clearAllFlows(true);
    localCtl->clearAllObjects();
    peerCtl->clearAllObjects();


    auto blockLa = GameUtils::createModelLayer();
    bottomNode->addChild(blockLa);
    nodes_layout::vscr::centerNode(blockLa);

    this->stopAllUIEvents();

    blockLa->setOpacity(0);
    eventBlockLayer->setOpacity(0);


    auto chapters = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_CHAPTER);
    auto& chapter = chapters->getDataRow(chapter_index);
    bool winner = isDramaWin;

    Sprite* localAvatar;
    if (this->battleStartupInfoResult < 1)
    {
        luax_pvcall("dbext.onDramaGuideDelete", backg, mainui);

        if (winner)
        {
            this->story_index = chapter.at(DAI_CHAPTER_WIN_MOVIE).asInt();
            auto condition = nsc::split(chapter.at(DAI_CHAPTER_WIN_CONDITIONS).asString(), ";");
            if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_HERO_DIED)
            {

                if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_LOCAL_FIELD)
                {
                    if (BattleData::getInstance()->queryData(VDI_REAL_HP) <= 0)
                    {

                        localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));
                        this->playExplosionAnim(localAvatar, winner);
                        return;
                    }
                }
                else if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_PEER_FIELD)
                {

                    if (BattleData::getInstance()->queryData(VDI_REAL_HP, false) <= 0)
                    {
                        localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_hero"));
                        this->playExplosionAnim(localAvatar, winner);
                        return;
                    }
                }
            }

            localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));
            this->playExplosionAnim(localAvatar, winner);
        }
        else
        {
            this->story_index = chapter.at(DAI_CHAPTER_LOSE_MOVIE).asInt();
            auto condition = nsc::split(chapter.at(DAI_CHAPTER_LOSE_CONDITIONS).asString(), ";");
            if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_HERO_DIED)
            {
                if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_LOCAL_FIELD)
                {
                    if (BattleData::getInstance()->queryData(VDI_REAL_HP) <= 0)
                    {
                        localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));
                        this->playExplosionAnim(localAvatar, winner);
                        return;
                    }
                }
                else if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_PEER_FIELD)
                {
                    if (BattleData::getInstance()->queryData(VDI_REAL_HP, false) <= 0)
                    {
                        localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_hero"));
                        this->playExplosionAnim(localAvatar, winner);
                        return;
                    }
                }
            }

            localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));
            this->playExplosionAnim(localAvatar, winner);
        }
    }
    else
    {
        winner = this->localHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE) > 0;
        if (!winner)
        {
#if 1
            localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));
            this->playExplosionAnim(localAvatar, isDramaWin);
#endif
        }
        else {
            localAvatar = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodePeer, "Image_hero"));
            this->playExplosionAnim(localAvatar, isDramaWin);
        }
    }
}

#define _MOVE_HEADIMAGE_TO_CENTER 1

void BattleScene::playExplosionAnim(Sprite* localAvatar, bool isDramaWin)
{
    auto localIamge = dynamic_cast<Sprite*>(GameUtils::findDescendant(pnodeLocal, "Image_hero"));

    auto& designSize = Director::getInstance()->getOpenGLView()->getDesignResolutionSize();
    auto moveTarget = localAvatar->getParent();
    auto moveTargetParent = moveTarget->getParent();

    auto worldPoint = moveTargetParent->convertToWorldSpace(moveTarget->getPosition());
    worldPoint.y = designSize.height / 2 + localAvatar->getContentSize().height / 4;
    auto targetPoint = moveTargetParent->convertToNodeSpace(worldPoint);

    auto frame = moveTargetParent->getChildByName("head_frame");
    auto frameAction = Spawn::create(ScaleTo::create(0.2f, 1.75f)
#if _MOVE_HEADIMAGE_TO_CENTER
        , MoveTo::create(0.2f, targetPoint)
#endif
        , nullptr);
    frame->runAction(frameAction);

    moveTarget->runAction(Sequence::create(Spawn::create(ScaleTo::create(0.2f, 1.75f),
#if _MOVE_HEADIMAGE_TO_CENTER
        MoveTo::create(0.2f, targetPoint),
#endif
        nullptr),
        DelayTime::create(0.1f),
        CallFunc::create([=]{

        //auto shatterAvatar = new ens::CshatterSprite();
        //shatterAvatar->initWithTexture(localAvatar->getTexture()/*"images/hero_1/small_img.png"*/);
        //shatterAvatar->setPosition(localAvatar->getPosition());
        //localAvatar->getParent()->addChild(shatterAvatar);
        //shatterAvatar->release();

        // localAvatar->removeFromParent();
        /*shatterAvatar->setOpacity(0);
        shatterAvatar->setScale(2.0f);
        shatterAvatar->stopAllActions();*/
        luax_pvcall("audiol.play", 332); // �����Ա���Ч

        Effect* explosion = Effect::create("models/ui_effect/touxiangbao", 1.5f);
        moveTarget->getParent()->addChild(explosion);
        nodes_layout::centerNode(explosion);
        explosion->alignCenter();
        explosion->setPosition(/*localAvatar*/moveTarget->getPosition());
        explosion->playAnimation("animation", false, true, [=](BattleObj*){
            if (this->battleStartupInfoResult < 1 && this->story_index != 0)
            {
                AIDriver::getInstance()->deactive();
                luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isDramaWin);
            }
            else
            {
                handleGameEnd(isDramaWin);
            }
        });
        explosion->addEventListener("ev_bomb", [=](Node*){
            /*auto shatterAction = Sequence::create(ens::shatter::CshatterAction::create(0.75f),
                DelayTime::create(0.75f),
                CallFunc::create([=]{
                shatterAvatar->removeFromParent();*/
            nodes_utility::changeNodeParent(explosion, moveTargetParent, true);
            explosion->setScale(1.75f);

            // should removeFromParent?
            moveTarget->setVisible(false);
            frame->setVisible(false);

            /* }), nullptr);*/

            // nodes_utility::changeNodeParent(shatterAvatar, moveTarget->getParent(), true);

            // shatterAvatar->runAction(shatterAction);
        });

    }), nullptr));
}

void BattleScene::handleGameEnd(bool isDramaWin)
{
    if (!this->gameRunning)
        return;


    BattleData::getInstance()->submitResultData();
    /*if (!BattleData::getInstance()->isPVE())
    {*/
    if (BattleData::getInstance()->battleStartupInfoResult != 1) {
        auto str = GameUtils::getStringForKey("getnews");
        GameUtils::showProgress(iconvw::g2u(str));
        NetworkManager::getInstance()->registerCallback(CID_BATTLE_RESULT_RESP, [this, isDramaWin](MsgBase* resp){
            GameUtils::hideProgress();

            auto detail = dynamic_cast<BattleResultResp*>(resp);
            if (detail == nullptr) {
                return;
            }

            this->battleResult = *detail;
            handleGameEndIntri(isDramaWin);
        }, true);
    }
    else {
        handleGameEndIntri(isDramaWin);
    }
    /*}
    else {
    handleGameEndIntri(isDramaWin);
    }*/
}

void BattleScene::handleGameEndIntri(bool isDramaWin)
{
    if (!this->gameRunning)
        return;

    if (isDramaWin)
        luax_pvcall("audiol.play", 341); // experimental::AudioEngine::play2d("sounds/mission_succeed", false);
    else
        luax_pvcall("audiol.play", 342); // experimental::AudioEngine::play2d("sounds/mission_failed", false);

    localCtl->clearAllObjects();
    peerCtl->clearAllObjects();

#if 1
    auto blockLa = GameUtils::createModelLayer();
    this->addChild(blockLa);

    Effect* skeleton = nullptr;
    Node* dialog = nullptr;

    auto heroId = BattleData::getInstance()->getHeroId();

    if (this->battleStartupInfoResult < 1)
    {
        if (this->isChapterFirstFight)
        {
            auto nPlayers = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_NEWPLAYER);
            auto& nPlayer = nPlayers->getDataRow(nPlayer_index);
            auto condition = nsc::split(nPlayer.at(DAI_NEWPLAYER_CONDITION).asString(), ";");
            auto save = nPlayer.at(DAI_NEWPLAYER_SAVE).asString();

            if (atoi(save) != 0)
            {
                auto save_info = nsc::split(save, ";");
                if (atoi(save_info.at(0).c_str()) != 9)
                {
                    this->dramaSavePoint = atoi(save_info.at(1).c_str());
                }

                if (this->chapter_index != 1001 && isDramaWin)
                {
                    messages::DramaGuideStep msg;
                    msg.step = this->dramaSavePoint;
                    NetworkManager::getInstance()->sendMsg(msg);
                }
            }
        }

        if (isDramaWin)
        {
            skeleton = Effect::create("models/ui_effect/la_fight_win");
            skeleton->playAnimation("animation", false, false);

            skeleton->addEventListener("ev_shot", [=](Node* n){
                auto dialog = CSLoader::createNode("la_fight_win.csb");
                this->timelineResult.play(dialog, false, "cwin"); // win: 100 160
                n->addChild(dialog);
                fillGameEndData(heroId, dialog, isDramaWin);
                nodes_layout::centerNode(dialog);
            });

            skeleton->alignCenter();
        }
        else
        {
            skeleton = Effect::create("models/ui_effect/la_fight_defeated");
            skeleton->playAnimation("animation", false, false);

            skeleton->addEventListener("ev_shot", [=](Node* n){
                auto dialog = CSLoader::createNode("la_fight_win.csb");
                this->timelineResult.play(dialog, false, "cdef"); // win: 100 160
                n->addChild(dialog);
                fillGameEndData(heroId, dialog, isDramaWin);
                nodes_layout::centerNode(dialog);
            });

            skeleton->alignCenter();
        }
    }
    else
    {
        if (this->localHero->getUnifyData(UnitPowerIndex::POWER_ATKVALUE) > 0)
        {
            skeleton = Effect::create("models/ui_effect/la_fight_win");
            skeleton->playAnimation("animation", false, false);

            skeleton->addEventListener("ev_shot", [=](Node* n){
                auto dialog = CSLoader::createNode("la_fight_win.csb");
                this->timelineResult.play(dialog, false, "cwin"); // win: 100 160
                n->addChild(dialog);
                fillGameEndData(heroId, dialog, isDramaWin);
                nodes_layout::centerNode(dialog);
            });

            skeleton->alignCenter();
        }
        else{
            skeleton = Effect::create("models/ui_effect/la_fight_defeated");
            skeleton->playAnimation("animation", false, false);

            skeleton->addEventListener("ev_shot", [=](Node* n){
                auto dialog = CSLoader::createNode("la_fight_win.csb");
                this->timelineResult.play(dialog, false, "cdef"); // win: 100 160
                n->addChild(dialog);
                fillGameEndData(heroId, dialog, isDramaWin);
                nodes_layout::centerNode(dialog);
            });

            skeleton->alignCenter();
        }
    }
    if (skeleton != nullptr)
    {
        blockLa->addChild(skeleton);
        nodes_layout::centerNode(skeleton);
    }
    else {
        blockLa->addChild(dialog);
        nodes_layout::vscr::centerNode(dialog);
    }


#if 0
    /// ����UI�ؼ�
    int heroId = BattleData::getInstance()->getHeroId();
    std::string heroImagePath = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_HEROS)->getDataRow(heroId).at(DAI_HEROS_IMAGES).asString();

    //auto largeImg = dynamic_cast<Sprite*>(GameUtils::findDescendant(dialog, "zhugong")); // Sprite::create(heroImagePath + "/large_img.png");
    auto smallImgSlot = dynamic_cast<Sprite*>(GameUtils::findDescendant(dialog, "touxiang")); // Sprite::create(heroImagePath + "/small_img.png");
    auto lblGold = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "label_gold")); // Label::create("x1000", FONT_NAME_0, 28);
    auto lblSliver = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "label_sliver")); // Label::create("x2000", FONT_NAME_0, 28);
    auto lblJewel = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "label_jewel")); // Label::create("x10", FONT_NAME_0, 28);
    auto btnGoback = dynamic_cast<ui::Button*>(GameUtils::findDescendant(dialog, "button_goback")); // internalCreateResultButton("Goback");
    auto btnRetry = dynamic_cast<ui::Button*>(GameUtils::findDescendant(dialog, "button_retry")); // internalCreateResultButton("Retry");

    //largeImg->setTexture(heroImagePath + "/large_img.png"); //
    auto smallImg = Sprite::create(heroImagePath + "/small_img.png");
    smallImgSlot->addChild(smallImg);
    nodes_layout::centerNode(smallImg);

    auto& smallImgSize = smallImg->getContentSize();
    float scaleProperly = std::min((lcgSmallIconSize.width / std::max(smallImgSize.width, smallImgSize.height)) * 0.9f, 0.9f);
    smallImg->setScale(scaleProperly);


    btnGoback->addClickEventListener([this](cocos2d::Ref*){
        luax_vcall("zysjSelectScene", this->story_index);
    });
    btnRetry->addClickEventListener([=](cocos2d::Ref*){
        if (detail_field.result < 1)
        {
            if (isDramaWin)
            {
                this->timelineResult.play(dialog, false, "cwin"); // win: 100 160
            }
            else
            {
                this->timelineDefeat.play(dialog, false, "cdef"); // win: 100 160
            }
        }
        else
        {
            if (this->localHero->getPower() > 0)
            {
                this->timelineResult.play(dialog, false, "cwin"); // win: 100 160
            }
            else{
                this->timelineDefeat.play(dialog, false, "cdef"); // win: 100 160
            }
        }
    });
#endif
#endif

    this->stopGame();
}

void BattleScene::fillGameEndData(int heroId, Node* dialog, bool isDramaWin)
{
    std::string heroImagePath = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_HEROS)->getDataRow(heroId).at(DAI_HEROS_IMAGES).asString();

    //auto largeImg = dynamic_cast<Sprite*>(GameUtils::findDescendant(dialog, "zhugong")); // Sprite::create(heroImagePath + "/large_img.png");
    auto smallImgSlot = dynamic_cast<Sprite*>(GameUtils::findDescendant(dialog, "hero_img")); // Sprite::create(heroImagePath + "/small_img.png");
    auto lblGiftAddScore = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_addScore"));
    // auto lblGold = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_addGold")); // Label::create("x1000", FONT_NAME_0, 28);
    //auto lblSliver = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_addSliver")); // Label::create("x2000", FONT_NAME_0, 28);
    //auto lblPlayerLv = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_playerLv")); // Label::create("x10", FONT_NAME_0, 28);
    auto lblDanAddScore = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_addExp"));
    //auto barExp = dynamic_cast<ui::LoadingBar*>(GameUtils::findDescendant(dialog, "LoadingBar_playerExp"));
    auto lblDanScore = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_Exp"));
    auto lblGiftScore = dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_Score"));

    auto btnGoback = dynamic_cast<ui::Button*>(GameUtils::findDescendant(dialog, "Button_next")); // internalCreateResultButton("Goback");
    // auto btnRetry = dynamic_cast<ui::Button*>(GameUtils::findDescendant(dialog, "Button_repeat")); // internalCreateResultButton("Retry");

    /// ����λ����
    auto& awards = this->battleResult.awards;

    int oldDan = my_division;
    int dan = my_division * 5; // ��λ
    int danScoreAdd = 0;
    int giftScoreAdd = 0;
    int danTotalScore = 0;
    int giftTotalScore = 0;

    if (awards.size() >= 1) {
        dan = awards[0].vlaue;
    }
    if (awards.size() >= 2) {
        danScoreAdd = awards[1].vlaue;
        luax_pvcall("butils.modifyUIText_Progressed", lblDanAddScore, danScoreAdd);
    }
    if (awards.size() >= 3) {
        giftScoreAdd = awards[2].vlaue;
        // lblGiftScore->setString(fastest_itoa(giftScoreAdd));
        luax_pvcall("butils.modifyUIText_Progressed", lblGiftAddScore, giftScoreAdd);
    }
    /*if (awards.size() >= 4){
        danTotalScore = awards[3].vlaue;
        luax_pvcall("butils.modifyScoreUIText_Progressed", lblDanScore, danTotalScore, danScoreAdd);
        }
        if (awards.size() >= 5){
        giftTotalScore = awards[4].vlaue;
        luax_pvcall("butils.modifyScoreUIText_Progressed", lblGiftScore, giftTotalScore, giftScoreAdd);
        }*/
    //if (awards.size() >= 4) {
    //    // oldDan = awards[3].vlaue;
    //}

    dan = std::ceil(dan / 5.0);

    //if (oldDan != 0) {
    if (dan > oldDan) {

        auto modelLayer = GameUtils::createModelLayer();
        this->getTopmost()->addChild(modelLayer);
        nodes_layout::centerNode(modelLayer);

        // ��������λ��Ч
        char modelPath[128];
        sprintf(modelPath, "models/ui_effect/duanwei%d", oldDan);
        auto upgradeEffect = Effect::create(modelPath, 1.0f, EffectAlign::ALIGN_CENTER);
        upgradeEffect->playAnimation("animation", false, true, [=](BattleObj*){
            modelLayer->removeFromParent();
        });
        this->getTopmost()->addChild(upgradeEffect);
        nodes_layout::centerNode(upgradeEffect);
    }
    else if (dan < oldDan) {
        // ���Ž���λ��Ч
        auto modelLayer = GameUtils::createModelLayer();
        this->getTopmost()->addChild(modelLayer);
        nodes_layout::centerNode(modelLayer);

        auto downgradeEffect = Effect::create("models/ui_effect/duanweijiangji", 1.0f, EffectAlign::ALIGN_CENTER);
        downgradeEffect->playAnimation("animation", false, true, [=](BattleObj*){
            modelLayer->removeFromParent();
        });
        this->getTopmost()->addChild(downgradeEffect);
        nodes_layout::centerNode(downgradeEffect);
    }
    /* ����λ���� */

    // ս���������
    if (this->battleStartupInfoResult >= 1) {

    }
    else if (this->battleStartupInfoResult < 1)
    { // ��������
        auto chapters = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_CHAPTER);
        auto& chapter = chapters->getDataRow(this->chapter_index);
        if (this->isChapterFirstFight)
        {
            if (strcmp(chapter.at(DAI_CHAPTER_REWARD1).asString(), "0") != 0)
            {
                auto reward_detail = nsc::split(chapter.at(DAI_CHAPTER_REWARD1).asString(), "#");
                for (size_t i = 0; i < reward_detail.size(); ++i)
                {
                    auto reward_info = nsc::split(reward_detail.at(i).c_str(), ";");
                    /*if (atoi(reward_info.at(0).c_str()) == EXP)
                    {
                    lblExp->setString(reward_info.at(1).c_str());
                    }
                    else if (atoi(reward_info.at(0).c_str()) == GOLD)
                    {
                    lblSliver->setString(reward_info.at(1).c_str());
                    }
                    else if (atoi(reward_info.at(0).c_str()) == DIAMOND)
                    {

                    }
                    else if (atoi(reward_info.at(0).c_str()) == IRON)
                    {

                    }*/
                }
            }
            else
            {
                /* lblExp->setString("0");
                 lblSliver->setString("0");
                 lblScore->setString("0");*/
            }
        }
        else
        {
            this->nPlayer_index = 0;
            if (strcmp(chapter.at(DAI_CHAPTER_REWARD2).asString(), "0") != 0)
            {
                auto reward_detail = nsc::split(chapter.at(DAI_CHAPTER_REWARD2).asString(), "#");
                for (size_t i = 0; i < reward_detail.size(); ++i)
                {
                    auto reward_info = nsc::split(reward_detail.at(i).c_str(), ";");
                    /* if (atoi(reward_info.at(0).c_str()) == EXP)
                     {
                     lblExp->setString(reward_info.at(1).c_str());
                     }
                     else if (atoi(reward_info.at(0).c_str()) == GOLD)
                     {
                     lblSliver->setString(reward_info.at(1).c_str());
                     }
                     else if (atoi(reward_info.at(0).c_str()) == DIAMOND)
                     {

                     }
                     else if (atoi(reward_info.at(0).c_str()) == IRON)
                     {

                     }*/
                }
            }
            else
            {
                /* lblExp->setString("0");
                 lblSliver->setString("0");
                 lblScore->setString("0");*/
            }
        }
    }

    //largeImg->setTexture(heroImagePath + "/large_img.png"); //
    auto smallImg = Sprite::create(heroImagePath + "/small_img.png");
    smallImgSlot->addChild(smallImg);
    nodes_layout::centerNode(smallImg);

    auto& smallImgSize = smallImg->getContentSize();
    float scaleProperly = std::min((smallImgSlot->getContentSize().width / std::max(smallImgSize.width, smallImgSize.height)) * 0.75f, 0.75f);
    smallImg->setScale(scaleProperly);

    btnGoback->addClickEventListener([=](cocos2d::Ref*){
        // btnGoback->setEnabled(false);
        btnGoback->setTouchEnabled(false);
        luax_vcall("zysjSelectScene", this->nPlayer_index, 3);
    });
}

float BattleScene::getFieldScale(void)
{
    return backg->getScale();
}

void BattleScene::setFieldScale(float scale)
{
    backg->setScale(scale);
}

static ui::Button* internalCreateCheatButton(BattleScene* scene, std::vector<Node*>& layouts, const char* text, const Color3B& color = Color3B::WHITE)
{
    auto button = ui::Button::create();
    button->setTitleText(text);
    button->setTitleColor(color);
    button->setTitleFontName(FONT_NAME_0);
    button->setTitleFontSize(32);
    button->getTitleRenderer()->enableOutline(Color4B(0, 0, 0, 220), 2);
    scene->getUIDisplay()->addChild(button);
    layouts.push_back(button);
    return button;
}

/// �������װ�ť
void BattleScene::openCheat(void)
{
#if defined(_WIN32)

    if (!cheatGroup.empty())
    {
        auto isopen = cheatGroup[0]->isVisible();
        if (isopen) { // close cheat
            for (auto cheatItem : cheatGroup)
                cheatItem->setVisible(false);
        }
        else { // open cheat
            for (auto cheatItem : cheatGroup)
                cheatItem->setVisible(true);
        }

        return;
    }

    internalCreateCheatButton(this, cheatGroup, "+HP", Color3B(255, 0, 0))->addClickEventListener([=](cocos2d::Ref*){
        auto lock = BattleData::getInstance()->isDataLocked();
        if (false)
        {
            localHero->cure(100);
        }
        else
        {
            REQUIRE_DATA_UNLOCKED_FUNC([=](){
                luax_pvcall("bext.modifyHeroHP_GM", localHero, 100, true); });
        }
        if (BattleData::getInstance()->isPVE()){
            if (false)
            {
                peerHero->cure(100);
            }
            else
            {
                REQUIRE_DATA_UNLOCKED_FUNC([=](){
                    luax_pvcall("bext.modifyHeroHP_GM", peerHero, 100, true); });
            }
        }
    });

    internalCreateCheatButton(this, cheatGroup, "++HP", Color3B(255, 0, 0))->addClickEventListener([=](cocos2d::Ref*){
        auto lock = BattleData::getInstance()->isDataLocked();
        if (false)
        {
            localHero->cure(10000);
        }
        else
        {
            REQUIRE_DATA_UNLOCKED_FUNC([=](){
                luax_pvcall("bext.modifyHeroHP_GM", localHero, 10000, true); });

        }
        if (BattleData::getInstance()->isPVE()){
            if (false)
            {
                peerHero->cure(10000);
            }
            else
            {
                REQUIRE_DATA_UNLOCKED_FUNC([=](){
                    luax_pvcall("bext.modifyHeroHP_GM", peerHero, 10000, true); });
            }
        }
    });

    internalCreateCheatButton(this, cheatGroup, "+MP", Color3B(0, 0, 255))->addClickEventListener([](cocos2d::Ref*){
        BattleData::getInstance()->modifyData(VDI_MP, 50);
        if (BattleData::getInstance()->isPVE())
            BattleData::getInstance()->modifyData(VDI_MP, 50, false);
    });
    internalCreateCheatButton(this, cheatGroup, "++MP", Color3B(0, 0, 255))->addClickEventListener([](cocos2d::Ref*){
        BattleData::getInstance()->modifyData(VDI_MP, 100);
        if (BattleData::getInstance()->isPVE())
            BattleData::getInstance()->modifyData(VDI_MP, 100, false);
    });

    internalCreateCheatButton(this, cheatGroup, "+Step")->addClickEventListener([](cocos2d::Ref*){
        BattleData::getInstance()->modifyData(VDI_STEP, 1);
    });

    internalCreateCheatButton(this, cheatGroup, "++Step")->addClickEventListener([](cocos2d::Ref*){
        BattleData::getInstance()->modifyData(VDI_STEP, 100);
    });

    internalCreateCheatButton(this, cheatGroup, "--HP", Color3B(255, 0, 0))->addClickEventListener([=](cocos2d::Ref*){
        if (false)
        {
            localHero->hurt(BattleData::getInstance()->queryData(VDI_REAL_HP) - 1);
        }
        else
        {
            REQUIRE_DATA_UNLOCKED_FUNC([=](){
                luax_pvcall("bext.modifyHeroHP_GM", localHero, 1 - BattleData::getInstance()->queryData(VDI_REAL_HP), false); });
        }
        if (BattleData::getInstance()->isPVE())
        {
            if (false)
            {
                peerHero->hurt(BattleData::getInstance()->queryData(VDI_REAL_HP, false) - 1);
            }
            else
            {
                REQUIRE_DATA_UNLOCKED_FUNC([=](){
                    luax_pvcall("bext.modifyHeroHP_GM", peerHero, 1 - BattleData::getInstance()->queryData(VDI_REAL_HP, false), false); });
            }
        }
    });

    internalCreateCheatButton(this, cheatGroup, "Refresh", Color3B(255, 0, 0))->addClickEventListener([this](cocos2d::Ref*){
        this->getLocalController()->clearAllObjects();
        BattleData::getInstance()->storeDataOnly(VDI_IDLES, BattleData::getInstance()->queryData(VDI_TOTAL_SOLDIERS));
        BattleData::getInstance()->flushSoldier(true);
    });

    nodes_layout::alignVerticals(cheatGroup);
    nodes_layout::alignLefts(cheatGroup);
    nodes_layout::makeVerticalSpacingEqual(cheatGroup, 30);
    nodes_layout::setNodeGroupTop(cheatGroup, 100);
    nodes_layout::setNodeGroupRight(cheatGroup, 7);

    GameUtils::findDescendant(mainui, TAG_BATTLE_LA_NEW_SETTINGS)->bringToFront();

#endif
}



bool BattleScene::checkDramaWinOrLoseCondition(int c_index, bool isWin)
{
    auto chapters = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_CHAPTER);
    auto& chapter = chapters->getDataRow(chapter_index);
    auto condition = nsc::split(chapter.at(c_index).asString(), ";");


    if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_HERO_DIED)
    {
        if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_LOCAL_FIELD)
        {
            /*if (isWin)
            {*/
            if (BattleData::getInstance()->queryData(VDI_HP) <= 0)
            {
                BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                    this->shaking = false;
                    // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                }, true);
                return true;
            }
            /*}
            else
            {
            if (BattleData::getInstance()->queryData(VDI_HP) <= 0)
            {
            BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
            }, true);
            }
            }*/

        }
        else if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_PEER_FIELD)
        {
            /*if (isWin)
            {*/
            if (BattleData::getInstance()->queryData(VDI_HP, false) <= 0)
            {
                BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                    this->shaking = false;
                    // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                }, true);
                return true;
            }
            /*}
            else
            {
            if (BattleData::getInstance()->queryData(VDI_HP, false) <= 0)
            {
            BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
            BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
            }, true);
            }
            }*/

        }

    }
    else if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_ALL_SOLDIER_DIED)
    {
        if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_LOCAL_FIELD)
        {
            if (atoi(condition.at(1).c_str()) == 0)
            {
                if (BattleData::getInstance()->isNoSoldier(true))
                {
                    /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                    luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                    BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                        this->shaking = false;// BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                    }, true);
                    return true;
                }
            }
            else
            {
                if (atoi(condition.at(1).c_str()) < BattleData::getInstance()->getRounds())
                {
                    /*this->story_index = chapter.at(DAI_CHAPTER_LOSE_MOVIE).asInt();
                    luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                    BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                        this->shaking = false;  // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, false);
                    }, true);
                    return true;
                }
                else
                {
                    if (BattleData::getInstance()->isNoSoldier(true))
                    {
                        /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                        luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                        BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                            this->shaking = false;// BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                        }, true);
                        return true;
                    }
                }
            }
        }
        else if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_PEER_FIELD)
        {
            if (atoi(condition.at(1).c_str()) != 0)
            {
                if (BattleData::getInstance()->isNoSoldier(true))
                {
                    /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                    luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                    BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                        this->shaking = false;// BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                    }, true);
                    return true;
                }
            }
            else
            {
                if (atoi(condition.at(1).c_str()) < BattleData::getInstance()->getRounds())
                {
                    /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                    luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                    BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                        this->shaking = false; // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, false);
                    }, true);
                    return true;
                }
                else
                {
                    if (BattleData::getInstance()->isNoSoldier(true))
                    {
                        /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                        luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                        BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                            this->shaking = false; // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                        }, true);
                        return true;
                    }
                }
            }
        }
    }
    else if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_ID_SOLDIER_DIED)
    {
        if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_LOCAL_FIELD)
        {
            auto assignSoldier = getAssignSoldier(this->localCtl, atoi(condition.at(1).c_str()));
            if (assignSoldier.empty())
            {
                /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                    this->shaking = false; // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                }, true);
                return true;
            }

        }
        else if (atoi(condition.at(2).c_str()) == DramaBattleFieldType::ON_PEER_FIELD)
        {
            auto assignSoldier = getAssignSoldier(this->peerCtl, atoi(condition.at(1).c_str()));
            if (assignSoldier.empty())
            {
                /*this->story_index = chapter.at(winOrLoseEnum).asInt();
                luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
                BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                    this->shaking = false; // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
                }, true);
                return true;
            }
        }
    }
    else if (atoi(condition.at(0).c_str()) == DramaBattleEndType::ON_ROUND_END)
    {
        if (atoi(condition.at(1).c_str()) < BattleData::getInstance()->getRounds())
        {
            /*this->story_index = chapter.at(winOrLoseEnum).asInt();
            luax_pvcall("dbext.onDramaAnim", mainui, this->story_index, true, isWin);*/
            BattleEventDispatcher::getInstance()->addEventListener(ON_SHAKE_END, [=](const BattleEventParam&){
                this->shaking = false; // BattleEventDispatcher::getInstance()->dispatchEvent(BattleEventType::ON_GAME_END, isWin);
            }, true);
            return true;
        }
    }
    return false;
}

std::vector<Unit*> BattleScene::getAssignSoldier(BattleFieldController* ctl, int soldier_id)
{
    std::vector<Unit*> tempVector;

    auto & tempMatrix = ctl->getMatrix();

    for (int i = 5; i >= 0; i--)
    {
        for (int j = 7; j >= 0; j--)
        {
            auto t = ctl->getOccupiedUnit(tempMatrix[i][j]);
            CONTINUE_IF(t == nullptr);                    //continue  empty

            if (t->isSoldier())
            {
                auto s = dynamic_cast<Soldier*>(t);

                if (s->unitid == soldier_id && !s->isVirtualSoldier() && (s->getState() == SOLDIER_STAND || s->getState() == SOLDIER_READYATK))
                {
                    tempVector.push_back(t);
                    continue;
                }
            }
        }
    }
    return tempVector;
}
void BattleScene::upStepPosition(bool islocal)
{
    float xorig = this->imageStep->getPositionX();
    float xorig2 = this->strStep->getPositionX();
    if (islocal)
    {
        this->imageStep->setPosition(Vec2(xorig, 586));
        this->strStep->setPosition(Vec2(xorig2, 21));
    }
    else
    {
        this->imageStep->setPosition(Vec2(xorig, 695));
        this->strStep->setPosition(Vec2(xorig2, 31));
    }
}


void BattleScene::setDesignationLocation(float x, float y)
{
    designationLocation = Vec2(x, y);
}

void BattleScene::setIsDramaConditionOk(bool isOk)
{
    isDramaConditionOk = isOk;
}

void BattleScene::setNPlayerIndex(int index)
{
    nPlayer_index = index;
}

void BattleScene::setChapterIndex(int index)
{
    chapter_index = index;
}

void BattleScene::setIsDramaSoldierDelete(bool isDel)
{
    isDramaSoldierDelete = isDel;
}

void BattleScene::setIsDrama(bool isDrama)
{
    this->isDrama = isDrama;
}

void BattleScene::setEnemyIndex(int enemy_index)
{
    this->enemy_index = enemy_index;
}

void BattleScene::setIsDramaClickButton(bool isDramaClickButton)
{
    this->isDramaClickButton = isDramaClickButton;
}

void BattleScene::setIsDramaSoldierAtk(bool isDramaSoldierAtk)
{
    this->isDramaSoldierAtk = isDramaSoldierAtk;
}

void BattleScene::setMyRefreshIndex(int index)
{
    this->myRefresh_index = index;
}

void BattleScene::setUserMsgFlag(int flag)
{
    this->userMsgFlag = flag;
}

void BattleScene::setDramaSavePoint(int point)
{
    this->dramaSavePoint = point;
}

void BattleScene::setIsChapterFirstFight(bool isFirst)
{
    this->isChapterFirstFight = isFirst;
}