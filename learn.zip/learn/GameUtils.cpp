#include "GameUtils.h"

#include <ui/CocosGUI.h>
#include <cocostudio/CocoStudio.h>
#include <ui/UIRichText.h>

#include "purelib/utils/politedef.h"
#include "purelib/NXNodesLayout.h"
#include "ShaderManager.h"
#include "EventDispatcherEx.h"
#include "purelib/utils/iconvw.h"
#include "purelib/utils/nsconv.h"
#include "data/DataSourceCSV.h"
#include "purelib/NXColorUtility.h"
#include "EventDispatcherEx.h"
#include "BaseScene.h"

using namespace cocos2d;
using namespace cocostudio;
using namespace cocos2d::ui;

#define kProgressLayerTag 201606
#define kUniqueDialogTag  201607

#define STRINGFUN(A) #A
#define JUDGELETTER_CLASSIC(ch) (((ch)>='A'&&ch<='Z')||((ch)>='a'&&(ch)<='z'))  

static const char* s_highlightFragSource = STRINGFUN(
    \n#ifdef GL_ES\n
    precision mediump float;
\n#endif\n

varying vec4 v_fragmentColor;
varying vec2 v_texCoord;

uniform vec2 resolution;

const float blurSize = 1.0 / 512.0;
const float intensity = 0.35;
void main()
{
    vec4 sum = vec4(0);
    vec2 texcoord = v_texCoord.xy;
    int j;
    int i;

    sum += texture2D(CC_Texture0, vec2(texcoord.x - 4.0*blurSize, texcoord.y)) * 0.05;
    sum += texture2D(CC_Texture0, vec2(texcoord.x - 3.0*blurSize, texcoord.y)) * 0.09;
    sum += texture2D(CC_Texture0, vec2(texcoord.x - 2.0*blurSize, texcoord.y)) * 0.12;
    sum += texture2D(CC_Texture0, vec2(texcoord.x - blurSize, texcoord.y)) * 0.15;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y)) * 0.16;
    sum += texture2D(CC_Texture0, vec2(texcoord.x + blurSize, texcoord.y)) * 0.15;
    sum += texture2D(CC_Texture0, vec2(texcoord.x + 2.0*blurSize, texcoord.y)) * 0.12;
    sum += texture2D(CC_Texture0, vec2(texcoord.x + 3.0*blurSize, texcoord.y)) * 0.09;
    sum += texture2D(CC_Texture0, vec2(texcoord.x + 4.0*blurSize, texcoord.y)) * 0.05;

    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y - 4.0*blurSize)) * 0.05;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y - 3.0*blurSize)) * 0.09;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y - 2.0*blurSize)) * 0.12;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y - blurSize)) * 0.15;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y)) * 0.16;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y + blurSize)) * 0.15;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y + 2.0*blurSize)) * 0.12;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y + 3.0*blurSize)) * 0.09;
    sum += texture2D(CC_Texture0, vec2(texcoord.x, texcoord.y + 4.0*blurSize)) * 0.05;

    gl_FragColor = sum*intensity + texture2D(CC_Texture0, texcoord);
    return;
}
);

cocos2d::GLProgram* internalGetHighlightProgram()
{
    cocos2d::GLProgram* s_highlightProgram = GLProgramCache::getInstance()->getGLProgram("internalGetHighlightProgram");
    if (s_highlightProgram != nullptr)
        return s_highlightProgram;

    s_highlightProgram = new cocos2d::GLProgram();
    s_highlightProgram->initWithByteArrays(ccPositionTextureColor_noMVP_vert, s_highlightFragSource);
    s_highlightProgram->link();
    s_highlightProgram->updateUniforms();
    /// memory managed by cache
    GLProgramCache::getInstance()->addGLProgram(s_highlightProgram, "internalGetHighlightProgram");
    s_highlightProgram->release();

    return s_highlightProgram;
}

static cocos2d::Map<Node*, GLProgram*> s_tabHighlightPrograms;

void internalClearCache()
{
    s_tabHighlightPrograms.clear();
}

void internalRestoreProgram(ui::Button* current)
{
    auto target = s_tabHighlightPrograms.find(current);
    if (target != s_tabHighlightPrograms.end())
    {
        auto render = dynamic_cast<ui::Scale9Sprite*>(current->getVirtualRenderer())->getSprite();
        render->setGLProgram(target->second);
        s_tabHighlightPrograms.erase(target);
    }
}

void internalSetHighlightedProgram(ui::Button* current)
{
    auto target = s_tabHighlightPrograms.find(current);
    if (target == s_tabHighlightPrograms.end())
    {
        auto render = dynamic_cast<ui::Scale9Sprite*>(current->getVirtualRenderer())->getSprite();
        s_tabHighlightPrograms.insert(current, render->getGLProgram());
        render->setGLProgram(internalGetHighlightProgram());
    }
}




class LayerPopup : public cocos2d::LayerColor
{
public:
    static LayerPopup* create(const Color4B& color = Color4B(0, 0, 0, 128))
    {
        LayerPopup *pRet = new(std::nothrow) LayerPopup();
        if (pRet && pRet->init(color))
        {
            pRet->autorelease();
            return pRet;
        }
        else
        {
            delete pRet;
            pRet = NULL;
            return NULL;
        }
    }
    ~LayerPopup()
    {
        if (this->getTag() == 201606) {
            int brk = 0;
        }
    }

    void addCSNode(Node* csUI)
    {
        this->addChild(csUI);
        nodes_layout::centerNode(csUI);
        this->uiRoot = csUI;
    }

    bool init(const Color4B& color)
    {
        this->uiRoot = nullptr;

        if (!LayerColor::initWithColor(color)) return false;

        setTouchMode(cocos2d::Touch::DispatchMode::ONE_BY_ONE);
        setTouchEnabled(true);

        EventListenerMouse* mouseListener = EventListenerMouse::create();
        mouseListener->onMouseMove = [](cocos2d::Event* e){
            e->stopPropagation();
        };

        Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(mouseListener, this);

        return true;
    }

    virtual bool onTouchBegan(Touch *touch, Event *unused_event) override
    {
        return this->isVisible();
    }

    virtual Node* getChildByName(const std::string& name) const override
    {
        if (this->uiRoot == nullptr)
            return LayerColor::getChildByName(name);
        else
            return this->uiRoot->getChildByName(name);
    }

    virtual Node* getChildByTag(int tag) const override
    {
        if (this->uiRoot == nullptr)
            return LayerColor::getChildByTag(tag);
        else
            return  this->uiRoot->getChildByTag(tag);
    }

private:
    Node* uiRoot;
}; /* endof LayerPopup */





void TimelineAnimate::setup(const char* src)
{
    clear();
    this->timelineAction = CSLoader::createTimeline(src);
    this->timelineAction->retain();
}

void TimelineAnimate::clear(void)
{
    if (this->timelineAction != nullptr) {
        this->timelineAction->release();
        this->timelineAction = nullptr;
    }
}

void TimelineAnimate::play(Node* target, bool loop)
{
    this->play(target, loop, TAG_NONAME_ANIMATION);
}

void TimelineAnimate::play(Node* target, bool loop, const char key[5], const std::function<void()>& onLastFrame)
{
    this->play(target, loop, *reinterpret_cast<const int*>(&key[0]), onLastFrame);
}

void TimelineAnimate::play(Node* target, bool loop, int tag, const std::function<void()>& onLastFrame)
{
    target->stopActionByTag(tag);
    auto tempAction = this->timelineAction;
    if (reuseAction)
        tempAction = timelineAction->clone();

    target->runAction(tempAction);

    tempAction->setTag(tag);

    applyScaleFixed(tempAction);

    if (!loop) {
        auto sharedAction = nodes_utility::shared(tempAction);
        auto sharedTarget = nodes_utility::shared(target);
        tempAction->setLastFrameCallFunc([=]{
            sharedTarget->stopAction(sharedAction);
            if (onLastFrame)
                onLastFrame();
            sharedAction->clearLastFrameCallFunc();
        });
    }
    tempAction->gotoFrameAndPlay(0, loop);
}

void TimelineAnimate::play(Node* target, const char* animation, bool loop, const std::function<void()>& onAnimationEnd)
{
    target->stopActionByTag(TAG_NAMED_ANIMATION);
    auto tempAction = this->timelineAction;
    if (reuseAction)
        tempAction = timelineAction->clone();

    target->runAction(tempAction);

    tempAction->setTag(TAG_NAMED_ANIMATION);

    applyScaleFixed(tempAction);

    tempAction->play(animation, loop);

    if (onAnimationEnd) {
        tempAction->setAnimationEndCallFunc(animation, onAnimationEnd);
    }
}

void TimelineAnimate::play(const char* animation, bool loop, const std::function<void()>& onAnimationEnd)
{
    auto tempAction = this->timelineAction;

    applyScaleFixed(tempAction);

    tempAction->play(animation, loop);

    if (onAnimationEnd) {
        tempAction->setAnimationEndCallFunc(animation, onAnimationEnd);
    }
}

void TimelineAnimate::playOnce(Node* target)
{
    auto tempAction = timelineAction->clone();
    target->runAction(tempAction);

    applyScaleFixed(tempAction);

    auto sharedAction = nodes_utility::shared(tempAction);
    auto sharedTarget = nodes_utility::shared(target);
    tempAction->setLastFrameCallFunc([=]{
        sharedTarget->stopAction(sharedAction);
        sharedTarget->removeFromParent();
        sharedAction->clearLastFrameCallFunc();
    });

    tempAction->gotoFrameAndPlay(0, false);
}

void TimelineAnimate::playLooped(Node* target, int startFrameForLoop, int endFrameForLoop, int startFrame)
{
    auto tempAction = timelineAction->clone();

    target->runAction(tempAction);
    auto sharedAction = nodes_utility::shared(tempAction);

    applyScaleFixed(tempAction);

    tempAction->setLastFrameCallFunc([=]{
        sharedAction->gotoFrameAndPlay(startFrameForLoop, endFrameForLoop, true);
    });

    tempAction->gotoFrameAndPlay(startFrame, false);
}

void TimelineAnimate::applyScaleFixed(timeline::ActionTimeline* actionTimeline)
{
    for (auto& timeline : actionTimeline->getTimelines())
    {
        for (auto frame : timeline->getFrames())
        {
            auto scaleFrame = dynamic_cast<timeline::ScaleFrame*>(frame);
            if (scaleFrame != nullptr)
            {
                assert(scaleFrame->getNode() != nullptr);
                if (scaleFrame->getNode() != nullptr) {
                    if (std::find(this->scaleNames.begin(), this->scaleNames.end(), scaleFrame->getNode()->getName()) != this->scaleNames.end())
                    {
                        scaleFrame->setScale(scaleFrame->getNode()->getScale());
                    }
                }
            }
        }
    }
}

void TimelineAnimate::preserveScale(const char* name)
{
    this->scaleNames.push_back(name);
}

void GameUtils::exit(void)
{
    Director::getInstance()->end();
}

LayerColor* GameUtils::createModelLayer(const Color4B& color)
{
    return LayerPopup::create(color);
}

/*
** @summary: ��ʾ��Ϸ�ڵ���
** @params:
** @remark:
*/
Node* GameUtils::showPopup(Node* parent, const char* res)
{
    auto* agentPopup = LayerPopup::create();
    auto uiRoot = CSLoader::getInstance()->createNode(res);
    agentPopup->addCSNode(uiRoot);

    parent->addChild(agentPopup);
    return agentPopup;
}

Node* GameUtils::showPopup(Node* parent, const char* resPopup, int tagClose)
{
    auto thePopup = showPopup(parent, resPopup);

    uiRegister(thePopup, tagClose, [thePopup](cocos2d::Ref*){
        thePopup->removeFromParent();
    });

    return thePopup;
}

Node* GameUtils::findDescendant(Node* root, const char* name, bool /*recursively*/)
{
    return utils::findChild(root, name);
}

Node* GameUtils::findDescendant(Node* root, int tag, bool /*recursively*/)
{
    return utils::findChild(root, tag);
}

void GameUtils::uiRegister(cocos2d::Node* root, const char* name, const cocos2d::ui::Widget::ccWidgetClickCallback& callback)
{
    auto target = findDescendant(root, name);
    if (!_IsNull(target))
        uiRegister(target, callback);
    else
        cocos2d::log("registerWidgetClick failed.\r\nCan't find the widget: name(%s)!", name);
}

void GameUtils::uiRegister(cocos2d::Node* root, const std::vector<std::string>& names, const cocos2d::ui::Widget::ccWidgetClickCallback& callback)
{
    for (const auto& name : names)
        uiRegister(root, name.c_str(), callback);
}

void  GameUtils::uiRegister(cocos2d::Node* uiRoot, int tag, const cocos2d::ui::Widget::ccWidgetClickCallback& callback)
{
    auto target = findDescendant(uiRoot, tag);
    if (!_IsNull(target))
        uiRegister(target, callback);
    else
        cocos2d::log("registerWidgetClick failed.\r\nCan't find the widget: TAG(%d)!", tag);
}

void  GameUtils::uiRegister(cocos2d::Node* uiRoot, const std::vector<int>& tags, const cocos2d::ui::Widget::ccWidgetClickCallback& callback)
{
    for (const auto& tag : tags)
        uiRegister(uiRoot, tag, callback);
}

void  GameUtils::uiRegister(Node* target, const cocos2d::ui::Widget::ccWidgetClickCallback& callback)// the real impl
{
    auto theWidget = dynamic_cast<ui::Widget*>(target);
    if (!_IsNull(theWidget))
    {
        auto checkbox = dynamic_cast<ui::CheckBox*>(theWidget);
        auto listview = dynamic_cast<ui::ListView*>(theWidget);
        if (!_IsNull(checkbox)) {
            checkbox->addEventListener([checkbox, callback](cocos2d::Ref* ref, ui::CheckBox::EventType){
                cocos2d::log("The checkbox:%s clicked!", checkbox->getName().c_str());
                callback(ref);
            });
        }
        else if (!_IsNull(listview))
        {
            listview->ListView::addEventListener(static_cast<ui::ListView::ccListViewCallback>([callback, listview, theWidget](cocos2d::Ref* ref, ui::ListView::EventType e){
                if (e == ui::ListView::EventType::ON_SELECTED_ITEM_END)
                {
                    cocos2d::log("The item:%s of list view: %s clicked, ", dynamic_cast<Node*>(ref)->getName().c_str(), theWidget->getName().c_str());
                    callback(ref);
                }
            }));
        }
        else {
            theWidget->addClickEventListener([callback, theWidget](cocos2d::Ref* ref){
                cocos2d::log("The widget:%s clicked!", theWidget->getName().c_str());
                if (auto btn = dynamic_cast<ui::Button*>(ref))
                {
                    internalRestoreProgram(btn);
                }
                callback(ref);
            });

#if 0
            auto buttonObj = dynamic_cast<ui::Button*>(theWidget);
            if (buttonObj != nullptr) {
                buttonObj->setScale9Enabled(false); // ע��: �༭������Scale9�����õģ�ʹ����Ч���������ã��Ƿ��ǿ���ģ�, 
                EventListenerMouse* mouseListener = EventListenerMouse::create();
                mouseListener->onMouseMove = [](cocos2d::Event* e){
                    auto mouseEvent = dynamic_cast<cocos2d::EventMouse*>(e);

                    if (mouseEvent->getMouseButton() != -1)
                        return;

                    auto worldPoint = Point(mouseEvent->getCursorX(), mouseEvent->getCursorY());
                    auto current = dynamic_cast<ui::Button*>(mouseEvent->getCurrentTarget());

                    auto render = dynamic_cast<ui::Scale9Sprite*>(current->getVirtualRenderer())->getSprite();
                    if (current->isEnabled()) {
                        if (nodes_utility::containsPoint(current, worldPoint))
                        {
                            internalSetHighlightedProgram(current);
                        }
                        else {
                            internalRestoreProgram(current);
                        }
                    }
                };
                Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(mouseListener, theWidget);
            }
#endif
        }
    }
    else {
        auto listener = EventDispatcherEx::create(target);
        listener->addClickListener([=](const Point& worldPoint, int clickCount) {
            if (nodes_utility::containsPoint(target, worldPoint))
                callback(target);
        });
    }
}

void  GameUtils::registerAny(Node* target, const cocos2d::ui::Widget::ccWidgetClickCallback&)
{
    // auto listener = EventListenerTouchOneByOne::create();
}

void GameUtils::enableHideAny(cocos2d::Node* uiRoot, int tag, const std::function<bool(Node*)>& hideFunc)
{
    enableHideAny(findDescendant(uiRoot, tag, true));
}

void GameUtils::enableHideAny(cocos2d::Node* ui, const std::function<bool(Node*)>& hideFunc)
{
    if (ui != nullptr)
    {
        EventDispatcherEx::getInstance()->addClickListener([=](const Point& p, int){
            if (ui->isVisible())
                hideFunc(ui);
        });
        //EventListenerTouchOneByOne* touchListener = EventListenerTouchOneByOne::create();
        //touchListener->onTouchBegan = [ui, hideFunc](Touch*, Event*)->bool {
        //    if (ui->isVisible())
        //    {
        //        hideFunc(ui);
        //        return false;
        //    }
        //    return false;  // return false;
        //};

        //touchListener->onTouchEnded = [ui, hideFunc](Touch*, Event*) {
        //    /*if (ui->isVisible())
        //    {
        //        hideFunc(ui);
        //    }*/
        //};

        //// EventDispatcherEx::getInstance()->addTouchEventListener(touchListener);
        //Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchListener, ui);
    }
}

void GameUtils::scaledShowUI(Node* uiRoot, int tag, float duration)
{
    auto ui = GameUtils::findDescendant(uiRoot, tag, true);

    scaledShowUI(ui, duration);
}

void GameUtils::scaledHideUI(Node* uiRoot, int tag, float duration)
{
    auto ui = GameUtils::findDescendant(uiRoot, tag, true);

    scaledShowUI(ui, duration);
}

void GameUtils::scaledShowUI(Node* uiNode, float duration)
{
    if (uiNode->isVisible())
        return;

    auto ui = dynamic_cast<ui::Widget*>(uiNode);
    if (ui != nullptr)
    {
        //ui->setTouchEnabled(true);
        //ui->bringToFront();
        ui->setVisible(true);
        ui->setScale(0);
        auto action = cocos2d::Sequence::create(cocos2d::ScaleTo::create(duration, 1.0f),
            cocos2d::ScaleTo::create(0.05f, 0.9f),
            cocos2d::ScaleTo::create(0.05f, 1.0f), nullptr);
        ui->runAction(action);
    }
}

void GameUtils::scaledHideUI(Node* uiNode, float duration)
{
    if (!uiNode->isVisible())
        return;

    auto ui = dynamic_cast<ui::Widget*>(uiNode);
    if (ui != nullptr)
    {
        //ui->setTouchEnabled(false);
        // ui->sendToBack();
        auto action = cocos2d::Sequence::create(cocos2d::ScaleTo::create(duration, 0), cocos2d::Hide::create(), nullptr);
        ui->runAction(action);
    }
}

#if 0
std::string spiltstring(std::string &str)
{
    std::string strC="";
    for (std::string::iterator it = str.begin(); it != str.end();)
    {
        if (JUDGELETTER_CLASSIC(*it))
        {
            strC +=(*it);
            it = str.erase(it);
        }
        else
        {
            break;
        }
    }
    return strC;
}
#endif
int Add(char *dec, int num, char hex)
{
    int i, nCarry;
    if (hex >= 'a' && hex <= 'f' || hex >= 'A' && hex <= 'F')
        nCarry = (hex & 0x0f) + 9;
    else
        nCarry = hex & 0x0f;

    for (i = 0; nCarry > 0 && i < num; i++)
    {
        nCarry += dec[i] - '0';
        dec[i] = nCarry % 10 + '0';
        nCarry /= 10;
    }
    if (nCarry > 0)
    {
        dec[num] = nCarry + '0';
        return num + 1;
    }
    else
        return num;
}
int Mult16(char *dec, int num)
{
    int i, nCarry;
    nCarry = 0;
    for (i = 0; i < num; i++)
    {
        nCarry += (dec[i] - '0') * 16;
        dec[i] = nCarry % 10 + '0';
        nCarry /= 10;
    }
    while (nCarry > 0)
    {
        dec[num++] = nCarry % 10 + '0';
        nCarry /= 10;
    }
    return num;
}

int hexToDec(std::string& str)
{
    char *hex = const_cast <char*>(str.c_str());
    char dec[1000];

    int i, num, ndec;
    char ch;
    num = strlen(hex);
    dec[0] = '0';
    ndec = 1;
    for (i = 0; i < num; i++)
    {
        ndec = Mult16(dec, ndec);
        ndec = Add(dec, ndec, hex[i]);
    }
    for (i = 0; i < ndec / 2; i++)
    {
        ch = dec[i];
        dec[i] = dec[ndec - 1 - i];
        dec[ndec - 1 - i] = ch;
    }   dec[ndec] = 0;

    int mynum = atoi(dec);
    return mynum;
}



Node* GameUtils::createRichTextByStringKey(const std::string& msg)
{
    auto richText = RichText::create();
    richText->ignoreContentAdaptWithSize(false);

    // _richText->setContentSize(Size(100, 100));

    auto subtitletable = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SUBTITLES, true);
    auto& description = subtitletable->getStringForForKey(msg);

    struct FontStyleDef {
        Color3B fontColor = Color3B::WHITE;
        float fontSize = 30;
        int outlineSize = 0;
        Color3B outlineColor = Color3B::BLACK;
        std::string fontName = "fonts/edosz-chs.ttf";
    } currentStyleDef;

    enum {
        parse_state_normal,
        parse_state_format
    } parse_state = parse_state_normal;

    std::string format;
    std::string textBlock;
    int textBlockCount = 0;
    for (auto ch : description)
    {
        switch (parse_state)
        {
        case parse_state_normal:
            if (ch == '{') {
                if (!textBlock.empty())
                {
                    RichElementText* re = RichElementText::create(++textBlockCount,
                        currentStyleDef.fontColor,
                        255,
                        textBlock,
                        currentStyleDef.fontName,
                        currentStyleDef.fontSize,
                        0,
                        "",
                        currentStyleDef.outlineColor,
                        currentStyleDef.outlineSize);
                    richText->pushBackElement(re);

                    textBlock.clear();
                }
                parse_state = parse_state_format;
            }
            else {
                textBlock.push_back(ch);
            }
            break;
        case parse_state_format:
            if (ch != '}') {
                format.push_back(ch);
            }
            else { // format end
                // parse & update currentStyleDef
                int index = 0;
                nsc::split(format.c_str(), format.length(), ",", 1, [&](const char* vstart, const char* vend){
                    switch (++index) {
                    case 1:
                        currentStyleDef.fontColor = color_utility::toccc3b(std::strtol(("0x" + std::string(vstart, vend)).c_str(), 0, 16));
                        break;
                    case 2:
                        currentStyleDef.fontSize = strtoi_s(vstart, vend - vstart);
                        break;
                    case 3:
                        currentStyleDef.outlineSize = strtoi_s(vstart, vend - vstart);
                        break;
                    case 4:
                        currentStyleDef.outlineColor = color_utility::toccc3b(std::strtol(("0x" + std::string(vstart, vend)).c_str(), 0, 16));
                        break;
                    case 5:
                        currentStyleDef.fontName += "fonts/";
                        currentStyleDef.fontName.append(vstart, vend);
                        break;
                    }
                });

                format.clear();
                parse_state = parse_state_normal;
            }
            break;
        }
    }

    if (!textBlock.empty())
    {
        RichElementText* re = RichElementText::create(++textBlockCount,
            currentStyleDef.fontColor,
            255,
            textBlock,
            currentStyleDef.fontName,
            currentStyleDef.fontSize,
            0,
            "",
            currentStyleDef.outlineColor,
            currentStyleDef.outlineSize);
        richText->pushBackElement(re);

        textBlock.clear();
    }

    return richText;

#if 0
    //auto textPtr = getStringForKey(msg);
    //if (textPtr.empty())
    //	auto& describle = msg;
    //else
    //	;
    // auto& describle = msg;

    //�ֽ��ַ���
    auto vs = nsc::split(describle.c_str(), "|c");
    int i = 1;
    for (auto s : vs)
    {
        auto vss = nsc::split(s.c_str(), "#");
        auto strC = vss[0];

        auto c3 = color_utility::toccc3b(nsc::to_numeric<uint32_t>("0x" + strC, std::hex));
        RichElementText * re = RichElementText::create(i, c3, 255, vss[1], "SimSun", 24);
        _richText->pushBackElement(re);
        i++;
    }
    return _richText;
#endif
}

inline
bool replace_once(std::string& string, const std::string& replaced_key, const std::string& replacing_key)
{
    std::string::size_type pos = 0;
    if ((pos = string.find(replaced_key, pos)) != std::string::npos)
    {
        (void)string.replace(pos, replaced_key.length(), replacing_key);
        pos += replacing_key.length();
        return true;
    }
    return false;
}

Node* GameUtils::createRichTextByStringKey(const std::string& msg, const std::vector<std::string>& args)
{
    auto richText = RichText::create();
    richText->ignoreContentAdaptWithSize(false);

    // _richText->setContentSize(Size(100, 100));

    auto subtitletable = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SUBTITLES, true);
    auto& description = subtitletable->getStringForForKey(msg);

    struct FontStyleDef {
        Color3B fontColor = Color3B::WHITE;
        float fontSize = 30;
        int outlineSize = 0;
        Color3B outlineColor = Color3B::BLACK;
        std::string fontName = "fonts/edosz-chs.ttf";
    } currentStyleDef;

    enum {
        parse_state_normal,
        parse_state_format
    } parse_state = parse_state_normal;

    std::string format;
    std::string textBlock;
    int textBlockIndex = 0;
    int formatIndex = 0;
    for (auto ch : description)
    {
        switch (parse_state)
        {
        case parse_state_normal:
            if (ch == '{') {
                if (!textBlock.empty())
                {
                    if (formatIndex < args.size() && replace_once(textBlock, "%s", args[formatIndex])) {
                        ++formatIndex;
                    }

                    RichElementText* re = RichElementText::create(++textBlockIndex,
                        currentStyleDef.fontColor,
                        255,
                        textBlock,
                        currentStyleDef.fontName,
                        currentStyleDef.fontSize,
                        0,
                        "",
                        currentStyleDef.outlineColor,
                        currentStyleDef.outlineSize);
                    richText->pushBackElement(re);

                    textBlock.clear();
                }
                parse_state = parse_state_format;
            }
            else {
                textBlock.push_back(ch);
            }
            break;
        case parse_state_format:
            if (ch != '}') {
                format.push_back(ch);
            }
            else { // format end
                // parse & update currentStyleDef
                int index = 0;
                nsc::split(format.c_str(), format.length(), ",", 1, [&](const char* vstart, const char* vend){
                    switch (++index) {
                    case 1:
                        currentStyleDef.fontColor = color_utility::toccc3b(std::strtol(("0x" + std::string(vstart, vend)).c_str(), 0, 16));
                        break;
                    case 2:
                        currentStyleDef.fontSize = strtoi_s(vstart, vend - vstart);
                        break;
                    case 3:
                        currentStyleDef.outlineSize = strtoi_s(vstart, vend - vstart);
                        break;
                    case 4:
                        currentStyleDef.outlineColor = color_utility::toccc3b(std::strtol(("0x" + std::string(vstart, vend)).c_str(), 0, 16));
                        break;
                    case 5:
                        currentStyleDef.fontName += "fonts/";
                        currentStyleDef.fontName.append(vstart, vend);
                        break;
                    }
                });

                format.clear();
                parse_state = parse_state_normal;
            }
            break;
        }
    }

    if (!textBlock.empty())
    {
        if (formatIndex < args.size() && replace_once(textBlock, "%s", args[formatIndex])) {
            ++formatIndex;
        }

        RichElementText* re = RichElementText::create(++textBlockIndex,
            currentStyleDef.fontColor,
            255,
            textBlock,
            currentStyleDef.fontName,
            currentStyleDef.fontSize,
            0,
            "",
            currentStyleDef.outlineColor,
            currentStyleDef.outlineSize);
        richText->pushBackElement(re);

        textBlock.clear();
    }

    return richText;

#if 0
    //auto textPtr = getStringForKey(msg);
    //if (textPtr.empty())
    //	auto& describle = msg;
    //else
    //	;
    // auto& describle = msg;

    //�ֽ��ַ���
    auto vs = nsc::split(describle.c_str(), "|c");
    int i = 1;
    for (auto s : vs)
    {
        auto vss = nsc::split(s.c_str(), "#");
        auto strC = vss[0];

        auto c3 = color_utility::toccc3b(nsc::to_numeric<uint32_t>("0x" + strC, std::hex));
        RichElementText * re = RichElementText::create(i, c3, 255, vss[1], "SimSun", 24);
        _richText->pushBackElement(re);
        i++;
    }
    return _richText;
#endif
}

//�ַ���
const std::string GameUtils::getStringForKey(const std::string& key)
{
    auto subtitletable = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SUBTITLES, true);
    auto& description = subtitletable->getStringForForKey(key);

    enum {
        parse_state_normal,
        parse_state_format
    } parse_state = parse_state_normal;

    std::string text;
    int textBlockCount = 0;
    for (auto ch : description)
    {
        switch (parse_state)
        {
        case parse_state_normal:
            if (ch == '{') {
                parse_state = parse_state_format;
            }
            else {
                text.push_back(ch);
            }
            break;
        case parse_state_format:
            if (ch == '}') {
                parse_state = parse_state_normal;
            }
            break;
        }
    }

    return std::move(text);
#if 0
    std::string temps;
    auto subtablle = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SUBTITLES, true);
    auto& describle = subtablle->getStringForForKey(key);
    if (describle.empty())
    {
        temps = key;
        return std::move(temps);
    }
    auto vs = nsc::split(describle.c_str(), "|c");
    for (auto s : vs)
    {
        auto vss = nsc::split(s.c_str(), "#");
        temps += vss[1];
    }
    return std::move(temps);
#endif
}


const std::vector<int>&  GameUtils::generateOneNumber(int size)
{
    int tnum = size > 3 ? 3 : size;        //���һ�����ݵĴ�С

    std::vector<int> vnumber;
    vnumber.clear();
    std::default_random_engine e((unsigned int)time(NULL));
    std::uniform_int_distribution<unsigned> u(0, size);
    do
    {
        int num = u(e);
        for (auto n : vnumber)
        {
            if (num == n)
            {
                continue;
            }
        }
        vnumber.push_back(num);

        if (vnumber.size() == tnum)
        {
            break;
        }
    } while (1);

    return std::move(vnumber);
}

Node* GameUtils::simplePlayTimeline(const char* csbFileTimeline, int startFrameForLoop, int endFrameForLoop, int startFrame)
{
    auto node = CSLoader::createNode(csbFileTimeline);
    if (node != nullptr) {
        TimelineAnimate tl(false);
        tl.setup(csbFileTimeline);
        // tl.play(node, true);
        tl.playLooped(node, startFrameForLoop, endFrameForLoop, startFrame);
    }
    return node;
}

Node* GameUtils::simplePlayTimeline(const char* csbFileTimeline, bool loop, bool autoRemove)
{
    auto node = CSLoader::createNode(csbFileTimeline);
    if (node != nullptr) {
        TimelineAnimate tl(false);
        tl.setup(csbFileTimeline);
        tl.play(node, loop, "SIPLY", [=]{
            if (autoRemove)
            {
                node->removeFromParent();
            }
        });
    }
    return node;
}

void GameUtils::showProgress(const std::string& msg, bool immediately, Node* explicitScene)
{
    auto scene = explicitScene;
    if (nullptr == scene) {
        scene = Director::getInstance()->getRunningScene();
    }

    GameUtils::hideProgress(scene);

    if (scene->getChildByTag(kProgressLayerTag) != nullptr)
        return;

    auto model = createModelLayer(Color4B(0, 0, 0, 0));
    model->setTag(kProgressLayerTag);
    scene->addChild(model, std::numeric_limits<int>::max() / 4);
    nodes_layout::centerNode(model);

    auto visual = simplePlayTimeline("la_anim_jiazai.csb", 30, 110, !immediately ? 0 : 29);
    model->addChild(visual);
    nodes_layout::centerNode(visual);

    auto lblTips = dynamic_cast<ui::Text*>(findDescendant(visual, "Text_tips"));
    if (!msg.empty()) {
        lblTips->setString(msg);
    }
    else {
        lblTips->setString(iconvw::g2u("���Ժ󡣡���"));
    }
}

void GameUtils::hideProgress(Node* explicitScene)
{
    auto scene = explicitScene;
    if (nullptr == scene) {
        scene = Director::getInstance()->getRunningScene();
    }

    if (scene != nullptr) {
        scene->removeChildByTag(kProgressLayerTag);
    }
}

void GameUtils::updateProgressTitle(const std::string& msg, Node* explicitScene)
{
    auto scene = explicitScene;
    if (nullptr == scene) {
        scene = Director::getInstance()->getRunningScene();
    }

    if (scene != nullptr) {
        auto visualParent = scene->getChildByTag(kProgressLayerTag);
        if (visualParent != nullptr) {
            auto visual = visualParent->getChildren().at(0);
            auto lblTips = dynamic_cast<ui::Text*>(findDescendant(visual, "Text_tips"));
            if (!msg.empty()) {
                lblTips->setString(msg);
            }
            else {
                lblTips->setString(msg);
            }
        }
    }
}


Node* GameUtils::showDialog(const std::string& msg, const std::function<void()>& onOK, const std::function<void()>& onCancel)
{
    auto model = createModelLayer();
    auto scene = Director::getInstance()->getRunningScene();

    if (scene->getChildByTag(kUniqueDialogTag) != nullptr) {
        scene->removeChildByTag(kUniqueDialogTag);
    }

    model->setTag(kUniqueDialogTag);
    scene->addChild(model, std::numeric_limits<int>::max() / 4);
    nodes_layout::centerNode(model);

    auto dialog = CSLoader::createNode("la_game_tips.csb");
    model->addChild(dialog);
    nodes_layout::centerNode(dialog);

    // dynamic_cast<ui::Widget*>(dialog)->setTouchEnabled(true);
    dynamic_cast<ui::Text*>(GameUtils::findDescendant(dialog, "Text_1"))->setText(msg);

    GameUtils::uiRegister(dialog, "Button_ok", [onOK, model](cocos2d::Ref*){
        if (onOK)
            onOK();

        model->removeFromParent();
    });

    GameUtils::uiRegister(dialog, "Button_ok_0", [onCancel, model](cocos2d::Ref*){
        if (onCancel)
            onCancel();

        model->removeFromParent();
    });

    return model;
}

void GameUtils::hideDialog()
{
    auto scene = Director::getInstance()->getRunningScene();
    if (scene != nullptr) {
        scene->removeChildByTag(kUniqueDialogTag);
    }
}
