#include "LuaSupport.h"

#include "cocosdenshion/lua_cocos2dx_cocosdenshion_manual.h"
#include "network/lua_cocos2dx_network_manual.h"
#include "cocosbuilder/lua_cocos2dx_cocosbuilder_manual.h"
#include "cocostudio/lua_cocos2dx_coco_studio_manual.hpp"
#include "extension/lua_cocos2dx_extension_manual.h"
#include "ui/lua_cocos2dx_ui_manual.hpp"
#include "spine/lua_cocos2dx_spine_manual.hpp"
#include "3d/lua_cocos2dx_3d_manual.h"
#include "audioengine/lua_cocos2dx_audioengine_manual.h"
#include <ui/CocosGUI.h>
#include "LuaBasicConversions.h"
#include "lauto/lua_thisapp_auto.hpp"
#include "lua_thisapp_manual.hpp"

#include "purelib/NXNodesLayout.h"
#include "purelib/platform/NXNativeUtils.h"
#include <unordered_map>
#include "GameUtils.h"
#include "battle/Effect.h"
#include "battle/BattleScene.h"
#include "battle/BattleFieldController.h"
#include "battle/BattleField.h"
#include "purelib/NXSharedPtr.h"
#include "purelib/utils/object_pool.h"
#include "ShaderManager.h"
//#include "purelib/NXProgressLayer.h"
#include "purelib/UXProgressBar.hpp"

#include "purelib/utils/iconvw.h"
#include "GameOptions.h"
#include "AudioEngine.h"

#include "purelib/platform/ol/NXOLPayment.h"

#ifdef _WIN32
#if !defined(WINRT)
#pragma comment(lib, "lua51.lib")
#endif
#endif

#define LAYOUTV_DEF_0(layoutFunc) \
    static int layoutv_##layoutFunc(lua_State* L) \
{ \
    if (lua_gettop(L) >= 1) { \
        cocos2d::Node* target = nullptr; \
        auto ok = luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &target); \
        \
        nodes_layout::layoutFunc(target); \
                                                    								    	                } \
    return 0; \
}

#define LAYOUTV_DEF_1(layoutFunc) \
    static int layoutv_##layoutFunc(lua_State* L) \
{ \
    if (lua_gettop(L) >= 3) { \
        cocos2d::Node* target = nullptr; \
        auto ok = luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &target); \
        auto r = lua_tonumber(L, 2); \
        auto t = lua_tonumber(L, 3); \
        \
        nodes_layout::layoutFunc(target, Vec2(r, t)); \
                                                    								    	        } \
    return 0; \
}

#define LAYOUTVA_DEF_0(layoutFunc) \
    static int layoutva_##layoutFunc(lua_State* L) \
{ \
    if (lua_gettop(L) >= 1) { \
        cocos2d::Node* target = nullptr; \
        auto ok = luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &target); \
        \
        nodes_layout::vscr::layoutFunc(target); \
                                                    							    	                } \
    return 0; \
}

#define LAYOUTVA_DEF_1(layoutFunc) \
    static int layoutva_##layoutFunc(lua_State* L) \
{ \
    if (lua_gettop(L) >= 3) { \
        cocos2d::Node* target = nullptr; \
        auto ok = luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &target); \
        auto r = lua_tonumber(L, 2); \
        auto t = lua_tonumber(L, 3); \
        \
        nodes_layout::vscr::layoutFunc(target, Vec2(r, t)); \
                                                    							    	        } \
    return 0; \
}

LAYOUTV_DEF_0(centerNode)
LAYOUTV_DEF_0(centerNodeX)
LAYOUTV_DEF_1(setNodeLT)
LAYOUTV_DEF_1(setNodeRT)
LAYOUTV_DEF_1(setNodeLB)
LAYOUTV_DEF_1(setNodeRB)

LAYOUTVA_DEF_0(centerNode)
LAYOUTVA_DEF_0(centerNodeX)
LAYOUTVA_DEF_1(setNodeLT)
LAYOUTVA_DEF_1(setNodeRT)
LAYOUTVA_DEF_1(setNodeLB)
LAYOUTVA_DEF_1(setNodeRB)

/// --- battle pseudo rand algorithm
static int _luax_holdrand = 0; // random seed
static unsigned long long _luax_rand_seq = 0;
static int luax_pseudo_rand(
    void
    )
{
    ++_luax_rand_seq;
    return (((_luax_holdrand = _luax_holdrand * 214013L + 2531011L) >> 16) ^ _luax_rand_seq & 0x7fff);
}

void luax_pseudo_setseed(int seed)
{
    _luax_rand_seq = 0;
    _luax_holdrand = seed;
}

void printLuaCallStack() {
    luax_pvcall("zysj.printTraceBack");
}

/// === end pseudo rand algorithm

static int lua_nativel_rand(lua_State* L)
{
    lua_pushinteger(L, luax_pseudo_rand());

    return 1;
}

// luax rand debug
static int lua_nativel_rand_seq(lua_State* L)
{
    lua_pushinteger(L, _luax_rand_seq);

    return 1;
}

static int lua_nativel_rand_setseq(lua_State* L)
{
    const char* func = __FUNCTION__;
    auto argc = lua_gettop(L);
    if (argc >= 1) {
        bool  ok = true;
        long long calls = 0;
        luax_retrive_arg(L, func, 1, calls, ok);
        _luax_rand_seq = calls;
    }

    return 0;
}

static int lua_nativel_rand_setseed(lua_State* L)
{
    const char* func = __FUNCTION__;
    auto argc = lua_gettop(L);
    if (argc >= 1) {
        bool  ok = true;
        int seed = 0;
        luax_retrive_arg(L, func, 1, seed, ok);
        luax_pseudo_setseed(seed);
    }

    return 0;
}

static int lua_nativel_showProgress(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;
    bool ok = true;
    if (argc >= 1) {
        std::string msg;
        bool immediately = false;
        cocos2d::Node* scene = nullptr;
        luax_retrive_arg(L, func, 1, msg, ok);
        if (argc >= 2) {
            luax_retrive_arg(L, func, 2, immediately, ok);
            if (argc >= 3) {
                luax_retrive_arg(L, func, 3, scene, ok);
            }
        }

        GameUtils::showProgress(msg, immediately, scene);
    }
    else {
        GameUtils::showProgress();
    }

    return 0;
}

static int lua_nativel_hideProgress(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    bool ok = true;
    if (argc >= 0) {
        cocos2d::Node* scene = nullptr;
        if (argc >= 1) {
            luax_retrive_arg(L, func, 1, scene, ok);
        }
        GameUtils::hideProgress(scene);
    }

    return 0;
}

static int lua_nativel_updateProgressTitle(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;
    bool ok = true;
    if (argc >= 1) {
        std::string msg;
        cocos2d::Node* scene = nullptr;
        luax_retrive_arg(L, func, 1, msg, ok);
        if (argc >= 2) {
            luax_retrive_arg(L, func, 2, scene, ok);
        }

        GameUtils::updateProgressTitle(msg, scene);
    }

    return 0;
}

static int lua_nativel_changeParent(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        Node* target = nullptr, *newParent = nullptr;
        bool worldPointLocked = false;
        size_t slen = 0, dl = 0;
        luax_retrive_arg(L, func, 1, target, ok);
        luax_retrive_arg(L, func, 2, newParent, ok);
        if (argc >= 3)
            luax_retrive_arg(L, func, 3, worldPointLocked, ok);

        if (ok && target != nullptr && newParent != nullptr)
            nodes_utility::changeNodeParent(target, newParent, worldPointLocked);
    }

    return 0;
}

/* end of CLASS LuaFunc */

static int lua_nativel_getTargetPlatform(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    lua_pushinteger(L, CC_TARGET_PLATFORM);

    return 1;
}

static int lua_nativel_split(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        const char* source = nullptr, *delims = nullptr;
        size_t slen = 0, dl = 0;
        luax_retrive_arg(L, func, 1, source, slen, ok);
        luax_retrive_arg(L, func, 2, delims, dl, ok);

        lua_newtable(L);
        if (source != nullptr || delims != nullptr)
        {
            int n = 0;
            nsc::split(source, slen, delims, dl, [&](const char* start, const char* end){
                lua_pushlstring(L, start, end - start);
                lua_rawseti(L, -2, ++n);
            });
        }
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}

static int lua_nativel_sreplace(lua_State* L)
{ // LUA signature: nativel.sreplace(str,replaced,replacing);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 3) {
        bool ok = true;
        std::string origin, replaced, replacing;
        luax_retrive_arg(L, func, 1, origin, ok);
        luax_retrive_arg(L, func, 2, replaced, ok);
        luax_retrive_arg(L, func, 3, replacing, ok);

        nsc::replace(origin, replaced, replacing);
        lua_pushlstring(L, origin.c_str(), origin.size());
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}
//nativel.execv  ��ִ��һ��
//nativel.execlc  ѭ��ִ��ĳһ���б�
//nativel.execl   ѭ��ִ��ĳһ���¼�
static int lua_nativel_execv(lua_State* L)
{ // LUA signature: nativel.execv(0.09, func); // run func once
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        float delay = 0.0f;
        SharedPtr<LuaFunc> luaFunc;

        luax_retrive_arg(L, func, 1, delay, ok);
        luax_retrive_arg(L, func, 2, luaFunc, ok);

        if (ok)
        {
            char key[128];
            sprintf(key, "LUAX_TIMER_D_%d", luaFunc->Id());
            Director::getInstance()->getScheduler()->schedule([luaFunc](float dt){ // lambda expression hold the reference of luaFunc automatically.
                luax_vcall(luaFunc->Id());
            }, luaFunc.get(), 0, 0, delay, false, key);

            lua_pushlightuserdata(L, luaFunc.get());
            return 1;
        }
    }
    return 0;
}

static int lua_nativel_execl(lua_State* L)
{ // LUA signature: local id = nativel.execl(0.09, func);
    auto argc = lua_gettop(L);

    if (argc >= 2) {
        const char* func = __FUNCTION__;
        bool ok = true;
        float interval = 0.0f;
        SharedPtr<LuaFunc> luaFunc;

        luax_retrive_arg(L, func, 1, interval, ok);
        luax_retrive_arg(L, func, 2, luaFunc, ok);

        if (ok)
        {
            char key[128];
            sprintf(key, "LUAX_TIMER_L_%d", luaFunc->Id());
            Director::getInstance()->getScheduler()->schedule([luaFunc](float dt){
                luax_vcall(luaFunc->Id(), dt);
            }, luaFunc.get(),
                interval,
                CC_REPEAT_FOREVER,
                interval,
                false,
                key);

            lua_pushlightuserdata(L, luaFunc.get());
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int lua_nativel_execlc(lua_State* L)
{ // LUA signature: local id = nativel.execlc(0.09, times, func);
    auto argc = lua_gettop(L);

    if (argc >= 2) {
        const char* func = __FUNCTION__;
        bool ok = true;
        float interval = 0.0f;
        int times = 0;
        SharedPtr<LuaFunc> luaFunc;

        luax_retrive_arg(L, func, 1, interval, ok);
        luax_retrive_arg(L, func, 2, times, ok);
        luax_retrive_arg(L, func, 3, luaFunc, ok);

        if (ok)
        {
            static long long s_totalAcc = 0;

            ++s_totalAcc;
            std::string key;
            key.resize(256);
            key.resize(sprintf(&key.front(), "LUAX_TIMER_LC_%lld", s_totalAcc));
            Director::getInstance()->getScheduler()->schedule([luaFunc, key](float dt){ // Will unschedule automatically when complete.
                luax_vcall(luaFunc->Id(), dt);
            }, luaFunc.get(), interval, times - 1, interval, false, key);

            return 0;
        }
    }

    return 0;
}

static int lua_nativel_kill(lua_State* L)
{ // LUA signature: nativel.kill(id);
    auto argc = lua_gettop(L);

    if (argc >= 1) {
        bool ok = true;
        void* id = nullptr;
        luax_retrive_arg(L, __FUNCTION__, 1, id, ok);

        if (ok && id != nullptr) {
            LuaFunc* luaFunc = (LuaFunc*)id;
            char key[128];
            sprintf(key, "LUAX_TIMER_L_%d", luaFunc->Id());

            cocos2d::log("lua_nativel_kill: killing timer id:%d", luaFunc->Id());

            Director::getInstance()->getScheduler()->unschedule(key, id);
        }
    }

    return 0;
}

static int lua_nativel_stopAllUIEvents(lua_State* L)
{

    const char* func = __FUNCTION__;

    bool ok = true;
    cocos2d::Node* root = nullptr;

    auto battleObj = BattleScene::thisObject();
    battleObj->stopAllUIEvents();

    return 0;
}

static int lua_nativel_setDesignationLocation(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 2)
    {
        bool ok = true;
        float point_x = 0.0f;
        float point_y = 0.0f;

        luax_retrive_arg(L, func, 1, point_x, ok);
        luax_retrive_arg(L, func, 2, point_y, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setDesignationLocation(point_x, point_y);
    }
    return 0;
}

static int lua_nativel_setIsDrama(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isDrama = false;

        luax_retrive_arg(L, func, 1, isDrama, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsDrama(isDrama);
    }
    return 0;
}

static int lua_nativel_setIsDramaSoldierDelete(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isDel = false;

        luax_retrive_arg(L, func, 1, isDel, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsDramaSoldierDelete(isDel);
    }
    return 0;
}

static int lua_nativel_setIsDramaConditionOk(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isOk = true;

        luax_retrive_arg(L, func, 1, isOk, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsDramaConditionOk(isOk);
    }
    return 0;
}

static int lua_nativel_getIsDramaConditionOk(lua_State* L)
{

    auto n = BattleScene::thisObject()->getIsDramaConditionOk();

    lua_pushboolean(L, n);

    return 1;
}

static int lua_nativel_setChapterIndex(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        int index = 0;

        luax_retrive_arg(L, func, 1, index, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setChapterIndex(index);
    }
    return 0;
}

static int lua_nativel_setNPlayerIndex(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        int index = 0;

        luax_retrive_arg(L, func, 1, index, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setNPlayerIndex(index);
    }
    return 0;
}

static int lua_nativel_handleGameEnd(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isWin = true;

        luax_retrive_arg(L, func, 1, isWin, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->handleGameEnd(isWin);
    }
    return 0;
}

static int lua_nativel_notifyTurnOver(lua_State* L)
{
    auto argc = lua_gettop(L);

    if (argc == 0)
    {
        BattleData::getInstance()->notifyTurnOver();
    }
    return 0;
}

static int lua_nativel_getLocalStep(lua_State* L)
{
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc == 0) {
        auto num = BattleData::getInstance()->queryData(VDI_STEP, true);
        lua_pushnumber(L, num);
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}

static int lua_nativel_findNodeByName(lua_State* L)
{ // LUA signature: nativel.findNodeByName(root,name,recursively/*optional*/);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        cocos2d::Node* root = nullptr;
        const char* name = "";
        bool recursively = true;

        luax_retrive_arg(L, func, 1, root, ok);
        luax_retrive_arg(L, func, 2, name, ok);

        if (argc >= 3)
            recursively = !!lua_toboolean(L, 3);

        auto n = GameUtils::findDescendant(root, name, recursively);

        object_to_luaval<Node>(L, "cc.Node", n);
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}


static int lua_nativel_makeSpriteGray(lua_State* L)
{ // LUA signature: nativel.findNodeByName(root,name,recursively/*optional*/);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 1) {
        bool ok = true;
        cocos2d::Node* root = nullptr;
        const char* name = "";
        bool recursively = true;

        luax_retrive_arg(L, func, 1, root, ok);

        if (ok)
        {
            auto sp = dynamic_cast<Sprite*>(root);
            if (sp != nullptr) {
                // ShaderManager::getInstance()->setShader(ShaderType::COMPLETE_GRAY, sp);
                sp->setGLProgramState(GLProgramState::getPositionTextureGrayGLProgramState(sp->getTexture()));
            }
        }
    }
    return 0;
}

static int lua_nativel_makeSpriteNormal(lua_State* L)
{ // LUA signature: nativel.findNodeByName(root,name,recursively/*optional*/);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 1) {
        bool ok = true;
        cocos2d::Node* root = nullptr;
        const char* name = "";
        bool recursively = true;

        luax_retrive_arg(L, func, 1, root, ok);

        if (ok)
        {
            auto sp = dynamic_cast<Sprite*>(root);
            if (sp != nullptr) {
                sp->setGLProgramState(GLProgramState::getPositionTextureColorGLProgramState(sp->getTexture()));
            }
            // ShaderManager::getInstance()->setShader(ShaderType::COMPLETE_GRAY, sp);
        }
    }
    return 0;
}

static int lua_nativel_findNodeById(lua_State* L)
{ // LUA signature: nativel.findNodeByName(root,name,recursively/*optional*/);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        cocos2d::Node* root = nullptr;
        int id = 0;
        bool recursively = true;

        luax_retrive_arg(L, func, 1, root, ok);
        luax_retrive_arg(L, func, 2, id, ok);

        if (argc >= 3)
            recursively = !!lua_toboolean(L, 3);

        auto n = GameUtils::findDescendant(root, id, recursively);

        object_to_luaval<Node>(L, "cc.Node", n);
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}

static int lua_nativel_millitime(lua_State* L)
{ // LUA signature: nativel.millitime();
    auto timestamp = millitime();
    lua_pushnumber(L, timestamp);

    return 1;
}

static int lua_nativel_playAnim(lua_State* L)
{ // LUA signature: nativel.playAnim(parent, animPath, loop, autoRemove, endcallback)
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;
    if (argc >= 2) {
        cocos2d::Node* parent = nullptr;
        const char* name = "";
        bool loop = false;
        bool autoRemoveOnFinish = false;
        bool ok = true;// luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &parent);
        SharedPtr<LuaFunc> luaFunc;

        luax_retrive_arg(L, func, 1, parent, ok);
        luax_retrive_arg(L, func, 2, name, ok);
        luax_retrive_arg(L, func, 3, loop, ok);

        if (argc >= 4)
            luax_retrive_arg(L, func, 4, autoRemoveOnFinish, ok);

        if (argc >= 5)
            luax_retrive_arg(L, func, 5, luaFunc, ok);

        if (ok) {
            auto anim = Effect::create(name);
            if (luaFunc == nullptr) {
                anim->playAnimation("animation", loop, autoRemoveOnFinish);
            }
            else {
                anim->playAnimation("animation", loop, autoRemoveOnFinish, [L, luaFunc](BattleObj*){
                    luax_vcall(luaFunc->Id());
                });
            }
            parent->addChild(anim);
            object_to_luaval<Node>(L, "cc.Node", anim); // return to lua
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int lua_nativel_addAnimEventListener(lua_State* L)
{ // LUA signature: nativel.addAnimEventListener(anim,eventName,eventCallback)
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;
    if (argc >= 1) {
        Effect* anim = nullptr;
        const char* name = "";
        SharedPtr<LuaFunc> luaFunc;
        auto ok = true;

        luax_retrive_arg(L, func, 1, anim, ok);
        luax_retrive_arg(L, func, 2, name, ok);
        luax_retrive_arg(L, func, 3, luaFunc, ok);

        if (luaFunc != nullptr)
        {
            anim->addEventListener(name, [L, luaFunc](Node*){
                luax_vcall(luaFunc->Id());
            });
        }
    }

    return 0;
}

static int lua_nativel_attachNodeToAnimSlot(lua_State* L)
{ // lua signature: nativel.attachNodeToAnimSlot(anim, slotName, node)
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;
    if (argc >= 3) {
        auto ok = true;

        Effect* effect = nullptr;
        const char* name = "";
        Node* node = nullptr;

        luax_retrive_arg(L, func, 1, effect, ok);
        luax_retrive_arg(L, func, 2, name, ok);
        luax_retrive_arg(L, func, 3, node, ok);

        if (ok) {
            auto relativeNode = effect->getSkeletonImpl()->associateSlotNode(name);
            if (relativeNode != nullptr)
                relativeNode->addChild(node);
        }
    }

    return 0;
}

static int lua_nativel_pauseAnim(lua_State* L)
{ // lua signature: nativel.pauseAnim(anim)
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 1) {
        Effect* effect = nullptr;
        bool loop = false;
        auto ok = true;
        luax_retrive_arg(L, func, 1, effect, ok);

        effect->getSkeletonImpl()->setTimeScale(0);
    }

    return 0;
}

static int lua_nativel_resumeAnim(lua_State* L)
{ // lua signature: nativel.resumeAnim(anim)
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 1) {
        Effect* effect = nullptr;
        bool loop = false;
        auto ok = true;
        luax_retrive_arg(L, func, 1, effect, ok);

        effect->getSkeletonImpl()->setTimeScale(1.0f);
    }

    return 0;
}

static int lua_nativel_showTips(lua_State* L)
{ // lua sign: showTips(msg)
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc >= 1) {
        bool ok = true;
        const char* msg = "";
        luax_retrive_arg(L, func, 1, msg, ok);

        bool hideGlobalTip = false;
        if (argc >= 2) {
            luax_retrive_arg(L, func, 2, hideGlobalTip, ok);
            if (hideGlobalTip)
                hideTextTag();
        }

        if (ok) {
            createTips(msg);
        }
    }
    else {
        lua_pushnil(L);
    }
    return 1;
}

static int lua_nativel_log(lua_State *L)
{
    if (lua_gettop(L) >= 1) {
        auto check = lua_tostring(L, -1);
        if (check)
            cocos2d::log("[LUA-LOG]:%s", check);
    }
    return 0;
}

static int lua_nativel_setSkeletonHue(lua_State* L)
{ // LUA signature: nativel.setSkeletonHue(effect,hue);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc >= 2) {
        bool ok = true;
        cocos2d::Node* target = nullptr;
        int hue = 0;
        bool recursively = true;

        luax_retrive_arg(L, func, 1, target, ok);
        luax_retrive_arg(L, func, 2, hue, ok);

        auto widget = dynamic_cast<BattleObj*>(target);
        if (widget != nullptr) {
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || _EMULATE_ANDROID
            ShaderManager::getInstance()->enableSpineHue("glsl/etc1_hue_render.frag", widget->getSkeletonImpl(), CC_DEGREES_TO_RADIANS(hue), false);
#else
            ShaderManager::getInstance()->enableSpineHue("glsl/glslx_hue.frag", widget->getSkeletonImpl(), CC_DEGREES_TO_RADIANS(hue), false);
#endif
        }
    }
    return 0;
}

static int lua_nativel_bringToFront(lua_State* L)
{ // LUA signature: nativel.setSkeletonHue(effect,hue);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc == 1) {
        bool ok = true;
        cocos2d::Node* target = nullptr;

        luax_retrive_arg(L, func, 1, target, ok);

        target->bringToFront();
    }
    return 0;
}

static int lua_nativel_sendToBack(lua_State* L)
{ // LUA signature: nativel.setSkeletonHue(effect,hue);
    auto argc = lua_gettop(L);

    const char* func = __FUNCTION__;

    if (argc == 1) {
        bool ok = true;
        cocos2d::Node* target = nullptr;

        luax_retrive_arg(L, func, 1, target, ok);

        target->sendToBack();
    }
    return 0;
}

static int lua_nativel_startPeerAIDriverAndAutoControl(lua_State* L)
{
    auto battleObj = BattleScene::thisObject();

    battleObj->startAIDriverAndAutoControl(battleObj->getPeerController());
    return 0;
}

static int lua_nativel_setIsDramaClickButton(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isOk = false;

        luax_retrive_arg(L, func, 1, isOk, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsDramaClickButton(isOk);
    }
    return 0;
}

static int lua_nativel_setIsDramaSoldierAtk(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isOk = false;

        luax_retrive_arg(L, func, 1, isOk, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsDramaSoldierAtk(isOk);
    }
    return 0;
}

static int lua_nativel_getIsDramaSoldierAtk(lua_State* L)
{

    auto n = BattleScene::thisObject()->getIsDramaSoldierAtk();

    lua_pushboolean(L, n);

    return 1;
}

static int lua_nativel_getEventBlockLayer(lua_State* L)
{

    auto n = BattleScene::thisObject()->getEventBlockLayer();

    object_to_luaval<Node>(L, "cc.Node", n);

    return 1;
}
static int lua_nativel_getNetworkType(lua_State* L)
{
    auto n = NXNativeUtils::getNetworkType();
    lua_pushinteger(L, (LUA_INTEGER)n);
    return 1;
}

static int lua_nativel_showDialog(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;
    if (argc >= 3) {
        std::string msg;
        SharedPtr<LuaFunc> luaFunc_ok;
        SharedPtr<LuaFunc> luaFunc_cancel;
        auto ok = true;

        luax_retrive_arg(L, func, 1, msg, ok);
        luax_retrive_arg(L, func, 2, luaFunc_ok, ok);
        luax_retrive_arg(L, func, 3, luaFunc_cancel, ok);

        if (luaFunc_ok != nullptr && luaFunc_cancel != nullptr)
        {
            GameUtils::showDialog(msg, [=]{luax_vcall(luaFunc_ok); }, [=]{luax_vcall(luaFunc_cancel); });
        }
    }

    return 0;
}


static int lua_nativel_getStringForKey(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;
    if (argc == 1)
    {
        std::string msg;
        bool ok = true;
        luax_retrive_arg(L, func, 1, msg, ok);
        auto ret = GameUtils::getStringForKey(msg);
        tolua_pushstring(L, ret.c_str());
    }
    return 1;
}

static int lua_nativel_createRichTextByStringKey(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;
    if (argc == 1)
    {
        std::string msgkey;
        bool ok = true;
        luax_retrive_arg(L, func, 1, msgkey, ok);
        auto ret = GameUtils::createRichTextByStringKey(msgkey);
        object_to_luaval<Node>(L, "cc.Node", ret);
    }
    else if (argc >= 2) {
        std::string msgkey;
		std::string argMsg;
        bool ok = true;
        luax_retrive_arg(L, func, 1, msgkey, ok);

        std::vector<std::string> args;
        for (int i = 2; i <= argc; ++i) {
			luax_retrive_arg(L, func, i, argMsg, ok);
			args.push_back(std::move(argMsg));
        }

        auto ret = GameUtils::createRichTextByStringKey(msgkey, args);
        object_to_luaval<Node>(L, "cc.Node", ret);
    }

    return 1;
}

static int lua_nativel_setUserMsgFlag(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        int flag = 0;

        luax_retrive_arg(L, func, 1, flag, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setUserMsgFlag(flag);
    }
    return 0;
}

static int lua_nativel_setDramaSavePoint(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        int point = 0;

        luax_retrive_arg(L, func, 1, point, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setDramaSavePoint(point);
    }
    return 0;
}

static int lua_nativel_setIsChapterFirstFight(lua_State* L)
{
    auto argc = lua_gettop(L);
    const char* func = __FUNCTION__;

    if (argc == 1)
    {
        bool ok = true;
        bool isFirst = false;

        luax_retrive_arg(L, func, 1, isFirst, ok);

        auto battleObj = BattleScene::thisObject();
        battleObj->setIsChapterFirstFight(isFirst);
    }
    return 0;
}

static int lua_nativel_setMyDivision(lua_State* L)
{
	auto argc = lua_gettop(L);
	const char* func = __FUNCTION__;

	if (argc == 1)
	{
		bool ok = true;
		int index = 0;

		luax_retrive_arg(L, func, 1, index, ok);

		auto battleObj = BattleScene::thisObject();
		battleObj->setMyDivision(index);
	}
	return 0;
}

static int lua_nativel_setTheirDivision(lua_State* L)
{
	auto argc = lua_gettop(L);
	const char* func = __FUNCTION__;

	if (argc == 1)
	{
		bool ok = true;
		int index = 0;

		luax_retrive_arg(L, func, 1, index, ok);

		auto battleObj = BattleScene::thisObject();
		battleObj->setTheirDivision(index);
	}
	return 0;
}

static int lua_nativel_createModleLayer(lua_State *L)
{
	auto argc = lua_gettop(L);
	const char* func = __FUNCTION__;
	if (argc >= 1)
	{
		//bool ok=true;
		//cocos2d::Color4B color;
		//luax_retrive_arg(L, func, 1, color, ok);
		//auto layer = GameUtils::createModelLayer();
		//object_to_luaval<Layer>(L, "Layer", (Layer*)layer);
		//return 1;
	}
	else
	{
		auto layer = GameUtils::createModelLayer();
		object_to_luaval<cocos2d::Layer>(L, "cc.Layer", (cocos2d::Layer*)layer);
		return 1;
	}
	return 0;

}


//static EventListenerCustom* s_maskScreenListener;
//static CustomCommand s_maskScreenCommand;
// lua signature: nativel.createMaskLayer(ui,size/*optionl*/,opacity/*optional*/)

#define kUniqueMaskTag  201608

static int lua_nativel_removeMaskLayer(lua_State* L)
{
    auto runningScene = Director::getInstance()->getRunningScene();
    if (runningScene != nullptr) {
        runningScene->removeChildByTag(kUniqueMaskTag);
        runningScene->removeChildByTag(kUniqueMaskTag + 1);
    }
    return 0;
}

static int lua_nativel_createMaskLayer(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;
    Node* ui = nullptr;
    Size size = Size(128, 128);
    float opacity = 128;

    if (argc >= 1) {
        luax_retrive_arg(L, func, 1, ui, ok);
        if (ok && argc >= 2) {
            ok &= luaval_to_size(L, 2, &size, func);

            if (ok && argc >= 3)
                luax_retrive_arg(L, func, 3, opacity, ok);
        }
        else
            size = ui->getContentSize();
    }
    else {
        return 0;
    }
    if (ui == nullptr) {
        return 0;
    }

    auto screenSize = Director::getInstance()->getOpenGLView()->getDesignResolutionSize();
    auto pos = ui->getParent()->convertToWorldSpace(ui->getPosition()); // Point(screenSize.width / 2, screenSize.height / 2);

    auto offset = (Point::ANCHOR_MIDDLE - ui->getAnchorPoint());
    offset.x = offset.x * size.width;
    offset.y = offset.y * size.height;

    pos += offset;
    // pos = Point(screenSize.width / 2, screenSize.height / 2);

    auto backg = LayerColor::create(Color4B(0, 0, 0, 255)); // GameUtils::createModelLayer(Color4B(0, 0, 0, 255)); // LayerColor::create(Color4B(0, 0, 0, 255));
    auto mask = cocos2d::Sprite::create("images/shared/mask.png");
    mask->setPosition(pos);
    backg->addChild(mask);

    auto scaleX = (size.width / mask->getContentSize().width);
    auto scaleY = (size.height / mask->getContentSize().height);
    mask->setScale(std::max(scaleX, scaleY));

    auto rtx = RenderTexture::create(screenSize.width, screenSize.height, Texture2D::PixelFormat::RGBA8888);
    rtx->beginWithClear(0, 0, 0, 0);
    backg->visit();
    rtx->end();

    auto finalMask = Sprite::createWithTexture(rtx->getSprite()->getTexture());
    finalMask->setPosition(screenSize.width / 2, screenSize.height / 2);
    finalMask->setScaleY(-1);
    finalMask->setBlendFunc(BlendFunc{ GL_DST_COLOR, GL_SRC_ALPHA }/*BlendFunc{ GL_SRC_ALPHA, GL_ONE }*//*BlendFunc{ GL_DST_COLOR, GL_SRC_ALPHA }*/);
    finalMask->setOpacity(255 - opacity);
    finalMask->setTag(kUniqueMaskTag);
    Director::getInstance()->getRunningScene()->addChild(finalMask);

    auto maskEffect = Effect::create("models/ui_effect/anniu_lashen", 1.0f, EffectAlign::ALIGN_CENTER);
    maskEffect->setPosition(pos);
    maskEffect->playAnimation("animation", true);
    maskEffect->setTag(kUniqueMaskTag + 1);
    auto& maskEffectSize = maskEffect->getContentSize();

    maskEffect->setScale(mask->getScale() /*std::max(size.width / maskEffect->getContentSize().width, size.height / maskEffect->getContentSize().height)*/);
    // maskEffect->setAnchorPoint(ui->getAnchorPoint());
    Director::getInstance()->getRunningScene()->addChild(maskEffect);

    /*auto scaleOriginX = scaleX * 3;
    auto scaleOriginY = scaleY * 3;

    finalMask->setScaleX(scaleOriginX);
    finalMask->setScaleY(scaleOriginY);
    finalMask->runAction(ScaleTo::create(2.0, scaleOriginX, scaleOriginY));*/

    return 0;
}
static int lua_nativel_createSquareMask(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;
    Node* ui = nullptr;
    Size size = Size(128, 128);
    float opacity = 128;

    if (argc >= 1) {
        luax_retrive_arg(L, func, 1, ui, ok);
        if (ok && argc >= 2) {
            ok &= luaval_to_size(L, 2, &size, func);

            if (ok && argc >= 3)
                luax_retrive_arg(L, func, 3, opacity, ok);
        }
        else
            size = ui->getContentSize();
    }
    else {
        return 0;
    }
    if (ui == nullptr) {
        return 0;
    }

    auto screenSize = Director::getInstance()->getOpenGLView()->getDesignResolutionSize();
    auto pos = ui->getParent()->convertToWorldSpace(ui->getPosition()); // Point(screenSize.width / 2, screenSize.height / 2);

    auto offset = (Point::ANCHOR_MIDDLE - ui->getAnchorPoint());
    offset.x = offset.x * size.width;
    offset.y = offset.y * size.height;

    pos += offset;
    // pos = Point(screenSize.width / 2, screenSize.height / 2);

    auto backg = LayerColor::create(Color4B(0, 0, 0, 255)); // GameUtils::createModelLayer(Color4B(0, 0, 0, 255)); // LayerColor::create(Color4B(0, 0, 0, 255));
    auto mask = cocos2d::Sprite::create("images/shared/mask_square.png");
    mask->setPosition(pos);
    backg->addChild(mask);

    auto scaleX = (size.width / mask->getContentSize().width);
    auto scaleY = (size.height / mask->getContentSize().height);
    mask->setScaleX(scaleX);
    mask->setScaleY(scaleY);

    auto rtx = RenderTexture::create(screenSize.width, screenSize.height, Texture2D::PixelFormat::RGBA8888);
    rtx->beginWithClear(0, 0, 0, 0);
    backg->visit();
    rtx->end();

    auto finalMask = Sprite::createWithTexture(rtx->getSprite()->getTexture());
    finalMask->setPosition(screenSize.width / 2, screenSize.height / 2);
    finalMask->setScaleY(-1);
    finalMask->setBlendFunc(BlendFunc{ GL_DST_COLOR, GL_SRC_ALPHA }/*BlendFunc{ GL_SRC_ALPHA, GL_ONE }*//*BlendFunc{ GL_DST_COLOR, GL_SRC_ALPHA }*/);
    finalMask->setOpacity(255 - opacity);
    finalMask->setTag(kUniqueMaskTag);
    Director::getInstance()->getRunningScene()->addChild(finalMask);

    auto maskEffect = Effect::create("models/ui_effect/anniu_fx", 1.0f, EffectAlign::ALIGN_CENTER);
    maskEffect->setPosition(pos);
    maskEffect->playAnimation("animation", true);
    maskEffect->setTag(kUniqueMaskTag + 1);
    auto& maskEffectSize = maskEffect->getContentSize();

    maskEffect->setScaleX(scaleX);
    maskEffect->setScaleY(scaleY);
    // maskEffect->setScale(mask->getScale() /*std::max(size.width / maskEffect->getContentSize().width, size.height / maskEffect->getContentSize().height)*/);
    // maskEffect->setAnchorPoint(ui->getAnchorPoint());
    Director::getInstance()->getRunningScene()->addChild(maskEffect);

    /*auto scaleOriginX = scaleX * 3;
    auto scaleOriginY = scaleY * 3;

    finalMask->setScaleX(scaleOriginX);
    finalMask->setScaleY(scaleOriginY);
    finalMask->runAction(ScaleTo::create(2.0, scaleOriginX, scaleOriginY));*/

    return 0;
}


static int lua_nativel_createMaskLayer3(lua_State* L)
{
    /*if (s_maskScreenListener)
    {
    CCLOG("Warning: CaptureScreen has been called already, don't call more than once in one frame.");
    return 0;
    }*/
    auto finalMask = cocos2d::ClippingNode::create();

    auto visibleSize = Director::getInstance()->getOpenGLView()->getDesignResolutionSize();
    auto pos = Point(visibleSize.width / 2, visibleSize.height / 2);
    auto size = Size(256, 256);
    auto opacity = 128;

    auto bg = LayerColor::create(Color4B(0, 0, 0, opacity));
    auto mask = cocos2d::Sprite::create("images/shared/circle.png");
    mask->setPosition(pos);
    // bg->addChild(mask);

    auto scaleX = (size.width / mask->getContentSize().width);
    auto scaleY = (size.height / mask->getContentSize().height);
    mask->setScaleY(scaleY);
    mask->setScaleX(scaleX);
    // mask->setOpacity(128);

#if 0
    Color4F yellow = { 1, 1, 0, 1 };
    auto front = cocos2d::DrawNode::create();
    // front->drawCircle(Vec2::ZERO, 30, CC_DEGREES_TO_RADIANS(90), 50, false, yellow);
    front->drawSolidCircle(Vec2::ZERO, 90, CC_DEGREES_TO_RADIANS(90), 50, yellow);
    front->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
#endif
    // mask->setBlendFunc(BlendFunc{ GL_ONE, GL_ONE_MINUS_SRC_ALPHA });
    // mask->runAction(RepeatForever::create(Sequence::create(ScaleBy::create(0.05f, 0.95f), ScaleTo::create(0.125f, 1.0f), nullptr)));

    /*����Բ������*/
    //���ò���
    static ccColor4F red = { 1, 0, 0, 1 };//������ɫ����Ϊ��ɫ��������R,G,B,͸����
    float radius = 55.0f;//����Բ�İ뾶
    const int nCount = 200;//���ö��������˴����ǽ�Բ����200����
    const float angel = 2.0f * (float)M_PI / nCount;//�������������ĵļнǣ����ȣ�
    static CCPoint circle[nCount];  //���涥�������
    for (int i = 0; i < nCount; i++){
        float radian = i*angel; //����
        circle[i].x = radius * cosf(radian);//����x����
        circle[i].y = radius * sinf(radian);//����y����
    }
    /*���ƶ����*/
    //ע�ⲻҪ��pStencil addChild
    CCDrawNode *pStencil = CCDrawNode::create();
    pStencil->drawPolygon(circle, nCount, red, 0, red);//������������

    /*��Բ����һ���Ŵ���С����*/
    pStencil->runAction(CCRepeatForever::create(CCSequence::createWithTwoActions(CCScaleBy::create(0.05f, 0.95f),
        CCScaleTo::create(0.125f, 1))));
    pStencil->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
    /*�����Բ�δӼ��ýڵ�����ٳ�����Stencil��ģ�����˼*/
    finalMask->setStencil(pStencil);

    mask->runAction(RepeatForever::create(Sequence::create(ScaleBy::create(0.05f, 0.95f), ScaleTo::create(0.125f, 1.0f), nullptr)));

    // mask->setBlendFunc(BlendFunc{ GL_ONE, GL_ONE });

    finalMask->setInverted(true);
    finalMask->setAlphaThreshold(0);
    finalMask->addChild(bg);


    /* auto rtx = RenderTexture::create(screenSize.width, screenSize.height, Texture2D::PixelFormat::RGBA8888, GL_DEPTH24_STENCIL8);
     rtx->beginWithClear(0, 0, 0, 0);
     bg->visit();
     rtx->end();

     auto finalMask = Sprite::createWithTexture(rtx->getSprite()->getTexture());
     finalMask->setPosition(screenSize.width / 2, screenSize.height / 2);
     finalMask->setScaleY(-1);
     finalMask->setBlendFunc(BlendFunc{ GL_DST_COLOR, GL_SRC_ALPHA });
     finalMask->setOpacity(255 - opacity);*/

    Director::getInstance()->getRunningScene()->addChild(finalMask);
    Director::getInstance()->getRunningScene()->addChild(mask);

    // object_to_luaval(L, "cc.Sprite", finalMask);

    return 1;
}

// lua sigature: audiol.play(id,finishedCallback)
static int lua_audiol_play(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;

    if (argc >= 1) {
        int id = 0;
        luax_retrive_arg(L, func, 1, id, ok);
        SharedPtr<LuaFunc> finishedCallback;
        if (argc >= 2) {
            luax_retrive_arg(L, func, 2, finishedCallback, ok);
        }
        auto tsound = DataSourceCSV::getInstance()->selectTable(VDATA_SRC_SOUND);
        auto& soundProps = tsound->getDataRow(id);
        if (!soundProps.empty()) {
            std::string path("sounds/");
            path.append(soundProps.at(DAI_SOUND_SOUND_FILE).asString());
            auto loop = !!soundProps.at(DAI_SOUND_LOOP).asInt();

            int psid = experimental::AudioEngine::play2d(path, loop);

            if (finishedCallback.get() != nullptr) {
                experimental::AudioEngine::setFinishCallback(psid, [finishedCallback](int id, const std::string& name){
                    luax_vcall(finishedCallback, id, name);
                });
            }

            lua_pushinteger(L, psid);
            return 1;
        }
        else {
            cocos2d::log("@warnning, sound not found, id:%d", id);
        }
    }

    return 0;
}

static int lua_audiol_pause(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;

    if (argc >= 1) {
        int psid = 0;
        luax_retrive_arg(L, func, 1, psid, ok);
        experimental::AudioEngine::pause(psid);
    }

    return 0;
}

static int lua_audiol_resume(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;

    if (argc >= 1) {
        int psid = 0;
        luax_retrive_arg(L, func, 1, psid, ok);
        experimental::AudioEngine::resume(psid);
    }

    return 0;
}

static int lua_audiol_stop(lua_State* L)
{
    auto func = __FUNCTION__;
    auto argc = lua_gettop(L);

    bool ok = true;

    if (argc >= 1) {
        int psid = 0;
        luax_retrive_arg(L, func, 1, psid, ok);
        experimental::AudioEngine::stop(psid);
    }

    return 0;
}

static int lua_audiol_pauseAll(lua_State* L)
{
    experimental::AudioEngine::pauseAll();
    return 0;
}

static int lua_audiol_resumeAll(lua_State* L)
{
    experimental::AudioEngine::resumeAll();
    return 0;
}

static int lua_audiol_stopAll(lua_State* L)
{
    experimental::AudioEngine::stopAll();
    return 0;
}


static int lua_nativel_triggerCrash(lua_State* L)
{
    ((Sprite*)nullptr)->setVisible(false);

    return 0;
}

static int lua_nativel_createProgressBar(lua_State* L)
{
    auto argc = lua_gettop(L);
    bool ok = true;
    Node* bar = nullptr;
    Size barViewSize;
    Node* barToy = nullptr;
    if (argc >= 2) {
        luax_retrive_arg(L, "", 1, bar, ok);
        luaval_to_size(L, 2, &barViewSize);
        if (argc >= 3) {
            luax_retrive_arg(L, "", 3, barToy, ok);
        }
       
        auto node = UXProgressBar::create(bar, barViewSize, barToy);
        object_to_luaval<Node>(L, "cc.Node", node);
        return 1;
    }
    return 0;
}

static int lua_nativel_setProgressBarPercent(lua_State* L)
{
    auto argc = lua_gettop(L);
    bool ok = true;
    Node* progressBar = nullptr;
    float percent = 0;
    if (argc >= 2) {
        luax_retrive_arg(L, "", 1, progressBar, ok);
        luax_retrive_arg(L, "", 2, percent, ok);
        if (ok && progressBar != nullptr)
        {
            static_cast<UXProgressBar*>(progressBar)->setPercent(percent);
        }
    }
    return 0;
}


static int lua_nativel_createBarrier(lua_State* L)
{
    auto argc = lua_gettop(L);
    bool ok = true;
    int modelID = 0;
    bool local = true;
    if (argc >= 2) {
        luax_retrive_arg(L, "", 1, modelID, ok);
        luax_retrive_arg(L, "", 2, local, ok);
        if (ok)
        {
            auto wall = Wall::create(modelID, local);
			auto filed=wall->controller->getBattleField();
			filed->addChild(wall);

            object_to_luaval<Wall>(L, "Wall", (Wall*)wall);
            return 1;
        }
    }
    return 0;
}

/// userchat.clear(type) ; "world","group","private"
static int lua_userdef_clear(lua_State* L)
{
    auto argc = lua_gettop(L);
    bool ok = true;
    bool local = true;
    if (argc >= 1) {
		const char* key;
        std::string type;
		luax_retrive_arg(L, "", 1, key, ok);
		luax_retrive_arg(L, "", 2, type, ok);
        if (ok)
        {
			auto clogs = userdef->get(key);
            clogs.removeMember(type);
			userdef->insert(key, clogs, true);
        }
    }
    return 0;
}

/// userchat.push_back(type,msg) ; "world","group","private"
static int lua_userdef_push_back(lua_State* L)
{ // 50.
    auto argc = lua_gettop(L);
    bool ok = true;
    bool local = true;
    if (argc >= 2) {
		const char* key;
        std::string type;
        std::string msg;
		luax_retrive_arg(L, "", 1, key, ok);
		luax_retrive_arg(L, "", 2, type, ok);
		luax_retrive_arg(L, "", 3, msg, ok);
        if (ok)
        {
			auto clogs = userdef->get(key);
            // if (clogs.isNull()) 
            auto& spec = clogs[type];
            spec.append(msg);
			userdef->insert(key, clogs, true);

            lua_pushinteger(L, spec.size());

            return 1;
            /*auto clogs = userdef->get("chat_logs");
            clogs[type].append(msg);
            userdef->flush();*/
        }
    }
    return 0;
}

// userchat.pop_front(type)
static int lua_userdef_pop_front(lua_State* L)
{ // 50.
    auto argc = lua_gettop(L);
    bool ok = true;
    bool local = true;
    if (argc >= 1) {
		const char* key;
        std::string type;
		luax_retrive_arg(L, "", 1, key, ok);
		luax_retrive_arg(L, "", 2, type, ok);
        if (ok)
        {
			auto clogs = userdef->get(key);
            clogs[type].removeAt(0);
			userdef->insert(key, clogs, true);
        }
    }
    return 0;
}

/// userchat.getall(type) ; "world","group","private"
static int lua_userdef_getall(lua_State* L)
{
    auto argc = lua_gettop(L);
    bool ok = true;
    bool local = true;
    if (argc >= 1) {
		const char* key;
        std::string type;
		luax_retrive_arg(L, "", 1, key, ok);
		luax_retrive_arg(L, "", 2, type, ok);
        if (ok)
        {
			auto clogs = userdef->get(key);
            auto logs = clogs[type];
            
            if (logs.isArray()) {
                oluastream ols(L);
                int index = 0;

                lua_createtable(L, logs.size(), 0);
                for (auto it : logs)
                {
                    ols.write_v(++index, it.asCString());
                }

                return 1;
            }
        }
    }
    return 0;
}

/// appstore
static int lua_appstore_loadProducts(lua_State* L)
{


    return 0;
}

static int lua_appstore_payForProduct(lua_State* L)
{ // should block UI to wait purchase response.


    
    return 0;
}

static luaL_Reg paymentFuncs[] = {
    { "loadProducts", lua_appstore_loadProducts },
    { "payForProduct", lua_appstore_payForProduct },
    { NULL, NULL }
};

static luaL_Reg chatFuncs[] = {
	{ "clear", lua_userdef_clear },
	{ "push_back", lua_userdef_push_back },
	{ "pop_front", lua_userdef_pop_front },
	{ "getall", lua_userdef_getall },
    { NULL, NULL }
};

static luaL_Reg nativelFuncs[] = {
    { "getTargetPlatform", lua_nativel_getTargetPlatform },
    { "split", lua_nativel_split },
    { "sreplace", lua_nativel_sreplace },
    { "execv", lua_nativel_execv },
    { "execl", lua_nativel_execl },
    { "execlc", lua_nativel_execlc },
    { "rand", lua_nativel_rand },
    { "rand_seq", lua_nativel_rand_seq },
    { "rand_setseq", lua_nativel_rand_setseq },
    { "rand_setseed", lua_nativel_rand_setseed },
    { "kill", lua_nativel_kill },
    { "setTimeout", lua_nativel_execv },
    { "setInterval", lua_nativel_execl },
    { "clearInterval", lua_nativel_kill },
    { "centerNode", layoutv_centerNode },
    { "findNode", lua_nativel_findNodeByName },
    { "findNodeById", lua_nativel_findNodeById },
    { "showDialog", lua_nativel_showDialog },
    { "getStringForKey", lua_nativel_getStringForKey },
    { "createRichTextByStringKey", lua_nativel_createRichTextByStringKey },

    { "createBarrier", lua_nativel_createBarrier },

    { "createProgressBar", lua_nativel_createProgressBar },
    { "setProgressBarPercent", lua_nativel_setProgressBarPercent },

    { "playAnim", lua_nativel_playAnim },
    { "pauseAnim", lua_nativel_pauseAnim },
    { "resumeAnim", lua_nativel_resumeAnim },
    { "attachAnimSlotNode", lua_nativel_attachNodeToAnimSlot },
    { "addAnimEventListener", lua_nativel_addAnimEventListener },
    { "showTips", lua_nativel_showTips }, // nativel.showTips(msg);
    { "elog", lua_nativel_log }, // FOR TEST
    { "setIsDramaConditionOk", lua_nativel_setIsDramaConditionOk },
    { "getIsDramaConditionOk", lua_nativel_getIsDramaConditionOk },
    { "setDesignationLocation", lua_nativel_setDesignationLocation },
    { "stopAllUIEvents", lua_nativel_stopAllUIEvents },
    { "setNPlayerIndex", lua_nativel_setNPlayerIndex },
    { "setChapterIndex", lua_nativel_setChapterIndex },
    { "getLocalStep", lua_nativel_getLocalStep },
    { "notifyTurnOver", lua_nativel_notifyTurnOver },
    { "setIsDramaSoldierDelete", lua_nativel_setIsDramaSoldierDelete },
    { "setIsDrama", lua_nativel_setIsDrama },
    { "setSkeletonHue", lua_nativel_setSkeletonHue },
    { "changeParent", lua_nativel_changeParent },
    { "showProgress", lua_nativel_showProgress },
    { "updateProgressTitle", lua_nativel_updateProgressTitle },
    { "hideProgress", lua_nativel_hideProgress },
    { "millitime", lua_nativel_millitime },
    { "bringToFront", lua_nativel_bringToFront },
    { "sendToBack", lua_nativel_sendToBack },
    { "makeSpriteGray", lua_nativel_makeSpriteGray },
    { "makeSpriteNormal", lua_nativel_makeSpriteNormal },
    { "handleGameEnd", lua_nativel_handleGameEnd },
    { "startPeerAIDriverAndAutoControl", lua_nativel_startPeerAIDriverAndAutoControl },
    { "setIsDramaClickButton", lua_nativel_setIsDramaClickButton },
    { "setIsDramaSoldierAtk", lua_nativel_setIsDramaSoldierAtk },
    { "getIsDramaSoldierAtk", lua_nativel_getIsDramaSoldierAtk },
    { "getEventBlockLayer", lua_nativel_getEventBlockLayer },
    { "getNetworkType", lua_nativel_getNetworkType },
    { "setUserMsgFlag", lua_nativel_setUserMsgFlag },
    { "setDramaSavePoint", lua_nativel_setDramaSavePoint },
    { "setIsChapterFirstFight", lua_nativel_setIsChapterFirstFight },
    { "createMaskLayer", lua_nativel_createMaskLayer },
    { "removeMaskLayer", lua_nativel_removeMaskLayer },
    { "triggerCrash", lua_nativel_triggerCrash },
    { "createSquareMask", lua_nativel_createSquareMask },
	{ "setMyDivision", lua_nativel_setMyDivision },
	{ "setTheirDivision", lua_nativel_setTheirDivision },
	{ "createModleLayer", lua_nativel_createModleLayer },
    { NULL, NULL }
};

static luaL_Reg layoutvFuncs[] = {
    { "centerNode", layoutv_centerNode },
    { "centerNodeX", layoutv_centerNodeX },
    { "setNodeLT", layoutv_setNodeLT },
    { "setNodeRT", layoutv_setNodeRT },
    { "setNodeLB", layoutv_setNodeLB },
    { "setNodeRB", layoutv_setNodeRB },

    { NULL, NULL }
};

static luaL_Reg layoutaFuncs[] = {

    { "centerNode", layoutva_centerNode },
    { "centerNodeX", layoutva_centerNodeX },
    { "setNodeLT", layoutva_setNodeLT },
    { "setNodeRT", layoutva_setNodeRT },
    { "setNodeLB", layoutva_setNodeLB },
    { "setNodeRB", layoutva_setNodeRB },

    { NULL, NULL }
};

static luaL_Reg audiolFuncs[] = {
    { "play", lua_audiol_play },
    { "pause", lua_audiol_pause },
    { "resume", lua_audiol_resume },
    { "stop", lua_audiol_stop },
    { "pauseAll", lua_audiol_pauseAll },
    { "resumeAll", lua_audiol_resumeAll },
    { "stopAll", lua_audiol_stopAll },

    { NULL, NULL },
};

extern "C" int luaopen_cjson(lua_State *l);

void luasupport_register_all_modules(lua_State *L)
{
    luax_setVM(L);
    luaL_register(L, "userdef", chatFuncs);
    luaL_register(L, "nativel", nativelFuncs);
    luaL_register(L, "layoutv", layoutvFuncs);
    luaL_register(L, "layouta", layoutaFuncs);
    luaL_register(L, "audiol", audiolFuncs);

    luaL_register(L, "appstore", paymentFuncs);

    luaopen_cjson(L);

#if 0
    register_all_cocos2dx_ui_manual(L);
    //extension module must be registed after ui module
    register_all_cocos2dx_extension_manual(L);
    register_all_cocos2dx_coco_studio_manual(L);
    register_all_cocos2dx_spine_manual(L);
    register_all_cocos2dx_manual(L);
    // register_all_cocos2dx_custom(L);
#else
    register_cocosdenshion_module(L);
    //register_network_module(L);
    //register_cocosbuilder_module(L);
    register_cocostudio_module(L);
    register_ui_moudle(L);
    //register_extension_module(L);
    //register_spine_module(L);
    //register_cocos3d_module(L);
    register_audioengine_module(L);

    register_thisapp_module(L); // pitfall: don't call autog register func directly
#endif
}
/*
template<>
std::vector<cocos2d::Node*> luax_dogetval(lua_State* L, const std::vector<cocos2d::Node*>& default_value)
{
//if (lua_istable(L, -1)){
//	std::vector<cocos2d::Node*> vec;

//	int count = luaL_getn(L, -1);

//	bool checkType = false;
//	for (int i = 1; i <= count; ++i)
//	{
//		Node* n = nullptr;
//		lua_rawgeti(L, -1, i);
//		checkType = lua_islightuserdata(L, -1);
//		checkType = lua_isnil(L, -1);
//		// checkType =
//		auto type = lua_type(L, -1);
//		luaval_to_object<cocos2d::Node>(L, -1, "cc.Node", &n, "");//1,2
//		lua_pop(L, 1);
//		vec.push_back(n);
//	}
//	return std::move(vec);
//}
return default_value;
}
*/
