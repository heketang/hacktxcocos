/// ��Ϸ������
/// Author: xseekerj 2015.7
#ifndef _DLVX_GAME_UTILS_H_
#define _DLVX_GAME_UTILS_H_

#include "cocos2d.h"
#include <ui/CocosGUI.h>
#include <cocostudio/CocoStudio.h>

using namespace cocos2d;
using namespace cocostudio;
#define TAG_NONAME_ANIMATION 201603
#define TAG_NAMED_ANIMATION 201605
class TimelineAnimate
{
public:
    TimelineAnimate(bool reuseAction = true) : reuseAction(reuseAction), timelineAction(nullptr)
	{
	}
	~TimelineAnimate()
	{
		clear();
	}
	void setup(const char* timelineSrc);
	void clear(void);

	void play(Node* target, bool loop);
	void play(Node* target, bool loop, const char key[5], const std::function<void()>& onLastFrame = nullptr);
	void play(Node* target, bool loop, int tag, const std::function<void()>& onLastFrame = nullptr);
	void playOnce(Node* target);
	void playLooped(Node* target, int startFrameForLoop, int endFrameForLoop, int startFrame = 0);
    void play(Node* target, const char* animation, bool loop, const std::function<void()>& onAnimationEnd = nullptr);

    void play(const char* animation, bool loop, const std::function<void()>& onAnimationEnd = nullptr);

    void preserveScale(const char* name);

protected:
    void applyScaleFixed(timeline::ActionTimeline*);
private:
    bool reuseAction;
	timeline::ActionTimeline* timelineAction;
    std::vector<std::string>  scaleNames;
};

class GameUtils
{
public:
    
    typedef std::function<void(void)> ccWidgetCallback;

    /*
    ** @summary: �˳���Ϸ����
    ** @params:
    ** @remark:
    */
    static void exit(void);

    /*
    ** @summary: ����һ�����ֲ�
    ** @params:
    ** @remark:
    */
    static LayerColor* createModelLayer(const Color4B& color = Color4B(0, 0, 0, 128));

    /*
    ** @summary: ��ʾ��Ϸ�ڵ���
    ** @params:
    **      parent: ���ڵ�
    **      resPopup: ������Դ·��: ����: res/tc_tuichu.csb
    ** @remark:
    */
    static Node* showPopup(Node* parent, const char* resPopup);

    static Node* showPopup(Node* parent, const char* resPopup, int tagClose);

    static Node* findDescendant(Node* root, const char* name, bool recursively = true);
    static Node* findDescendant(Node* root, int tag, bool recursively = true);


    /*
    ** @summary: ��ȫע��UI�¼����ص��д������
    ** @params: 
    ** @remark: �¼��ص�������ʽ:
    **          [](cocos2d::Ref*){
    **          }
    */
    static void  uiRegister(cocos2d::Node* uiRoot, const char* name, const cocos2d::ui::Widget::ccWidgetClickCallback&);
    static void  uiRegister(cocos2d::Node* uiRoot, const std::vector<std::string>& names, const cocos2d::ui::Widget::ccWidgetClickCallback&);
    static void  uiRegister(cocos2d::Node* uiRoot, int tag, const cocos2d::ui::Widget::ccWidgetClickCallback&);
    static void  uiRegister(cocos2d::Node* uiRoot, const std::vector<int>& tags, const cocos2d::ui::Widget::ccWidgetClickCallback&);
    static void  uiRegister(/*cocos2d::Node* uiRoot, */Node* target, const cocos2d::ui::Widget::ccWidgetClickCallback&); // the real impl

    static void  registerAny(Node* target, const cocos2d::ui::Widget::ccWidgetClickCallback&);


    static void enableHideAny(cocos2d::Node* uiRoot, int tag, const std::function<bool(Node*)>& hideFunc = [](Node* n){ n->setVisible(false); return false; });
    static void enableHideAny(cocos2d::Node* ui, const std::function<bool(Node*)>& hideFunc = [](Node* n){ n->setVisible(false); return false; });

    static void scaledShowUI(Node* uiRoot, int tag, float duration = 0.3f);
    static void scaledHideUI(Node* uiRoot, int tag, float duration = 0.3f);

    static void scaledShowUI(Node* ui, float duration = 0.3f);
    static void scaledHideUI(Node* ui, float duration = 0.3f);
	
	static const std::vector<int>& generateOneNumber(int size);


	/// showDialog: is model dialog.
	static Node* showDialog(const std::string& msg, const std::function<void()>& onOK, const std::function<void()>& onCancel = nullptr);
    static void hideDialog();
	static const std::string getStringForKey(const std::string& key);
	static const std::string& getStringForKey(int  key);
	static Node* createRichTextByStringKey(const std::string& msg);
    static Node* createRichTextByStringKey(const std::string& key, const std::vector<std::string>& args);

    static Node* simplePlayTimeline(const char* csbFileTimeline, int loopStart, int loopEnd, int startFrame = 0);
    static Node* simplePlayTimeline(const char* csbFileTimeline, bool loop = false, bool autoRemove = true);

    static void showProgress(const std::string& msg = "", bool immediately = false, Node* explicitScene = nullptr);
    static void updateProgressTitle(const std::string& msg, Node* explicitScene = nullptr);
    static void hideProgress(Node* explicitScene = nullptr);
};

#endif // __HELLOWORLD_SCENE_H__
