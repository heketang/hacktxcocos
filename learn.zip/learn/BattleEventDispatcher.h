///
/// ���ܹ���: ��ʿ������һ�ι��������������У���������Ч���������˺���ɣ�������ɺ���ܲ�����ӦBUF
/// ������˲ʱ�ģ��ͷ���ɺ�������ʧ
/// 
#ifndef _BATTLEEVENTDISPATCHER_H_
#define _BATTLEEVENTDISPATCHER_H_
#include "cocos2d.h"
#include "GameDefs.h"
//#include "Unit.h"
#include <unordered_map>
#if 0
#include "InstantaneousFunction.h"
#include "ContinuousFunction.h"
#endif
class Weapon;
class Effect;
class Unit;
class Ability;
class BattleFieldController;
class Soldier;

enum BattleEventType
{
	ON_TURN_ROUND_PEER,
	ON_TURN_ROUND_LOCAL,
	ON_ATTACKING_STARTING,
	ON_ATTACKING_END,
	ON_GAME_END,
	ON_DRAMA_BATTLE_START,
	ON_DRAMA_GUIDE,
	ON_DRAMA_GUIDE_BACK,
	ON_DRAMA_GUIDE_DELETE,
	ON_REWARD_STEP,
	ON_IDLES_INCREASE,
	ON_STEP_REDUCE,
	ON_BACK_PRESS, // only android & windows 10
	ON_SHAKE_END,
    ON_ENTER_ANIMATION_END,
    ON_SOLDIER_INITIALIZED,
};

enum DramaBattleEndType
{
	ON_HERO_DIED = 1,
	ON_ALL_SOLDIER_DIED,
	ON_ID_SOLDIER_DIED,
	ON_ROUND_END,
};

enum DramaBattleFieldType
{
	ON_PEER_FIELD = 1,
	ON_LOCAL_FIELD,
};

union BattleEventParam
{
	BattleEventParam(){ memset(this, 0, sizeof(*this)); }
	BattleEventParam(void* v) : ptrVal(v){}
	BattleEventParam(bool v) : bVal(v){}
	BattleEventParam(int v) : iVal(v){}
	BattleEventParam(float v) : fVal(v){}
	void* ptrVal;
	bool bVal;
	int iVal;
	float fVal;
};

static BattleEventParam s_battleEventParamNull;

struct BattleEventListener
{
	BattleEventType eventType;
	unsigned long long eventId;
	bool shotOnce = false;
	std::function < void(const BattleEventParam& param)> eventCallback;
};

class BattleEventDispatcher
{
public:

	static BattleEventDispatcher* getInstance();
	~BattleEventDispatcher(void);

	void removeAllEventListeners();

#if !defined(_EXPORTING_LUA)
	void addEventListener(BattleEventType, const std::function<void(const BattleEventParam& param)>& callback, bool shotOnce = false);
#endif
	void removeEventListener(BattleEventType);
	void removeEventListener(BattleEventType, unsigned long long eventId);
	void dispatchEvent(BattleEventType, const BattleEventParam& param = s_battleEventParamNull);


	inline void setNotifyAttackStart(bool turn){ turnround = turn; };
	inline bool needsNotifyAttackStart() const {
		return turnround; 			
	};

	inline void setCtlAttackStart(bool islocal){ ctllocal = islocal; };
	inline bool judgeCtlAttackStart()const { return ctllocal; };

protected:
	unsigned long long autoEventIdAcc = 0;
	std::unordered_map<int, std::vector<BattleEventListener*>> tEventListeners;
	bool turnround = false;
	bool ctllocal = true;
	bool againcor;
};

#endif

	// int i;   // int
	// float ii;
	// string a;
	// char c;
	// auto name = typeid(i).name();
	// cout << "i ������Ϊ: " << typeid(i).name() << endl;         // ��ʾ��������������
	// string m1 = "int";
	// if ((string)(typeid(i).name()) == m1)
	// {
		// cout << "yes" << endl;
	// }
	// cout << "ii ������Ϊ: " << typeid(ii).name() << endl;
	// string m2 = "float";
	// if ((string)(typeid(i).name()) == m2)
	// {
		// cout << "yes" << endl;
	// }
	// cout << "a ������Ϊ: " << typeid(a).name() << endl;
	// cout << "c ������Ϊ: " << typeid(c).name() << endl;
 //void(BattleFieldController::*updateFunc)(float dt);   //
