#include "BattleEventDispatcher.h"
#include "Ability.h"
#include "Unit.h"
#include "BattleScene.h"
#include "BattleField.h"
#include "Soldier.h"
#include "BattleFieldController.h"
#include "data/DataSourceCSV.h"


BattleEventDispatcher* BattleEventDispatcher::getInstance()
{
	return purelib::gc::singleton<BattleEventDispatcher>::instance();
}

BattleEventDispatcher::~BattleEventDispatcher(void)
{
    removeAllEventListeners();
}

void BattleEventDispatcher::removeAllEventListeners()
{
    for (auto listeners : this->tEventListeners)
    {
        for (auto listener : listeners.second)
        {
            delete listener;
        }
    }
    this->tEventListeners.clear();
}

void BattleEventDispatcher::addEventListener(BattleEventType type, const std::function<void(const BattleEventParam& param)>& callback, bool shotOnce)
{
	auto target = tEventListeners.find(type);
	if (target == tEventListeners.end())
	{
		std::vector<BattleEventListener*> emptyVec;
		target = tEventListeners.insert(std::make_pair(type, emptyVec)).first;
	}

	auto listener = new BattleEventListener();
	listener->eventId = ++autoEventIdAcc;
	listener->eventType = type;
	listener->eventCallback = callback;
        listener->shotOnce = shotOnce;
	target->second.push_back(listener);
}

void BattleEventDispatcher::dispatchEvent(BattleEventType type, const BattleEventParam& param)
{
    auto target = tEventListeners.find(type);
    if (target != tEventListeners.end())
    {
        for (auto listener = target->second.begin(); listener != target->second.end();)
        {
			(*listener)->eventCallback(param);
            if ((*listener)->shotOnce)
            {
                delete *listener;
                listener = target->second.erase(listener);
            }
            else {
                ++listener;
            }
        }
    }
}

void BattleEventDispatcher::removeEventListener(BattleEventType){}
void BattleEventDispatcher::removeEventListener(BattleEventType, unsigned long long eventId){}
